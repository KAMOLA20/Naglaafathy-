import { useEffect, useMemo, useState } from 'react';
import { Lock, Star } from 'lucide-react';
import type { Course, Lesson, LessonAttendance, LessonReview, Student } from '../types.ts';
import { formatArabicDateTime } from '../utils/academy.ts';

interface LessonReviewPanelProps {
  course: Course;
  lesson: Lesson;
  currentStudent: Student | null;
  isCourseUnlocked: boolean;
  attendance: LessonAttendance | null;
  reviews: LessonReview[];
  onSubmitReview: (payload: {
    lessonId: string;
    audioRating: number;
    contentRating: number;
    comment: string;
  }) => Promise<LessonReview | null>;
  onGoToStudentLogin: () => void;
}

export function LessonReviewPanel({
  course,
  lesson,
  currentStudent,
  isCourseUnlocked,
  attendance,
  reviews,
  onSubmitReview,
  onGoToStudentLogin,
}: LessonReviewPanelProps) {
  const [audioRating, setAudioRating] = useState<number>(5);
  const [contentRating, setContentRating] = useState<number>(5);
  const [comment, setComment] = useState<string>('');
  const [submitting, setSubmitting] = useState(false);

  const courseReviews = useMemo(
    () => reviews.filter((r) => r.courseId === course.id),
    [reviews, course.id]
  );

  const currentLessonReviews = useMemo(
    () => courseReviews.filter((r) => r.lessonId === lesson.id),
    [courseReviews, lesson.id]
  );

  const myLessonReview = useMemo(() => {
    if (!currentStudent) return null;
    return currentLessonReviews.find((r) => r.studentId === currentStudent.id) || null;
  }, [currentLessonReviews, currentStudent]);

  useEffect(() => {
    if (myLessonReview) {
      setAudioRating(myLessonReview.audioRating);
      setContentRating(myLessonReview.contentRating);
      setComment(myLessonReview.comment);
    } else {
      setAudioRating(5);
      setContentRating(5);
      setComment('');
    }
  }, [myLessonReview?.id, lesson.id]);

  const lessonAverageRating = useMemo(() => {
    if (currentLessonReviews.length === 0) return null;
    const sum = currentLessonReviews.reduce((acc, r) => acc + r.overallRating, 0);
    return Number((sum / currentLessonReviews.length).toFixed(1));
  }, [currentLessonReviews]);

  const courseAverageRating = useMemo(() => {
    if (courseReviews.length === 0) return null;
    const sum = courseReviews.reduce((acc, r) => acc + r.overallRating, 0);
    return Number((sum / courseReviews.length).toFixed(1));
  }, [courseReviews]);

  const isLessonCompleted = Boolean(
    currentStudent &&
      (currentStudent.completedLessonIds.includes(lesson.id) || attendance?.fullyWatched)
  );

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (submitting) return;
    setSubmitting(true);
    try {
      await onSubmitReview({
        lessonId: lesson.id,
        audioRating,
        contentRating,
        comment,
      });
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <section
      aria-label="تقييم الدرس والمحتوى التعليمي"
      className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 space-y-5"
    >
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 dark:border-slate-800 pb-4">
        <div>
          <h2 className="text-base font-bold text-slate-900 dark:text-slate-100 font-display">
            تقييم الدرس والمحتوى التعليمي ({lesson.title})
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
            شارك تقييمك من 5 نجوم وملاحظتك النصية بعد الانتهاء من مشاهدة الدرس
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3 shrink-0">
          {lessonAverageRating !== null && (
            <div className="flex items-center gap-1.5 text-xs font-bold text-slate-900 dark:text-slate-100 bg-amber-50 dark:bg-amber-950/50 border border-amber-200 dark:border-amber-800 px-3 py-1.5 rounded-xl font-mono tabular-nums">
              <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-500" />
              <span>متوسط هذا الدرس: {lessonAverageRating} / 5</span>
              <span className="text-slate-500 dark:text-slate-400 font-sans font-normal">
                ({currentLessonReviews.length})
              </span>
            </div>
          )}

          {courseAverageRating !== null && (
            <div className="flex items-center gap-1.5 text-sm font-bold text-slate-900 dark:text-slate-100 font-mono tabular-nums">
              <Star className="w-4 h-4 fill-amber-400 text-amber-500" />
              <span>{courseAverageRating} / 5</span>
              <span className="text-xs font-sans font-normal text-slate-500 dark:text-slate-400">
                · {courseReviews.length} تقييمات للكورس
              </span>
            </div>
          )}
        </div>
      </div>

      {!isCourseUnlocked ? (
        <div className="bg-slate-50 dark:bg-slate-800/70 border border-slate-200 dark:border-slate-700 rounded-xl p-4 flex items-center gap-3 text-xs text-slate-600 dark:text-slate-300">
          <Lock className="w-4 h-4 shrink-0 text-slate-500 dark:text-slate-400" />
          <span>اشترك في الكورس وشاهد الدرس لتتمكن من إضافة تقييمك وملاحظتك.</span>
        </div>
      ) : !currentStudent ? (
        <div className="bg-slate-50 dark:bg-slate-800/70 border border-slate-200 dark:border-slate-700 rounded-xl p-4 flex flex-wrap items-center justify-between gap-3 text-xs text-slate-700 dark:text-slate-200">
          <span>سجّل الدخول بحساب الطالب أولاً لتقييم الدروس بعد الانتهاء منها.</span>
          <button
            type="button"
            onClick={onGoToStudentLogin}
            className="px-4 py-2 min-h-[38px] bg-blue-700 hover:bg-blue-800 text-white font-bold rounded-xl cursor-pointer"
          >
            تسجيل الدخول
          </button>
        </div>
      ) : !isLessonCompleted ? (
        <div className="bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800 rounded-xl p-4 flex items-start gap-3 text-xs text-amber-950 dark:text-amber-100">
          <Lock className="w-4 h-4 shrink-0 mt-0.5 text-amber-700 dark:text-amber-400" />
          <div className="space-y-1">
            <p className="font-bold">يُفتح التقييم فور الانتهاء من مشاهدة الدرس</p>
            <p className="text-amber-900/90 dark:text-amber-200/90 tabular-nums">
              شاهد الشرح الكرتوني حتى 90% أو اضغط على زر «تأكيد إتمام المحاضرة» بعد المشاهدة لإضافة تقييمك (من 5 نجوم) وملاحظتك النصية والحصول على 15 نقطة.
              {attendance ? ` (مشاهدتك الحالية: ${attendance.watchedPercent}%)` : ''}
            </p>
          </div>
        </div>
      ) : (
        <form
          onSubmit={(e) => void handleSubmit(e)}
          className="bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-xl p-5 space-y-4"
        >
          <div className="flex flex-wrap items-center justify-between gap-2">
            <p className="text-xs font-bold text-slate-900 dark:text-slate-100">
              {myLessonReview ? 'تحديث تقييمك وملاحظتك لهذا الدرس' : 'أضف تقييمك وملاحظتك بعد إتمام الدرس (+15 نقطة)'}
            </p>
            <span className="text-xs font-mono font-bold text-amber-700 dark:text-amber-400 tabular-nums">
              المتوسط: {((audioRating + contentRating) / 2).toFixed(1)} / 5
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl p-3.5 space-y-2">
              <span className="text-xs font-semibold text-slate-700 dark:text-slate-200 block">
                تقييم الشرح الصوتي والرسوم
              </span>
              <div className="flex items-center gap-1" role="radiogroup" aria-label="تقييم الشرح الصوتي">
                {[1, 2, 3, 4, 5].map((star) => (
                  <button
                    key={star}
                    type="button"
                    onClick={() => setAudioRating(star)}
                    aria-label={`${star} نجوم للشرح الصوتي`}
                    className="p-1.5 rounded-lg hover:bg-amber-50 dark:hover:bg-amber-950/60 transition-colors cursor-pointer"
                  >
                    <Star
                      className={`w-5 h-5 ${
                        star <= audioRating
                          ? 'fill-amber-400 text-amber-500'
                          : 'text-slate-300 dark:text-slate-600'
                      }`}
                    />
                  </button>
                ))}
                <span className="mr-2 text-xs font-mono font-bold text-slate-700 dark:text-slate-200 tabular-nums">
                  {audioRating}/5
                </span>
              </div>
            </div>

            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl p-3.5 space-y-2">
              <span className="text-xs font-semibold text-slate-700 dark:text-slate-200 block">
                تقييم المحتوى التعليمي والأمثلة
              </span>
              <div className="flex items-center gap-1" role="radiogroup" aria-label="تقييم المحتوى التعليمي">
                {[1, 2, 3, 4, 5].map((star) => (
                  <button
                    key={star}
                    type="button"
                    onClick={() => setContentRating(star)}
                    aria-label={`${star} نجوم للمحتوى التعليمي`}
                    className="p-1.5 rounded-lg hover:bg-amber-50 dark:hover:bg-amber-950/60 transition-colors cursor-pointer"
                  >
                    <Star
                      className={`w-5 h-5 ${
                        star <= contentRating
                          ? 'fill-amber-400 text-amber-500'
                          : 'text-slate-300 dark:text-slate-600'
                      }`}
                    />
                  </button>
                ))}
                <span className="mr-2 text-xs font-mono font-bold text-slate-700 dark:text-slate-200 tabular-nums">
                  {contentRating}/5
                </span>
              </div>
            </div>
          </div>

          <label className="block space-y-1">
            <span className="text-xs font-semibold text-slate-700 dark:text-slate-200">
              ملاحظتك النصية ورأيك على الدرس
            </span>
            <textarea
              rows={2}
              value={comment}
              onChange={(e) => setComment(e.target.value)}
              maxLength={600}
              placeholder="اكتب ملاحظتك في وضوح الشرح، الصوت، وأمثلة السبورة..."
              className="w-full px-3.5 py-2.5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-slate-100 placeholder:text-slate-400 rounded-xl text-xs focus:outline-none focus:border-blue-600"
            />
          </label>

          <div className="flex items-center justify-end">
            <button
              type="submit"
              disabled={submitting}
              className="px-5 py-2.5 min-h-[40px] bg-blue-700 hover:bg-blue-800 disabled:bg-slate-400 text-white text-xs font-bold rounded-xl transition-colors cursor-pointer"
            >
              {submitting
                ? 'جاري الحفظ...'
                : myLessonReview
                  ? 'تحديث تقييمي وملاحظتي'
                  : 'إرسال التقييم والملاحظة (+15 نقطة)'}
            </button>
          </div>
        </form>
      )}

      {/* Verified Reviews List */}
      <div className="space-y-3">
        <h3 className="text-xs font-bold text-slate-700 dark:text-slate-300">
          آراء الطلاب في هذا الكورس ({courseReviews.length})
        </h3>
        {courseReviews.length === 0 ? (
          <p className="text-xs text-slate-500 dark:text-slate-400 py-2">
            لم تُضف تقييمات لهذا الكورس بعد — كن أول طالب يقيم الدرس بعد مشاهدته!
          </p>
        ) : (
          <div className="space-y-2.5">
            {(currentLessonReviews.length > 0 ? currentLessonReviews : courseReviews).map((rev) => (
              <div
                key={rev.id}
                className="border border-slate-200 dark:border-slate-700 rounded-xl p-4 space-y-1.5 bg-white dark:bg-slate-800/50"
              >
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div className="text-xs">
                    <span className="font-bold text-slate-900 dark:text-slate-100">{rev.studentName}</span>
                    <span className="text-slate-400 mx-1.5">·</span>
                    <span className="text-slate-500 dark:text-slate-400">{rev.lessonTitle}</span>
                  </div>
                  <div className="flex items-center gap-1 text-xs font-mono font-bold text-amber-700 dark:text-amber-400 tabular-nums">
                    <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-500" />
                    <span>{rev.overallRating.toFixed(1)}</span>
                  </div>
                </div>
                <p className="text-[11px] text-slate-500 dark:text-slate-400 tabular-nums">
                  الصوت والرسوم: {rev.audioRating}/5 · المحتوى التعليمي: {rev.contentRating}/5 ·{' '}
                  {formatArabicDateTime(rev.updatedAt || rev.createdAt)}
                </p>
                {rev.comment && (
                  <p className="text-xs text-slate-700 dark:text-slate-200 leading-relaxed pt-1">
                    {rev.comment}
                  </p>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </section>
  );
}
