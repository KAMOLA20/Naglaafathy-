import { useEffect, useMemo, useRef, useState } from 'react';
import {
  Award,
  CheckCircle2,
  CreditCard,
  Download,
  Eye,
  KeyRound,
  LogOut,
  Play,
  UserCheck,
  Wallet,
  X,
} from 'lucide-react';
import { useAcademy } from '../context/AcademyContext.tsx';
import type { Certificate, GradeLevel, TopupMethod } from '../types.ts';
import {
  BRANCH_LABELS,
  EGYPT_GOVERNORATES,
  formatArabicDateTime,
  formatEgp,
  GRADE_LABELS,
  TOPUP_METHOD_LABELS,
} from '../utils/academy.ts';
import { renderCertificateToCanvas } from '../utils/certificatePdf.ts';

export function StudentPortal() {
  const {
    snapshot,
    currentStudent,
    loginStudent,
    registerStudent,
    logoutStudent,
    openCourse,
    redeemCode,
    requestTopup,
    createFawryCharge,
    confirmSandboxFawryOrder,
    downloadCertificatePdf,
  } = useAcademy();

  const [authMode, setAuthMode] = useState<'login' | 'register'>('login');
  const [phone, setPhone] = useState('01099887766');
  const [password, setPassword] = useState('123456');

  // Register fields
  const [regName, setRegName] = useState('');
  const [regPhone, setRegPhone] = useState('');
  const [regParentPhone, setRegParentPhone] = useState('');
  const [regGov, setRegGov] = useState('القاهرة');
  const [regGrade, setRegGrade] = useState<GradeLevel>('p4');
  const [regPassword, setRegPassword] = useState('');

  // Portal actions
  const [codeInput, setCodeInput] = useState('');
  const [topupAmount, setTopupAmount] = useState('250');
  const [topupMethod, setTopupMethod] = useState<TopupMethod>('fawry');
  const [topupRef, setTopupRef] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const enrolledCourses = useMemo(() => {
    if (!snapshot || !currentStudent) return [];
    return snapshot.courses.filter(
      (c) => c.priceEgp === 0 || currentStudent.enrolledCourseIds.includes(c.id)
    );
  }, [snapshot, currentStudent]);

  const myAttempts = useMemo(() => {
    if (!snapshot || !currentStudent) return [];
    return snapshot.examAttempts.filter((a) => a.studentId === currentStudent.id);
  }, [snapshot, currentStudent]);

  const myWalletRequests = useMemo(() => {
    if (!snapshot || !currentStudent) return [];
    return snapshot.walletRequests.filter((w) => w.studentId === currentStudent.id);
  }, [snapshot, currentStudent]);

  const myFawryOrders = useMemo(() => {
    if (!snapshot || !currentStudent) return [];
    return (snapshot.fawryOrders || []).filter((o) => o.studentId === currentStudent.id);
  }, [snapshot, currentStudent]);

  const myCertificates = useMemo(() => {
    if (!snapshot || !currentStudent) return [];
    return (snapshot.certificates || []).filter((c) => c.studentId === currentStudent.id);
  }, [snapshot, currentStudent]);

  const [previewCert, setPreviewCert] = useState<Certificate | null>(null);
  const [downloadingCertId, setDownloadingCertId] = useState<string | null>(null);
  const previewCanvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    if (!previewCert || !previewCanvasRef.current) return;
    let active = true;
    const draw = async () => {
      if ('fonts' in document) {
        try {
          await document.fonts.ready;
        } catch {
          // ignore font wait failure
        }
      }
      if (active && previewCanvasRef.current) {
        renderCertificateToCanvas(previewCanvasRef.current, previewCert);
      }
    };
    void draw();
    return () => {
      active = false;
    };
  }, [previewCert]);

  const handleLoginSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    await loginStudent(phone, password);
    setSubmitting(false);
  };

  const handleRegisterSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    await registerStudent({
      name: regName,
      phone: regPhone,
      parentPhone: regParentPhone,
      governorate: regGov,
      grade: regGrade,
      password: regPassword,
    });
    setSubmitting(false);
  };

  const handleRedeem = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!codeInput.trim()) return;
    setSubmitting(true);
    const ok = await redeemCode(codeInput.trim());
    if (ok) setCodeInput('');
    setSubmitting(false);
  };

  const handleTopup = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    if (topupMethod === 'fawry') {
      await createFawryCharge({
        purpose: 'wallet',
        amountEgp: Number(topupAmount),
      });
    } else {
      const ok = await requestTopup({
        amountEgp: Number(topupAmount),
        method: topupMethod,
        referenceNumber: topupRef,
      });
      if (ok) setTopupRef('');
    }
    setSubmitting(false);
  };

  if (!currentStudent) {
    return (
      <div className="max-w-xl mx-auto py-6">
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 sm:p-8 space-y-6">
          <div className="space-y-1">
            <h1 className="text-2xl font-extrabold text-slate-900 dark:text-slate-100 font-display">
              بوابة الطالب
            </h1>
            <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400">
              سجل الدخول للوصول إلى كورساتك، متابعة درجات الامتحانات، وشحن المحفظة أو أكواد السنتر.
            </p>
          </div>

          <div className="grid grid-cols-2 gap-1 p-1 bg-slate-100 dark:bg-slate-800 rounded-xl">
            <button
              type="button"
              onClick={() => setAuthMode('login')}
              className={`py-2 text-xs font-semibold rounded-lg transition-colors cursor-pointer ${
                authMode === 'login' ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-slate-100 shadow-sm' : 'text-slate-600 dark:text-slate-400'
              }`}
            >
              تسجيل الدخول
            </button>
            <button
              type="button"
              onClick={() => setAuthMode('register')}
              className={`py-2 text-xs font-semibold rounded-lg transition-colors cursor-pointer ${
                authMode === 'register' ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-slate-100 shadow-sm' : 'text-slate-600 dark:text-slate-400'
              }`}
            >
              حساب طالب جديد
            </button>
          </div>

          {authMode === 'login' ? (
            <form onSubmit={(e) => void handleLoginSubmit(e)} className="space-y-4">
              <label className="block space-y-1.5">
                <span className="text-xs font-semibold text-slate-700 dark:text-slate-300">رقم موبايل الطالب</span>
                <input
                  type="tel"
                  dir="ltr"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="010xxxxxxxx"
                  className="w-full px-3.5 py-2.5 min-h-[42px] bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-sm font-mono text-slate-900 dark:text-slate-100 focus:outline-none focus:border-blue-700"
                />
              </label>

              <label className="block space-y-1.5">
                <span className="text-xs font-semibold text-slate-700 dark:text-slate-300">كلمة المرور</span>
                <input
                  type="password"
                  dir="ltr"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••"
                  className="w-full px-3.5 py-2.5 min-h-[42px] bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-sm text-slate-900 dark:text-slate-100 focus:outline-none focus:border-blue-700"
                />
              </label>

              <button
                type="submit"
                disabled={submitting}
                className="w-full py-3 min-h-[44px] bg-blue-700 hover:bg-blue-800 text-white text-sm font-semibold rounded-xl transition-colors cursor-pointer"
              >
                {submitting ? 'جاري الدخول...' : 'دخول إلى حسابي'}
              </button>

              <div className="bg-slate-50 dark:bg-slate-800/70 border border-slate-200 dark:border-slate-700 rounded-xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div className="text-xs text-slate-600 dark:text-slate-400">
                  <p className="font-bold text-slate-900 dark:text-slate-100">حساب طالب تجريبي جاهز</p>
                  <p className="font-mono mt-0.5">01099887766 · 123456</p>
                </div>
                <button
                  type="button"
                  onClick={() => void loginStudent('01099887766', '123456')}
                  className="inline-flex items-center gap-1.5 px-4 py-2 bg-slate-900 dark:bg-blue-700 hover:bg-slate-800 dark:hover:bg-blue-800 text-white text-xs font-semibold rounded-xl shrink-0 cursor-pointer"
                >
                  <UserCheck className="w-3.5 h-3.5" />
                  <span>دخول سريع</span>
                </button>
              </div>
            </form>
          ) : (
            <form onSubmit={(e) => void handleRegisterSubmit(e)} className="space-y-4">
              <label className="block space-y-1.5">
                <span className="text-xs font-semibold text-slate-700 dark:text-slate-300">اسم الطالب الثلاثي</span>
                <input
                  type="text"
                  value={regName}
                  onChange={(e) => setRegName(e.target.value)}
                  placeholder="مثال: كريم أحمد علي"
                  className="w-full px-3.5 py-2.5 min-h-[42px] bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-sm text-slate-900 dark:text-slate-100 focus:outline-none focus:border-blue-700"
                />
              </label>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <label className="block space-y-1.5">
                  <span className="text-xs font-semibold text-slate-700 dark:text-slate-300">موبايل الطالب</span>
                  <input
                    type="tel"
                    dir="ltr"
                    value={regPhone}
                    onChange={(e) => setRegPhone(e.target.value)}
                    placeholder="010xxxxxxxx"
                    className="w-full px-3.5 py-2.5 min-h-[42px] bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-sm font-mono text-slate-900 dark:text-slate-100 focus:outline-none focus:border-blue-700"
                  />
                </label>

                <label className="block space-y-1.5">
                  <span className="text-xs font-semibold text-slate-700 dark:text-slate-300">موبايل ولي الأمر</span>
                  <input
                    type="tel"
                    dir="ltr"
                    value={regParentPhone}
                    onChange={(e) => setRegParentPhone(e.target.value)}
                    placeholder="011xxxxxxxx"
                    className="w-full px-3.5 py-2.5 min-h-[42px] bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-sm font-mono text-slate-900 dark:text-slate-100 focus:outline-none focus:border-blue-700"
                  />
                </label>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <label className="block space-y-1.5">
                  <span className="text-xs font-semibold text-slate-700 dark:text-slate-300">الصف الدراسي</span>
                  <select
                    value={regGrade}
                    onChange={(e) => setRegGrade(e.target.value as GradeLevel)}
                    className="w-full px-3 py-2.5 min-h-[42px] bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-semibold text-slate-900 dark:text-slate-100 focus:outline-none focus:border-blue-700"
                  >
                    {Object.entries(GRADE_LABELS).map(([k, v]) => (
                      <option key={k} value={k}>
                        {v}
                      </option>
                    ))}
                  </select>
                </label>

                <label className="block space-y-1.5">
                  <span className="text-xs font-semibold text-slate-700 dark:text-slate-300">المحافظة</span>
                  <select
                    value={regGov}
                    onChange={(e) => setRegGov(e.target.value)}
                    className="w-full px-3 py-2.5 min-h-[42px] bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-semibold text-slate-900 dark:text-slate-100 focus:outline-none focus:border-blue-700"
                  >
                    {EGYPT_GOVERNORATES.map((g) => (
                      <option key={g} value={g}>
                        {g}
                      </option>
                    ))}
                  </select>
                </label>
              </div>

              <label className="block space-y-1.5">
                <span className="text-xs font-semibold text-slate-700 dark:text-slate-300">كلمة المرور (6 أحرف فأكثر)</span>
                <input
                  type="password"
                  dir="ltr"
                  value={regPassword}
                  onChange={(e) => setRegPassword(e.target.value)}
                  placeholder="••••••"
                  className="w-full px-3.5 py-2.5 min-h-[42px] bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-sm text-slate-900 dark:text-slate-100 focus:outline-none focus:border-blue-700"
                />
              </label>

              <button
                type="submit"
                disabled={submitting}
                className="w-full py-3 min-h-[44px] bg-blue-700 hover:bg-blue-800 text-white text-sm font-semibold rounded-xl transition-colors cursor-pointer"
              >
                {submitting ? 'جاري إنشاء الحساب...' : 'إنشاء حساب الطالب'}
              </button>
            </form>
          )}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-8 pb-10">
      {/* Profile Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-200 dark:border-slate-800 pb-4">
        <div>
          <p className="text-xs font-semibold text-blue-700 dark:text-blue-400">
            {GRADE_LABELS[currentStudent.grade]} · {currentStudent.governorate}
          </p>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-slate-100 font-display mt-1">
            مرحباً، {currentStudent.name}
          </h1>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5 font-mono tabular-nums">
            موبايل الطالب: {currentStudent.phone} · ولي الأمر: {currentStudent.parentPhone}
          </p>
        </div>

        <button
          type="button"
          onClick={() => void logoutStudent()}
          className="inline-flex items-center gap-1.5 px-4 py-2 min-h-[40px] bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-100 text-xs font-semibold rounded-xl transition-colors whitespace-nowrap shrink-0 cursor-pointer"
        >
          <LogOut className="w-3.5 h-3.5" />
          <span>تسجيل الخروج</span>
        </button>
      </div>

      {/* 4-Column KPI Strip */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5">
          <p className="text-xs text-slate-500 dark:text-slate-400">رصيد المحفظة</p>
          <p className="text-2xl font-extrabold text-slate-900 dark:text-slate-100 font-mono tabular-nums mt-1">
            {currentStudent.walletBalance} ج.م
          </p>
        </div>
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5">
          <p className="text-xs text-slate-500 dark:text-slate-400">الكورسات المفعلة</p>
          <p className="text-2xl font-extrabold text-blue-700 dark:text-blue-400 font-mono tabular-nums mt-1">
            {enrolledCourses.length}
          </p>
        </div>
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5">
          <p className="text-xs text-slate-500 dark:text-slate-400">المحاضرات المكتملة</p>
          <p className="text-2xl font-extrabold text-emerald-700 dark:text-emerald-400 font-mono tabular-nums mt-1">
            {currentStudent.completedLessonIds.length}
          </p>
        </div>
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5">
          <p className="text-xs text-slate-500 dark:text-slate-400">نقاط التفوق</p>
          <p className="text-2xl font-extrabold text-amber-600 dark:text-amber-400 font-mono tabular-nums mt-1">
            {currentStudent.points}
          </p>
        </div>
      </div>

      {/* Enrolled Courses */}
      <section className="space-y-4">
        <h2 className="text-lg font-bold text-slate-900 dark:text-slate-100 font-display">كورساتي الحالية</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {enrolledCourses.map((course) => {
            const done = course.lessons.filter((l) => {
              const att = (snapshot?.attendances || []).find(
                (a) => a.studentId === currentStudent.id && a.lessonId === l.id
              );
              return Boolean(att && att.checkedIn && att.fullyWatched);
            }).length;
            const pct = course.lessons.length > 0 ? Math.round((done / course.lessons.length) * 100) : 0;
            return (
              <div
                key={course.id}
                className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 flex flex-col justify-between gap-4"
              >
                <div className="space-y-2">
                  <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
                    <span>{course.monthLabel}</span>
                    <span className="font-mono tabular-nums">
                      حضور ومشاهدة {done}/{course.lessons.length} محاضرات ({pct}%)
                    </span>
                  </div>
                  <h3 className="text-base font-bold text-slate-900 dark:text-slate-100 font-display">{course.title}</h3>
                  <div className="h-2 bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
                    <div className="h-full bg-blue-700 dark:bg-blue-500" style={{ width: `${pct}%` }} />
                  </div>
                </div>

                <div className="flex items-center justify-between pt-2 border-t border-slate-100 dark:border-slate-800">
                  <span className="inline-flex items-center gap-1 text-xs font-semibold text-emerald-700 dark:text-emerald-400">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>
                      {done >= course.lessons.length && course.lessons.length > 0
                        ? 'تم حضور الـ 8 محاضرات (الشهادة صادرة)'
                        : `مفعل · متبقي ${Math.max(0, course.lessons.length - done)} حضور كامل للشهادة`}
                    </span>
                  </span>
                  <button
                    type="button"
                    onClick={() => openCourse(course.id)}
                    className="inline-flex items-center gap-1.5 px-4 py-2 bg-slate-900 dark:bg-blue-700 hover:bg-slate-800 dark:hover:bg-blue-800 text-white text-xs font-semibold rounded-xl cursor-pointer"
                  >
                    <Play className="w-3.5 h-3.5" />
                    <span>استكمال المحاضرات</span>
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* Earned Completion Certificates (Auto-issued on 8/8 lectures) */}
      <section className="space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <Award className="w-5 h-5 text-amber-600 dark:text-amber-400" />
            <h2 className="text-lg font-bold text-slate-900 dark:text-slate-100 font-display">
              شهادات الإنجاز التلقائية (إتمام 8 محاضرات)
            </h2>
          </div>
          <span className="text-xs font-mono text-slate-500 dark:text-slate-400 tabular-nums">
            الشهادات الصادرة: {myCertificates.length}
          </span>
        </div>

        {myCertificates.length === 0 ? (
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="space-y-1">
              <p className="text-sm font-bold text-slate-900 dark:text-slate-100">
                لم تصدر لك شهادة إتمام بعد
              </p>
              <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
                بمجرد إتمام الـ 8 محاضرات كاملة في أي كورس مفعل على حسابك، يتم إصدار شهادة الإنجاز المعتمدة تلقائياً ويمكنك تحميلها بصيغة PDF من هنا.
              </p>
            </div>
            {enrolledCourses[0] && (
              <button
                type="button"
                onClick={() => openCourse(enrolledCourses[0].id)}
                className="px-4 py-2.5 min-h-[40px] bg-blue-700 hover:bg-blue-800 text-white text-xs font-semibold rounded-xl whitespace-nowrap shrink-0 cursor-pointer"
              >
                متابعة المحاضرات الآن
              </button>
            )}
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {myCertificates.map((cert) => {
              const parentCourse = snapshot?.courses.find((c) => c.id === cert.courseId);
              const attendedFull = parentCourse
                ? parentCourse.lessons.filter((l) => {
                    const att = (snapshot?.attendances || []).find(
                      (a) => a.studentId === currentStudent.id && a.lessonId === l.id
                    );
                    return Boolean(att && att.checkedIn && att.fullyWatched);
                  }).length
                : cert.completedLessonsCount;
              const attendanceVerified = attendedFull >= cert.totalLessonsCount;

              return (
                <div
                  key={cert.id}
                  className="bg-white dark:bg-slate-900 border border-amber-300/80 dark:border-amber-700/70 rounded-2xl p-5 flex flex-col justify-between gap-4"
                >
                  <div className="space-y-2">
                    <div className="flex items-center justify-between gap-2 text-xs text-slate-500 dark:text-slate-400">
                      <span className="font-semibold text-amber-800 dark:text-amber-400">
                        {GRADE_LABELS[cert.grade]} · {BRANCH_LABELS[cert.branch]}
                      </span>
                      <span className="font-mono font-semibold text-slate-700 dark:text-slate-300 tabular-nums">
                        {cert.certificateNumber}
                      </span>
                    </div>

                    <h3 className="text-base font-extrabold text-slate-900 dark:text-slate-100 font-display leading-snug">
                      شهادة إتمام: {cert.courseTitle}
                    </h3>

                    <p className="text-xs text-slate-600 dark:text-slate-400 tabular-nums">
                      تم التحقق من حضور ومشاهدة {attendedFull} من {cert.totalLessonsCount} محاضرات ({cert.monthLabel}) · صدرت في{' '}
                      {formatArabicDateTime(cert.issuedAt)}
                    </p>
                  </div>

                  <div className="flex flex-wrap items-center justify-between gap-2 pt-3 border-t border-slate-100 dark:border-slate-800">
                    <button
                      type="button"
                      onClick={() => setPreviewCert(cert)}
                      className="inline-flex items-center gap-1.5 px-3.5 py-2 min-h-[40px] bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-900 dark:text-slate-100 text-xs font-semibold rounded-xl cursor-pointer"
                    >
                      <Eye className="w-3.5 h-3.5" />
                      <span>معاينة الشهادة</span>
                    </button>

                    <button
                      type="button"
                      disabled={!attendanceVerified || downloadingCertId === cert.id}
                      onClick={async () => {
                        setDownloadingCertId(cert.id);
                        await downloadCertificatePdf(cert.id);
                        setDownloadingCertId(null);
                      }}
                      className="inline-flex items-center gap-1.5 px-4 py-2 min-h-[40px] bg-blue-700 hover:bg-blue-800 disabled:opacity-60 text-white text-xs font-bold rounded-xl cursor-pointer"
                    >
                      <Download className="w-3.5 h-3.5" />
                      <span>
                        {downloadingCertId === cert.id
                          ? 'جاري تجهيز PDF...'
                          : attendanceVerified
                            ? 'تحميل الشهادة PDF'
                            : 'بانتظار إكمال الحضور 8/8'}
                      </span>
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </section>

      {/* Code Redemption + Wallet Topup */}
      <section className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <form
          onSubmit={(e) => void handleRedeem(e)}
          className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 space-y-4"
        >
          <div className="flex items-center gap-2">
            <KeyRound className="w-5 h-5 text-blue-700 dark:text-blue-400" />
            <h2 className="text-base font-bold text-slate-900 dark:text-slate-100 font-display">شحن كود سنتر أو كارت اشتراك</h2>
          </div>
          <p className="text-xs text-slate-600 dark:text-slate-400">
            أدخل الكود المطبوع على بطاقة الكورس. للتجربة السريعة: <span className="font-mono font-bold text-blue-700 dark:text-blue-400">QEMA-P4-MATH</span>
          </p>
          <div className="flex gap-2">
            <input
              type="text"
              dir="ltr"
              value={codeInput}
              onChange={(e) => setCodeInput(e.target.value.toUpperCase())}
              placeholder="QEMA-XXXX-2026"
              className="flex-1 px-3.5 py-2.5 min-h-[42px] bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-sm font-mono text-slate-900 dark:text-slate-100 focus:outline-none focus:border-blue-700"
            />
            <button
              type="submit"
              disabled={submitting}
              className="px-5 py-2.5 min-h-[42px] bg-blue-700 hover:bg-blue-800 text-white text-xs font-semibold rounded-xl whitespace-nowrap shrink-0 cursor-pointer"
            >
              تفعيل الكود
            </button>
          </div>
        </form>

        <form
          onSubmit={(e) => void handleTopup(e)}
          className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 space-y-4"
        >
          <div className="flex items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              <Wallet className="w-5 h-5 text-emerald-700 dark:text-emerald-400" />
              <h2 className="text-base font-bold text-slate-900 dark:text-slate-100 font-display">شحن المحفظة الإلكترونية</h2>
            </div>
            <span className="text-[11px] font-semibold text-amber-800 dark:text-amber-400">
              {snapshot?.fawryStatus.mode === 'live' ? 'فوري باي مباشر' : 'فوري باي (تجريبي)'}
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <label className="block space-y-1">
              <span className="text-[11px] font-semibold text-slate-600 dark:text-slate-400">المبلغ (ج.م)</span>
              <input
                type="number"
                dir="ltr"
                min={50}
                max={5000}
                value={topupAmount}
                onChange={(e) => setTopupAmount(e.target.value)}
                className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-sm font-mono text-slate-900 dark:text-slate-100"
              />
            </label>

            <label className="block space-y-1">
              <span className="text-[11px] font-semibold text-slate-600 dark:text-slate-400">طريقة الدفع</span>
              <select
                value={topupMethod}
                onChange={(e) => setTopupMethod(e.target.value as TopupMethod)}
                className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-semibold text-slate-900 dark:text-slate-100"
              >
                {Object.entries(TOPUP_METHOD_LABELS).map(([k, v]) => (
                  <option key={k} value={k}>
                    {v}
                  </option>
                ))}
              </select>
            </label>

            {topupMethod === 'fawry' ? (
              <div className="bg-amber-50 dark:bg-amber-950/60 border border-amber-200 dark:border-amber-800 rounded-xl px-3 py-2 flex items-center text-[11px] text-amber-900 dark:text-amber-200 leading-snug">
                يصدر النظام رقماً مرجعياً فورياً للسداد عبر فوري باي وإضافة الرصيد تلقائياً.
              </div>
            ) : (
              <label className="block space-y-1">
                <span className="text-[11px] font-semibold text-slate-600 dark:text-slate-400">رقم العملية / المحول منه</span>
                <input
                  type="text"
                  dir="ltr"
                  value={topupRef}
                  onChange={(e) => setTopupRef(e.target.value)}
                  placeholder="VF-882910"
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-sm font-mono text-slate-900 dark:text-slate-100"
                />
              </label>
            )}
          </div>

          <div className="flex items-center justify-between gap-3">
            <span className="text-[11px] text-slate-500 dark:text-slate-400">
              {topupMethod === 'fawry'
                ? 'ينزل الرصيد تلقائياً فور الدفع عبر ماكينة فوري أو تطبيق myFawry.'
                : 'يتم اعتماد طلبات التحويل اليدوي من تبويب «لوحة المعلم».'}
            </span>
            <button
              type="submit"
              disabled={submitting}
              className="px-5 py-2.5 min-h-[40px] bg-slate-900 dark:bg-blue-700 hover:bg-slate-800 dark:hover:bg-blue-800 text-white text-xs font-semibold rounded-xl whitespace-nowrap shrink-0 cursor-pointer"
            >
              {topupMethod === 'fawry' ? 'إصدار كود دفع فوري باي' : 'إرسال طلب الشحن'}
            </button>
          </div>
        </form>
      </section>

      {/* FawryPay Automated Invoices */}
      {myFawryOrders.length > 0 && (
        <section className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl overflow-hidden">
          <div className="px-5 py-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <CreditCard className="w-4 h-4 text-amber-700 dark:text-amber-400" />
              <h2 className="text-sm font-bold text-slate-900 dark:text-slate-100">فواتير فوري باي (FawryPay)</h2>
            </div>
            <span className="text-xs text-slate-500 dark:text-slate-400 tabular-nums">{myFawryOrders.length} فواتير</span>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-right text-xs">
              <thead className="bg-slate-50 dark:bg-slate-800/80 text-slate-500 dark:text-slate-400 border-b border-slate-200 dark:border-slate-800">
                <tr>
                  <th className="py-2.5 px-4">الرقم المرجعي في فوري</th>
                  <th className="py-2.5 px-4">الغرض</th>
                  <th className="py-2.5 px-4">المبلغ</th>
                  <th className="py-2.5 px-4">الحالة</th>
                  <th className="py-2.5 px-4">الإجراء</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {myFawryOrders.map((order) => (
                  <tr key={order.id}>
                    <td className="py-3 px-4 font-mono font-extrabold text-slate-900 dark:text-slate-100 tabular-nums">
                      {order.referenceNumber}
                    </td>
                    <td className="py-3 px-4 text-slate-700 dark:text-slate-300">
                      {order.purpose === 'course'
                        ? `كورس: ${order.courseTitle || order.courseId}`
                        : 'شحن رصيد المحفظة'}
                    </td>
                    <td className="py-3 px-4 font-mono font-bold text-slate-900 dark:text-slate-100 tabular-nums">
                      {formatEgp(order.amountEgp)}
                    </td>
                    <td
                      className={`py-3 px-4 font-semibold ${
                        order.status === 'PAID'
                          ? 'text-emerald-700 dark:text-emerald-400'
                          : order.status === 'UNPAID'
                            ? 'text-amber-700 dark:text-amber-400'
                            : 'text-red-700 dark:text-red-400'
                      }`}
                    >
                      {order.status === 'PAID'
                        ? 'مدفوعة ومفعلة'
                        : order.status === 'UNPAID'
                          ? 'بانتظار السداد'
                          : 'منتهية'}
                    </td>
                    <td className="py-3 px-4">
                      {order.status === 'UNPAID' && order.mode === 'sandbox' ? (
                        <button
                          type="button"
                          onClick={() => void confirmSandboxFawryOrder(order.id)}
                          className="px-3 py-1.5 bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-semibold rounded-lg cursor-pointer"
                        >
                          تأكيد السداد (تجريبي)
                        </button>
                      ) : (
                        <span className="text-slate-400 dark:text-slate-500 text-[11px]">
                          {order.paidAt ? formatArabicDateTime(order.paidAt) : '—'}
                        </span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>
      )}

      {/* Exam Results & Wallet Request Logs */}
      <section className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl overflow-hidden">
          <div className="px-5 py-4 border-b border-slate-200 dark:border-slate-800">
            <h2 className="text-sm font-bold text-slate-900 dark:text-slate-100">سجل درجات الامتحانات</h2>
          </div>
          {myAttempts.length === 0 ? (
            <p className="p-6 text-xs text-slate-500 dark:text-slate-400 text-center">لم تقم بأداء أي امتحان إلكتروني بعد.</p>
          ) : (
            <table className="w-full text-right text-xs">
              <thead className="bg-slate-50 dark:bg-slate-800/80 text-slate-500 dark:text-slate-400 border-b border-slate-200 dark:border-slate-800">
                <tr>
                  <th className="py-2.5 px-4">الكورس</th>
                  <th className="py-2.5 px-4">الدرجة</th>
                  <th className="py-2.5 px-4">التقييم</th>
                  <th className="py-2.5 px-4">التاريخ</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {myAttempts.map((att) => {
                  const crs = snapshot?.courses.find((c) => c.id === att.courseId);
                  return (
                    <tr key={att.id}>
                      <td className="py-3 px-4 font-semibold text-slate-900 dark:text-slate-100">{crs?.title || att.courseId}</td>
                      <td className="py-3 px-4 font-mono font-bold text-slate-900 dark:text-slate-100 tabular-nums">
                        {att.score}/{att.total} ({att.percentage}%)
                      </td>
                      <td className={`py-3 px-4 font-semibold ${att.passed ? 'text-emerald-700 dark:text-emerald-400' : 'text-amber-700 dark:text-amber-400'}`}>
                        {att.passed ? 'ناجح' : 'يحتاج مراجعة'}
                      </td>
                      <td className="py-3 px-4 text-slate-500 dark:text-slate-400">{formatArabicDateTime(att.submittedAt)}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          )}
        </div>

        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl overflow-hidden">
          <div className="px-5 py-4 border-b border-slate-200 dark:border-slate-800">
            <h2 className="text-sm font-bold text-slate-900 dark:text-slate-100">طلبات شحن المحفظة</h2>
          </div>
          {myWalletRequests.length === 0 ? (
            <p className="p-6 text-xs text-slate-500 dark:text-slate-400 text-center">لا توجد طلبات شحن مسجلة.</p>
          ) : (
            <table className="w-full text-right text-xs">
              <thead className="bg-slate-50 dark:bg-slate-800/80 text-slate-500 dark:text-slate-400 border-b border-slate-200 dark:border-slate-800">
                <tr>
                  <th className="py-2.5 px-4">المبلغ</th>
                  <th className="py-2.5 px-4">الوسيلة</th>
                  <th className="py-2.5 px-4">المرجع</th>
                  <th className="py-2.5 px-4">الحالة</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {myWalletRequests.map((wr) => (
                  <tr key={wr.id}>
                    <td className="py-3 px-4 font-mono font-bold text-slate-900 dark:text-slate-100 tabular-nums">{formatEgp(wr.amountEgp)}</td>
                    <td className="py-3 px-4 text-slate-700 dark:text-slate-300">{TOPUP_METHOD_LABELS[wr.method]}</td>
                    <td className="py-3 px-4 font-mono text-slate-700 dark:text-slate-300">{wr.referenceNumber}</td>
                    <td
                      className={`py-3 px-4 font-semibold ${
                        wr.status === 'approved'
                          ? 'text-emerald-700 dark:text-emerald-400'
                          : wr.status === 'rejected'
                            ? 'text-red-700 dark:text-red-400'
                            : 'text-amber-700 dark:text-amber-400'
                      }`}
                    >
                      {wr.status === 'approved'
                        ? 'معتمد'
                        : wr.status === 'rejected'
                          ? 'مرفوض'
                          : 'قيد المراجعة'}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </section>

      {/* Live Certificate Preview Modal */}
      {previewCert && (
        <div
          className="fixed inset-0 z-50 bg-slate-950/80 flex items-center justify-center p-4"
          onClick={() => setPreviewCert(null)}
        >
          <div
            className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl max-w-4xl w-full overflow-hidden shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="px-5 py-3.5 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between gap-3">
              <div>
                <p className="text-sm font-bold text-slate-900 dark:text-slate-100">
                  معاينة شهادة الإتمام · {previewCert.courseTitle}
                </p>
                <p className="text-xs font-mono text-slate-500 dark:text-slate-400 tabular-nums">
                  {previewCert.certificateNumber}
                </p>
              </div>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  disabled={downloadingCertId === previewCert.id}
                  onClick={async () => {
                    setDownloadingCertId(previewCert.id);
                    await downloadCertificatePdf(previewCert.id);
                    setDownloadingCertId(null);
                  }}
                  className="inline-flex items-center gap-1.5 px-4 py-2 min-h-[38px] bg-blue-700 hover:bg-blue-800 text-white text-xs font-bold rounded-xl cursor-pointer"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>تحميل PDF</span>
                </button>
                <button
                  type="button"
                  onClick={() => setPreviewCert(null)}
                  aria-label="إغلاق المعاينة"
                  className="p-2 text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white rounded-lg cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            <div className="p-4 sm:p-6 bg-slate-100 dark:bg-slate-950 flex items-center justify-center">
              <canvas
                ref={previewCanvasRef}
                className="w-full max-w-[780px] aspect-[1754/1240] rounded-lg shadow-lg border border-slate-300 dark:border-slate-700 bg-white"
              />
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
