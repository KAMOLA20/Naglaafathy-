import { useEffect, useMemo, useRef, useState } from 'react';
import { MessageCircle, MessageSquare, Phone, Send, X } from 'lucide-react';
import { useAcademy } from '../context/AcademyContext.tsx';

export function formatWhatsappHref(phoneRaw: string): string {
  const digits = phoneRaw.replace(/\D/g, '');
  if (!digits) return 'https://wa.me/201029121467';
  const normalized = digits.startsWith('20')
    ? digits
    : digits.startsWith('0')
      ? `2${digits}`
      : `20${digits}`;
  return `https://wa.me/${normalized}`;
}

export function formatPhoneDigits(phoneRaw: string): string {
  const digits = phoneRaw.replace(/\D/g, '');
  return digits || '01029121467';
}

export function SupportChatDrawer() {
  const {
    snapshot,
    currentStudent,
    chatMessages,
    activeChatThreadId,
    isChatOpen,
    setIsChatOpen,
    unreadChatCount,
    sendChatMessage,
  } = useAcademy();

  const hotline = snapshot?.profile.hotline || '01029121467';
  const phoneDigits = formatPhoneDigits(hotline);
  const whatsappUrl = formatWhatsappHref(hotline);

  const [guestName, setGuestName] = useState(() => {
    if (typeof window === 'undefined') return '';
    return localStorage.getItem('qema_guest_chat_name_v1') || '';
  });
  const [guestPhone, setGuestPhone] = useState(() => {
    if (typeof window === 'undefined') return '';
    return localStorage.getItem('qema_guest_chat_phone_v1') || '';
  });
  const [draft, setDraft] = useState('');
  const [sending, setSending] = useState(false);

  const scrollEndRef = useRef<HTMLDivElement | null>(null);

  const threadMessages = useMemo(
    () => chatMessages.filter((m) => m.threadId === activeChatThreadId),
    [chatMessages, activeChatThreadId]
  );

  useEffect(() => {
    if (isChatOpen) {
      scrollEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [isChatOpen, threadMessages.length]);

  const handleGuestNameChange = (value: string) => {
    setGuestName(value);
    localStorage.setItem('qema_guest_chat_name_v1', value);
  };

  const handleGuestPhoneChange = (value: string) => {
    setGuestPhone(value);
    localStorage.setItem('qema_guest_chat_phone_v1', value);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const text = draft.trim();
    if (!text || sending) return;
    setSending(true);
    try {
      const ok = await sendChatMessage({
        threadId: activeChatThreadId,
        senderRole: 'student',
        senderName: currentStudent?.name || guestName.trim() || 'ولي أمر / زائر',
        senderPhone: currentStudent?.phone || guestPhone.trim() || undefined,
        text,
      });
      if (ok) {
        setDraft('');
      }
    } finally {
      setSending(false);
    }
  };

  const formatTime = (iso: string) => {
    try {
      return new Intl.DateTimeFormat('ar-EG', {
        hour: '2-digit',
        minute: '2-digit',
      }).format(new Date(iso));
    } catch {
      return '';
    }
  };

  if (!isChatOpen) {
    return (
      <div className="fixed bottom-5 left-5 z-40 flex items-center gap-2">
        <a
          href={whatsappUrl}
          target="_blank"
          rel="noopener noreferrer"
          aria-label={`تواصل واتساب على ${hotline}`}
          className="inline-flex items-center gap-1.5 px-4 py-3 min-h-[44px] bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-bold rounded-xl shadow-lg transition-colors whitespace-nowrap"
        >
          <MessageCircle className="w-4 h-4 shrink-0" />
          <span className="hidden sm:inline">واتساب</span>
          <span className="font-mono tabular-nums" dir="ltr">
            {hotline}
          </span>
        </a>

        <button
          type="button"
          onClick={() => setIsChatOpen(true)}
          className="inline-flex items-center gap-2 px-4 py-3 min-h-[44px] bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold rounded-xl shadow-lg transition-colors whitespace-nowrap cursor-pointer"
        >
          <MessageSquare className="w-4 h-4 shrink-0" />
          <span>محادثة داخل الموقع</span>
          {unreadChatCount > 0 && (
            <span className="px-1.5 py-0.5 bg-amber-400 text-slate-950 text-[11px] font-extrabold rounded-md font-mono tabular-nums">
              {unreadChatCount}
            </span>
          )}
        </button>
      </div>
    );
  }

  return (
    <section
      aria-label="المحادثة المباشرة داخل المنصة"
      className="fixed bottom-5 left-5 z-50 w-[calc(100vw-2.5rem)] max-w-sm bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[84vh]"
    >
      {/* Header */}
      <div className="bg-slate-900 dark:bg-slate-950 text-white px-4 py-3.5 flex items-center justify-between gap-2 border-b border-transparent dark:border-slate-800">
        <div>
          <h2 className="text-sm font-extrabold font-display">المحادثة المباشرة داخل المنصة</h2>
          <p className="text-[11px] text-slate-300 mt-0.5">
            تواصل مباشر مع إدارة {snapshot?.profile.teacherName || 'الأستاذة نجلاء فتحي'}
          </p>
        </div>
        <button
          type="button"
          onClick={() => setIsChatOpen(false)}
          aria-label="إغلاق نافذة المحادثة"
          className="p-2 rounded-lg text-slate-300 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      {/* Direct Call & WhatsApp Bar */}
      <div className="bg-emerald-50 dark:bg-emerald-950/60 border-b border-emerald-200 dark:border-emerald-800 px-4 py-2.5 flex items-center justify-between gap-2 text-xs">
        <a
          href={`tel:${phoneDigits}`}
          className="inline-flex items-center gap-1.5 font-bold text-slate-900 dark:text-slate-100 hover:text-blue-700 dark:hover:text-blue-400 transition-colors"
        >
          <Phone className="w-3.5 h-3.5 text-blue-700 dark:text-blue-400 shrink-0" />
          <span>اتصال:</span>
          <span className="font-mono tabular-nums" dir="ltr">
            {hotline}
          </span>
        </a>

        <a
          href={whatsappUrl}
          target="_blank"
          rel="noopener noreferrer"
          className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-emerald-700 hover:bg-emerald-800 text-white font-bold rounded-lg transition-colors whitespace-nowrap"
        >
          <MessageCircle className="w-3.5 h-3.5 shrink-0" />
          <span>واتساب مباشر</span>
        </a>
      </div>

      {/* Visitor identity inputs if not signed in */}
      {!currentStudent && (
        <div className="px-4 py-2.5 bg-slate-50 dark:bg-slate-800/70 border-b border-slate-200 dark:border-slate-800 grid grid-cols-2 gap-2">
          <input
            type="text"
            value={guestName}
            onChange={(e) => handleGuestNameChange(e.target.value)}
            placeholder="اسم الطالب / ولي الأمر"
            className="px-2.5 py-1.5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs text-slate-900 dark:text-slate-100"
          />
          <input
            type="tel"
            dir="ltr"
            value={guestPhone}
            onChange={(e) => handleGuestPhoneChange(e.target.value)}
            placeholder="رقم الهاتف / الواتس"
            className="px-2.5 py-1.5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-xs font-mono text-slate-900 dark:text-slate-100"
          />
        </div>
      )}

      {/* Messages Thread */}
      <div className="flex-1 overflow-y-auto p-4 space-y-3 bg-slate-50 dark:bg-slate-950 min-h-[220px] max-h-[340px]">
        {threadMessages.length === 0 ? (
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-4 text-xs text-slate-600 dark:text-slate-300 leading-relaxed space-y-1.5">
            <p className="font-bold text-slate-900 dark:text-slate-100">أهلاً بكم في {snapshot?.profile.platformName || 'منصة الأستاذة نجلاء فتحي'}</p>
            <p>
              اكتب استفسارك عن الكورسات الشهرية أو تأسيس رياض الأطفال أو الدفع عبر فوري باي، وستصل رسالتك مباشرة إلى لوحة المعلم للرد عليك.
            </p>
            <p className="text-emerald-800 dark:text-emerald-400 font-semibold">
              للتواصل الفوري هاتفياً أو واتساب: <span className="font-mono tabular-nums" dir="ltr">{hotline}</span>
            </p>
          </div>
        ) : (
          threadMessages.map((msg) => {
            const isTeacher = msg.senderRole === 'teacher';
            return (
              <div
                key={msg.id}
                className={`flex flex-col ${isTeacher ? 'items-start' : 'items-end'}`}
              >
                <div
                  className={`max-w-[85%] rounded-xl px-3.5 py-2.5 text-xs leading-relaxed ${
                    isTeacher
                      ? 'bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-slate-100'
                      : 'bg-blue-700 text-white'
                  }`}
                >
                  <p className={`text-[11px] font-bold mb-1 ${isTeacher ? 'text-blue-700 dark:text-blue-400' : 'text-blue-100'}`}>
                    {msg.senderName}
                  </p>
                  <p className="whitespace-pre-wrap break-words">{msg.text}</p>
                </div>
                <span className="text-[10px] text-slate-400 dark:text-slate-500 font-mono tabular-nums mt-1 px-1">
                  {formatTime(msg.createdAt)}
                </span>
              </div>
            );
          })
        )}
        <div ref={scrollEndRef} />
      </div>

      {/* Composer */}
      <form
        onSubmit={(e) => void handleSubmit(e)}
        className="p-3 bg-white dark:bg-slate-900 border-t border-slate-200 dark:border-slate-800 flex items-center gap-2"
      >
        <input
          type="text"
          value={draft}
          onChange={(e) => setDraft(e.target.value)}
          placeholder="اكتب رسالتك هنا..."
          maxLength={1000}
          className="flex-1 px-3 py-2 min-h-[42px] bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-slate-100 focus:outline-none focus:border-blue-700"
        />
        <button
          type="submit"
          disabled={!draft.trim() || sending}
          aria-label="إرسال الرسالة"
          className="inline-flex items-center gap-1.5 px-4 py-2 min-h-[42px] bg-blue-700 hover:bg-blue-800 disabled:bg-slate-300 dark:disabled:bg-slate-700 text-white text-xs font-bold rounded-xl transition-colors cursor-pointer shrink-0"
        >
          <Send className="w-3.5 h-3.5" />
          <span>إرسال</span>
        </button>
      </form>
    </section>
  );
}
