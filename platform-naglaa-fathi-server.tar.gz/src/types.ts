export type GradeLevel = 'kg' | 'p1' | 'p2' | 'p3' | 'p4' | 'p5' | 'p6';

export type SubjectBranch =
  | 'arabic'
  | 'math'
  | 'kg_arabic'
  | 'kg_math'
  | 'kg_english'
  | 'kg_discover';

export type AppSection =
  | 'catalog'
  | 'kindergarten'
  | 'classroom'
  | 'interactive-lab'
  | 'honor-roll'
  | 'student'
  | 'admin';

export interface LessonSlide {
  heading: string;
  formula: string;
  note: string;
}

export interface Lesson {
  id: string;
  order: number;
  weekNumber?: number;
  title: string;
  durationMin: number;
  videoSummary: string;
  keyFormulas: string[];
  slides: LessonSlide[];
  handoutTitle: string;
  handoutSummary: string;
  isFreePreview: boolean;
}

export interface ExamQuestion {
  id: string;
  prompt: string;
  formula?: string;
  options: string[];
  correctIndex: number;
  explanation: string;
}

export interface Exam {
  id: string;
  courseId: string;
  title: string;
  durationMin: number;
  passingScore: number;
  questions: ExamQuestion[];
}

export interface Course {
  id: string;
  title: string;
  subtitle: string;
  grade: GradeLevel;
  branch: SubjectBranch;
  monthLabel: string;
  priceEgp: number;
  originalPriceEgp?: number;
  coverImage: string;
  totalHours: number;
  lessons: Lesson[];
  examId: string;
  featured?: boolean;
}

export interface ActivationCode {
  code: string;
  courseId: string;
  status: 'active' | 'used';
  createdAt: string;
  usedByStudentId?: string;
  usedByStudentName?: string;
  usedAt?: string;
}

export type TopupMethod = 'vodafone_cash' | 'instapay' | 'fawry';

export interface WalletRequest {
  id: string;
  studentId: string;
  studentName: string;
  studentPhone: string;
  amountEgp: number;
  method: TopupMethod;
  referenceNumber: string;
  status: 'pending' | 'approved' | 'rejected';
  createdAt: string;
}

export interface ExamAttempt {
  id: string;
  examId: string;
  courseId: string;
  studentId: string;
  studentName: string;
  score: number;
  total: number;
  percentage: number;
  passed: boolean;
  answers: number[];
  submittedAt: string;
}

export interface Student {
  id: string;
  name: string;
  phone: string;
  parentPhone: string;
  governorate: string;
  grade: GradeLevel;
  walletBalance: number;
  enrolledCourseIds: string[];
  completedLessonIds: string[];
  totalWatchMinutes: number;
  points: number;
  createdAt: string;
}

export interface Announcement {
  id: string;
  title: string;
  body: string;
  grade: GradeLevel | 'all';
  createdAt: string;
}

export interface AcademyProfile {
  platformName: string;
  teacherName: string;
  teacherTitle: string;
  teacherBio: string;
  hotline: string;
  academicYear: string;
}

export interface FawryOrder {
  id: string;
  referenceNumber: string;
  studentId: string;
  studentName: string;
  studentPhone: string;
  purpose: 'course' | 'wallet';
  courseId?: string;
  courseTitle?: string;
  amountEgp: number;
  status: 'UNPAID' | 'PAID' | 'EXPIRED' | 'FAILED';
  mode: 'live' | 'sandbox';
  expiresAt: string;
  createdAt: string;
  paidAt?: string;
}

export interface FawryStatus {
  configured: boolean;
  mode: 'live' | 'sandbox';
  merchantCodeMasked?: string;
}

export interface Certificate {
  id: string;
  certificateNumber: string;
  studentId: string;
  studentName: string;
  courseId: string;
  courseTitle: string;
  grade: GradeLevel;
  branch: SubjectBranch;
  monthLabel: string;
  completedLessonsCount: number;
  totalLessonsCount: number;
  teacherName: string;
  platformName: string;
  issuedAt: string;
}

export interface LessonAttendance {
  id: string;
  studentId: string;
  courseId: string;
  lessonId: string;
  watchedPercent: number;
  watchedSeconds: number;
  lastPositionSec?: number;
  lastSceneIndex?: number;
  checkedIn: boolean;
  fullyWatched: boolean;
  firstAttendedAt: string;
  lastActivityAt: string;
  completedAt?: string;
}

export interface ChatMessage {
  id: string;
  threadId: string;
  senderRole: 'student' | 'teacher';
  senderName: string;
  senderPhone?: string;
  text: string;
  createdAt: string;
}

export interface LiveLectureSchedule {
  id: string;
  courseId: string;
  courseTitle: string;
  lessonId?: string;
  lessonTitle: string;
  grade: GradeLevel;
  branch: SubjectBranch;
  teacherName: string;
  scheduledAt: string;
  durationMin: number;
  remindBeforeMin: number;
  note?: string;
  createdAt: string;
}

export interface LecturePushEvent {
  id: string;
  scheduleId: string;
  courseId: string;
  courseTitle: string;
  lessonTitle: string;
  grade: GradeLevel;
  scheduledAt: string;
  title: string;
  body: string;
  pushedAt: string;
}

export interface LessonReview {
  id: string;
  studentId: string;
  studentName: string;
  courseId: string;
  courseTitle: string;
  lessonId: string;
  lessonTitle: string;
  grade: GradeLevel;
  branch: SubjectBranch;
  audioRating: number;
  contentRating: number;
  overallRating: number;
  comment: string;
  createdAt: string;
  updatedAt?: string;
}

export interface TeacherPayoutSettings {
  autoTransferEnabled: boolean;
  destinationMethod: TopupMethod;
  destinationPhone: string;
  destinationLabel: string;
}

export interface TeacherWalletTransaction {
  id: string;
  type: 'student_payment' | 'auto_payout' | 'manual_payout';
  amountEgp: number;
  sourceMethod: 'fawry' | 'student_wallet' | 'vodafone_cash' | 'instapay';
  studentId?: string;
  studentName?: string;
  courseId?: string;
  courseTitle?: string;
  destinationPhone?: string;
  referenceNumber: string;
  status: 'credited' | 'transferred';
  note: string;
  createdAt: string;
}

export interface AcademySnapshot {
  profile: AcademyProfile;
  courses: Course[];
  exams: Exam[];
  students: Student[];
  activationCodes: ActivationCode[];
  walletRequests: WalletRequest[];
  examAttempts: ExamAttempt[];
  announcements: Announcement[];
  fawryOrders: FawryOrder[];
  fawryStatus: FawryStatus;
  certificates: Certificate[];
  attendances: LessonAttendance[];
  chatMessages: ChatMessage[];
  lectureSchedules: LiveLectureSchedule[];
  lessonReviews: LessonReview[];
  teacherWalletBalance: number;
  teacherTotalCollectedEgp: number;
  teacherTotalTransferredEgp: number;
  payoutSettings: TeacherPayoutSettings;
  teacherTransactions: TeacherWalletTransaction[];
}
