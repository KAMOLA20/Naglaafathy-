import { useEffect, useMemo, useState } from 'react';
import { Bar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import {
  ArrowDownLeft,
  ArrowUpRight,
  BellRing,
  Check,
  Copy,
  Download,
  Globe,
  HardDriveDownload,
  MessageCircle,
  Phone,
  Plus,
  RotateCcw,
  Send,
  Star,
  Trash2,
  Wallet,
  X,
} from 'lucide-react';
import { AcademyEmblem } from './BrandLogo.tsx';
import { useAcademy } from '../context/AcademyContext.tsx';
import type { ChatMessage, GradeLevel, SubjectBranch, TopupMethod } from '../types.ts';
import {
  BRANCH_LABELS,
  formatArabicDateTime,
  formatEgp,
  GRADE_LABELS,
  GRADE_SHORT_LABELS,
  TOPUP_METHOD_LABELS,
} from '../utils/academy.ts';
import { formatPhoneDigits, formatWhatsappHref } from './SupportChatDrawer.tsx';

type AdminTab = 'courses' | 'schedules' | 'reviews' | 'codes' | 'wallet' | 'chat' | 'students' | 'settings';

export function TeacherDashboard() {
  const {
    snapshot,
    generateCodes,
    resolveWalletRequest,
    createCourse,
    addLesson,
    publishAnnouncement,
    updateProfile,
    resetAcademy,
    showToast,
    chatMessages,
    sendChatMessage,
    lectureSchedules,
    createLectureSchedule,
    pushLectureReminderNow,
    deleteLectureSchedule,
    updatePayoutSettings,
    transferTeacherWalletNow,
  } = useAcademy();

  const [activeTab, setActiveTab] = useState<AdminTab>('courses');

  // New Course State
  const [courseTitle, setCourseTitle] = useState('');
  const [courseSubtitle, setCourseSubtitle] = useState('');
  const [courseGrade, setCourseGrade] = useState<GradeLevel>('p4');
  const [courseBranch, setCourseBranch] = useState<SubjectBranch>('arabic');
  const [courseMonth, setCourseMonth] = useState('الشهر الأول');
  const [coursePrice, setCoursePrice] = useState('160');
  const [courseHours, setCourseHours] = useState('10');
  const [firstLessonTitle, setFirstLessonTitle] = useState('');

  // Add Lesson State
  const [lessonCourseId, setLessonCourseId] = useState(snapshot?.courses[0]?.id || 'crs-p4-ar');
  const [lessonTitle, setLessonTitle] = useState('');
  const [lessonDuration, setLessonDuration] = useState('45');
  const [lessonFormula, setLessonFormula] = useState('');
  const [lessonSummary, setLessonSummary] = useState('');
  const [lessonFree, setLessonFree] = useState(false);

  // Code Generator State
  const [codeCourseId, setCodeCourseId] = useState('ALL');
  const [codeCount, setCodeCount] = useState(5);
  const [copiedCode, setCopiedCode] = useState<string | null>(null);

  // Student search
  const [studentQuery, setStudentQuery] = useState('');

  // Settings & Announcement State
  const [annTitle, setAnnTitle] = useState('');
  const [annBody, setAnnBody] = useState('');
  const [annGrade, setAnnGrade] = useState<GradeLevel | 'all'>('all');

  const [profName, setProfName] = useState(snapshot?.profile.platformName || 'منصة الأستاذة نجلاء فتحي');
  const [profTeacher, setProfTeacher] = useState(snapshot?.profile.teacherName || 'الأستاذة نجلاء فتحي');
  const [profTitle, setProfTitle] = useState(snapshot?.profile.teacherTitle || '');
  const [profBio, setProfBio] = useState(snapshot?.profile.teacherBio || '');
  const [profHotline, setProfHotline] = useState(snapshot?.profile.hotline || '01029121467');

  // In-site Live Chat Inbox State
  const [selectedThreadId, setSelectedThreadId] = useState<string | null>(null);
  const [teacherReply, setTeacherReply] = useState('');
  const [sendingReply, setSendingReply] = useState(false);

  // Upcoming Lecture Schedule & Push Notification State
  const [schCourseId, setSchCourseId] = useState(snapshot?.courses[0]?.id || 'crs-p4-ar');
  const [schLessonTitle, setSchLessonTitle] = useState('');
  const [schStartsInMin, setSchStartsInMin] = useState('10');
  const [schRemindMin, setSchRemindMin] = useState('15');
  const [schNote, setSchNote] = useState('');
  const [schPushNow, setSchPushNow] = useState(true);
  const [reviewCourseFilter, setReviewCourseFilter] = useState<string>('all');

  // Instant Teacher Wallet Payout State
  const [payoutAuto, setPayoutAuto] = useState<boolean>(
    snapshot?.payoutSettings?.autoTransferEnabled ?? true
  );
  const [payoutMethod, setPayoutMethod] = useState<TopupMethod>(
    snapshot?.payoutSettings?.destinationMethod || 'vodafone_cash'
  );
  const [payoutPhone, setPayoutPhone] = useState<string>(
    snapshot?.payoutSettings?.destinationPhone || '01029121467'
  );
  const [payoutLabel, setPayoutLabel] = useState<string>(
    snapshot?.payoutSettings?.destinationLabel || 'محفظة الأستاذة نجلاء فتحي'
  );
  const [savingPayout, setSavingPayout] = useState(false);
  const [embedOrigin, setEmbedOrigin] = useState<string>(() =>
    typeof window !== 'undefined'
      ? window.location.origin
      : 'https://ais-pre-kpzrcgz2rkdojvesw72oll-286129243002.europe-west2.run.app'
  );
  const [copiedOdoo, setCopiedOdoo] = useState(false);
  const [downloadingFile, setDownloadingFile] = useState<'bundle' | 'odoo' | 'logo' | 'backup' | null>(null);

  const sanitizedEmbedUrl = (embedOrigin || 'https://ais-dev-kpzrcgz2rkdojvesw72oll-286129243002.europe-west2.run.app')
    .trim()
    .replace(/\/+$/, '');
  const odooEmbedSnippet = `<iframe src="${sanitizedEmbedUrl}" width="100%" height="900" style="border:0;border-radius:16px;overflow:hidden;" allow="clipboard-write; autoplay" loading="lazy" title="منصة الأستاذة نجلاء فتحي"></iframe>`;

  const handleCopyOdooEmbed = async () => {
    try {
      await navigator.clipboard.writeText(odooEmbedSnippet);
      setCopiedOdoo(true);
      showToast('success', 'تم نسخ كود التضمين HTML الجاهز لموقع Odoo');
      setTimeout(() => setCopiedOdoo(false), 2200);
    } catch {
      try {
        const ta = document.createElement('textarea');
        ta.value = odooEmbedSnippet;
        ta.style.position = 'fixed';
        ta.style.opacity = '0';
        document.body.appendChild(ta);
        ta.focus();
        ta.select();
        const ok = document.execCommand('copy');
        document.body.removeChild(ta);
        if (ok) {
          setCopiedOdoo(true);
          showToast('success', 'تم نسخ كود التضمين HTML الجاهز لموقع Odoo');
          setTimeout(() => setCopiedOdoo(false), 2200);
          return;
        }
      } catch {
        // fall through to manual prompt
      }
      showToast('error', 'اضغط داخل مربع الكود واختر تحديد الكل ثم نسخ (Ctrl+C)');
    }
  };

  const triggerBlobDownload = async (
    key: 'bundle' | 'odoo' | 'logo' | 'backup',
    endpoint: string,
    filename: string,
    label: string
  ) => {
    setDownloadingFile(key);
    try {
      const res = await fetch(endpoint);
      if (!res.ok) {
        throw new Error(`HTTP ${res.status}`);
      }
      const blob = await res.blob();
      const blobUrl = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = blobUrl;
      link.download = filename;
      link.style.display = 'none';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      setTimeout(() => URL.revokeObjectURL(blobUrl), 5000);
      showToast('success', `تم بدء تحميل ${label} (${filename})`);
    } catch {
      showToast('error', `تعذر تحميل ${label} — تأكد من الاتصال وحاول مرة أخرى`);
    } finally {
      setDownloadingFile(null);
    }
  };

  const openExportSection = () => {
    setActiveTab('settings');
    setTimeout(() => {
      const el = document.getElementById('teacher-export-panel');
      if (el) {
        el.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
    }, 60);
  };

  useEffect(() => {
    if (snapshot?.payoutSettings) {
      setPayoutAuto(snapshot.payoutSettings.autoTransferEnabled);
      setPayoutMethod(snapshot.payoutSettings.destinationMethod);
      setPayoutPhone(snapshot.payoutSettings.destinationPhone);
      setPayoutLabel(snapshot.payoutSettings.destinationLabel);
    }
  }, [
    snapshot?.payoutSettings?.autoTransferEnabled,
    snapshot?.payoutSettings?.destinationMethod,
    snapshot?.payoutSettings?.destinationPhone,
    snapshot?.payoutSettings?.destinationLabel,
  ]);

  const courses = snapshot?.courses || [];
  const students = snapshot?.students || [];
  const codes = snapshot?.activationCodes || [];
  const walletRequests = snapshot?.walletRequests || [];
  const fawryOrders = snapshot?.fawryOrders || [];
  const fawryStatus = snapshot?.fawryStatus;
  const attempts = snapshot?.examAttempts || [];
  const lessonReviews = snapshot?.lessonReviews || [];
  const teacherTransactions = snapshot?.teacherTransactions || [];
  const teacherWalletBalance = snapshot?.teacherWalletBalance || 0;
  const teacherTotalCollectedEgp = snapshot?.teacherTotalCollectedEgp || 0;
  const teacherTotalTransferredEgp = snapshot?.teacherTotalTransferredEgp || 0;

  const reviewStats = useMemo(() => {
    const total = lessonReviews.length;
    if (total === 0) {
      return {
        total: 0,
        avgOverall: 0,
        avgAudio: 0,
        avgContent: 0,
        byCourse: [] as {
          courseId: string;
          courseTitle: string;
          grade: GradeLevel;
          count: number;
          avgAudio: number;
          avgContent: number;
          avgOverall: number;
        }[],
        byLesson: [] as {
          lessonId: string;
          lessonTitle: string;
          courseId: string;
          courseTitle: string;
          grade: GradeLevel;
          count: number;
          avgAudio: number;
          avgContent: number;
          avgOverall: number;
        }[],
      };
    }

    const avgOverall = Number(
      (lessonReviews.reduce((s, r) => s + r.overallRating, 0) / total).toFixed(1)
    );
    const avgAudio = Number(
      (lessonReviews.reduce((s, r) => s + r.audioRating, 0) / total).toFixed(1)
    );
    const avgContent = Number(
      (lessonReviews.reduce((s, r) => s + r.contentRating, 0) / total).toFixed(1)
    );

    const groupedByCourse = new Map<string, typeof lessonReviews>();
    const groupedByLesson = new Map<string, typeof lessonReviews>();
    for (const r of lessonReviews) {
      const cArr = groupedByCourse.get(r.courseId) || [];
      cArr.push(r);
      groupedByCourse.set(r.courseId, cArr);

      const lArr = groupedByLesson.get(r.lessonId) || [];
      lArr.push(r);
      groupedByLesson.set(r.lessonId, lArr);
    }

    const byCourse = Array.from(groupedByCourse.entries())
      .map(([courseId, list]) => {
        const count = list.length;
        const first = list[0];
        return {
          courseId,
          courseTitle: first.courseTitle,
          grade: first.grade,
          count,
          avgAudio: Number((list.reduce((s, r) => s + r.audioRating, 0) / count).toFixed(1)),
          avgContent: Number((list.reduce((s, r) => s + r.contentRating, 0) / count).toFixed(1)),
          avgOverall: Number((list.reduce((s, r) => s + r.overallRating, 0) / count).toFixed(1)),
        };
      })
      .sort((a, b) => b.avgOverall - a.avgOverall || b.count - a.count);

    const byLesson = Array.from(groupedByLesson.entries())
      .map(([lessonId, list]) => {
        const count = list.length;
        const first = list[0];
        return {
          lessonId,
          lessonTitle: first.lessonTitle,
          courseId: first.courseId,
          courseTitle: first.courseTitle,
          grade: first.grade,
          count,
          avgAudio: Number((list.reduce((s, r) => s + r.audioRating, 0) / count).toFixed(1)),
          avgContent: Number((list.reduce((s, r) => s + r.contentRating, 0) / count).toFixed(1)),
          avgOverall: Number((list.reduce((s, r) => s + r.overallRating, 0) / count).toFixed(1)),
        };
      })
      .sort((a, b) => b.avgOverall - a.avgOverall || b.count - a.count);

    return { total, avgOverall, avgAudio, avgContent, byCourse, byLesson };
  }, [lessonReviews]);

  const filteredReviews = useMemo(() => {
    const list =
      reviewCourseFilter === 'all'
        ? lessonReviews
        : lessonReviews.filter((r) => r.courseId === reviewCourseFilter);
    return [...list].sort((a, b) =>
      (b.updatedAt || b.createdAt).localeCompare(a.updatedAt || a.createdAt)
    );
  }, [lessonReviews, reviewCourseFilter]);

  const pendingWalletCount = walletRequests.filter((w) => w.status === 'pending').length;
  const activeCodesCount = codes.filter((c) => c.status === 'active').length;
  const fawryPaidTotal = fawryOrders
    .filter((o) => o.status === 'PAID')
    .reduce((sum, o) => sum + o.amountEgp, 0);

  const enrollmentChartData = useMemo(() => {
    return courses.map((c) => {
      const enrolledCount = students.filter(
        (s) => c.priceEgp === 0 || s.enrolledCourseIds.includes(c.id)
      ).length;
      return {
        name: c.monthLabel,
        طلاب: enrolledCount,
      };
    });
  }, [courses, students]);

  const filteredStudents = useMemo(() => {
    const q = studentQuery.trim().toLowerCase();
    if (!q) return students;
    return students.filter(
      (s) =>
        s.name.toLowerCase().includes(q) ||
        s.phone.includes(q) ||
        s.governorate.toLowerCase().includes(q)
    );
  }, [students, studentQuery]);

  const chatThreads = useMemo(() => {
    const grouped = new Map<string, ChatMessage[]>();
    for (const msg of chatMessages) {
      const list = grouped.get(msg.threadId) || [];
      list.push(msg);
      grouped.set(msg.threadId, list);
    }

    return Array.from(grouped.entries())
      .map(([threadId, msgs]) => {
        const sorted = [...msgs].sort((a, b) => a.createdAt.localeCompare(b.createdAt));
        const lastMessage = sorted[sorted.length - 1];
        const studentMsg = [...sorted].reverse().find((m) => m.senderRole === 'student');
        const linkedStudent = threadId.startsWith('student:')
          ? students.find((s) => s.id === threadId.replace('student:', ''))
          : undefined;
        return {
          threadId,
          displayName: linkedStudent?.name || studentMsg?.senderName || 'طالب / ولي أمر',
          phone: linkedStudent?.phone || studentMsg?.senderPhone || '',
          gradeLabel: linkedStudent ? GRADE_SHORT_LABELS[linkedStudent.grade] : 'زائر',
          messages: sorted,
          lastMessage,
        };
      })
      .sort((a, b) => b.lastMessage.createdAt.localeCompare(a.lastMessage.createdAt));
  }, [chatMessages, students]);

  const activeThread = useMemo(() => {
    if (chatThreads.length === 0) return null;
    return chatThreads.find((t) => t.threadId === selectedThreadId) || chatThreads[0];
  }, [chatThreads, selectedThreadId]);

  const handleCopyCode = async (code: string) => {
    try {
      await navigator.clipboard.writeText(code);
      setCopiedCode(code);
      showToast('success', `تم نسخ الكود ${code}`);
      setTimeout(() => setCopiedCode(null), 1500);
    } catch {
      // ignore
    }
  };

  const handleCreateCourse = async (e: React.FormEvent) => {
    e.preventDefault();
    const ok = await createCourse({
      title: courseTitle,
      subtitle: courseSubtitle,
      grade: courseGrade,
      branch: courseBranch,
      monthLabel: courseMonth,
      priceEgp: Number(coursePrice),
      totalHours: Number(courseHours),
      firstLessonTitle,
    });
    if (ok) {
      setCourseTitle('');
      setCourseSubtitle('');
      setFirstLessonTitle('');
    }
  };

  const handleAddLesson = async (e: React.FormEvent) => {
    e.preventDefault();
    const ok = await addLesson(lessonCourseId, {
      title: lessonTitle,
      durationMin: Number(lessonDuration),
      videoSummary: lessonSummary,
      formula: lessonFormula,
      isFreePreview: lessonFree,
    });
    if (ok) {
      setLessonTitle('');
      setLessonFormula('');
      setLessonSummary('');
      setLessonFree(false);
    }
  };

  const handlePublishAnnouncement = async (e: React.FormEvent) => {
    e.preventDefault();
    const ok = await publishAnnouncement({ title: annTitle, body: annBody, grade: annGrade });
    if (ok) {
      setAnnTitle('');
      setAnnBody('');
    }
  };

  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    await updateProfile({
      platformName: profName,
      teacherName: profTeacher,
      teacherTitle: profTitle,
      teacherBio: profBio,
      hotline: profHotline,
    });
  };

  const handleSendTeacherReply = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeThread || !teacherReply.trim() || sendingReply) return;
    setSendingReply(true);
    try {
      const ok = await sendChatMessage({
        threadId: activeThread.threadId,
        senderRole: 'teacher',
        senderName: snapshot?.profile.teacherName || 'الأستاذة نجلاء فتحي',
        text: teacherReply.trim(),
      });
      if (ok) {
        setTeacherReply('');
      }
    } finally {
      setSendingReply(false);
    }
  };

  const handleCreateSchedule = async (e: React.FormEvent) => {
    e.preventDefault();
    const ok = await createLectureSchedule({
      courseId: schCourseId,
      lessonTitle: schLessonTitle.trim() || undefined,
      startsInMinutes: Number(schStartsInMin || 15),
      remindBeforeMin: Number(schRemindMin || 15),
      note: schNote.trim() || undefined,
      pushNow: schPushNow,
    });
    if (ok) {
      setSchLessonTitle('');
      setSchNote('');
    }
  };

  const handleSavePayoutSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    setSavingPayout(true);
    try {
      await updatePayoutSettings({
        autoTransferEnabled: payoutAuto,
        destinationMethod: payoutMethod,
        destinationPhone: payoutPhone,
        destinationLabel: payoutLabel,
      });
    } finally {
      setSavingPayout(false);
    }
  };

  const tabs: { id: AdminTab; label: string }[] = [
    { id: 'courses', label: 'الكورسات والمحاضرات' },
    { id: 'schedules', label: `مواعيد المحاضرات والتنبيهات (${lectureSchedules.length})` },
    {
      id: 'reviews',
      label: `تقييمات الدروس (${reviewStats.total > 0 ? `${reviewStats.avgOverall} ★` : '0'})`,
    },
    { id: 'codes', label: `أكواد التفعيل (${activeCodesCount})` },
    { id: 'wallet', label: `المحفظة والتحويل الفوري (${formatEgp(teacherTotalTransferredEgp)})` },
    { id: 'chat', label: `المحادثات المباشرة (${chatThreads.length})` },
    { id: 'students', label: `الطلاب والدرجات (${students.length})` },
    { id: 'settings', label: 'الإعدادات وملف السيرفر' },
  ];

  return (
    <div className="space-y-6 pb-10">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 border-b border-slate-200 dark:border-slate-800 pb-4">
        <div>
          <p className="text-xs font-semibold text-blue-700 dark:text-blue-400">إدارة المحتوى والأكواد والتحويلات</p>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-slate-100 font-display mt-1">
            لوحة تحكم المعلم والإدارة
          </h1>
        </div>

        <div className="flex flex-wrap items-center gap-2 shrink-0">
          <button
            type="button"
            onClick={openExportSection}
            className="inline-flex items-center gap-1.5 px-4 py-2 min-h-[40px] bg-amber-400 hover:bg-amber-300 text-slate-950 text-xs font-extrabold rounded-xl transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            <HardDriveDownload className="w-3.5 h-3.5" />
            <span>تحميل ملف السيرفر وربط Odoo</span>
          </button>

          <button
            type="button"
            onClick={() => void resetAcademy()}
            className="inline-flex items-center gap-1.5 px-4 py-2 min-h-[40px] bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-100 text-xs font-semibold rounded-xl transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>استعادة البيانات الافتراضية</span>
          </button>
        </div>
      </div>

      {/* 5-Column Operations KPIs */}
      <div className="grid grid-cols-2 lg:grid-cols-5 gap-4">
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5">
          <p className="text-xs text-slate-500 dark:text-slate-400">إجمالي الطلاب المسجلين</p>
          <p className="text-2xl font-extrabold text-slate-900 dark:text-slate-100 font-mono tabular-nums mt-1">
            {students.length}
          </p>
        </div>
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5">
          <p className="text-xs text-slate-500 dark:text-slate-400">إجمالي المحوّل لمحفظة المعلم</p>
          <p className="text-2xl font-extrabold text-emerald-700 dark:text-emerald-400 font-mono tabular-nums mt-1">
            {formatEgp(teacherTotalTransferredEgp)}
          </p>
        </div>
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5">
          <p className="text-xs text-slate-500 dark:text-slate-400">متوسط تقييم الدروس</p>
          <p className="text-2xl font-extrabold text-amber-600 dark:text-amber-400 font-mono tabular-nums mt-1 flex items-center gap-1.5">
            <Star className="w-5 h-5 fill-amber-400 text-amber-500 shrink-0" />
            <span>{reviewStats.total > 0 ? `${reviewStats.avgOverall} / 5` : '—'}</span>
          </p>
          <p className="text-[11px] text-slate-500 dark:text-slate-400 tabular-nums mt-0.5">
            من {reviewStats.total} تقييم
          </p>
        </div>
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5">
          <p className="text-xs text-slate-500 dark:text-slate-400">أكواد تفعيل متاحة</p>
          <p className="text-2xl font-extrabold text-blue-700 dark:text-blue-400 font-mono tabular-nums mt-1">
            {activeCodesCount}
          </p>
        </div>
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5">
          <p className="text-xs text-slate-500 dark:text-slate-400">طلبات شحن قيد المراجعة</p>
          <p className="text-2xl font-extrabold text-amber-600 dark:text-amber-400 font-mono tabular-nums mt-1">
            {pendingWalletCount}
          </p>
        </div>
      </div>

      {/* Enrollment Distribution Chart */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 space-y-3">
        <div className="flex items-center justify-between">
          <h2 className="text-sm font-bold text-slate-900 dark:text-slate-100">توزيع اشتراكات الطلاب حسب الكورسات</h2>
          <span className="text-xs text-slate-500 dark:text-slate-400">تحديث مباشر</span>
        </div>
        <div className="h-52 w-full" dir="ltr">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={enrollmentChartData} margin={{ top: 10, right: 16, left: 0, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#94a3b8" strokeOpacity={0.25} />
              <XAxis dataKey="name" tick={{ fontSize: 11, fill: '#64748b' }} />
              <YAxis allowDecimals={false} tick={{ fontSize: 11, fill: '#64748b' }} />
              <Tooltip />
              <Bar dataKey="طلاب" fill="#1d4ed8" radius={[6, 6, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Workspace Tabs */}
      <div className="flex items-center gap-1 p-1 bg-slate-100 dark:bg-slate-900 border border-transparent dark:border-slate-800 rounded-xl overflow-x-auto">
        {tabs.map((tab) => {
          const active = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              type="button"
              onClick={() => setActiveTab(tab.id)}
              className={`px-4 py-2 text-xs font-semibold rounded-lg whitespace-nowrap shrink-0 transition-colors cursor-pointer ${
                active
                  ? 'bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100 shadow-sm'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-100'
              }`}
            >
              {tab.label}
            </button>
          );
        })}
      </div>

      {/* Tab 1: Courses & Lessons Management */}
      {activeTab === 'courses' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <form
            onSubmit={(e) => void handleCreateCourse(e)}
            className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 space-y-4"
          >
            <h2 className="text-base font-bold text-slate-900 dark:text-slate-100 font-display">إضافة كورس جديد</h2>

            <label className="block space-y-1">
              <span className="text-xs font-semibold text-slate-700 dark:text-slate-300">عنوان الكورس</span>
              <input
                type="text"
                value={courseTitle}
                onChange={(e) => setCourseTitle(e.target.value)}
                placeholder="مثال: مراجعة ليلة الامتحان — تفاضل"
                className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-sm text-slate-900 dark:text-slate-100"
              />
            </label>

            <label className="block space-y-1">
              <span className="text-xs font-semibold text-slate-700 dark:text-slate-300">وصف مختصر</span>
              <textarea
                rows={2}
                value={courseSubtitle}
                onChange={(e) => setCourseSubtitle(e.target.value)}
                placeholder="محاور الشرح والتدريب داخل الكورس"
                className="w-full px-3.5 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-sm text-slate-900 dark:text-slate-100"
              />
            </label>

            <div className="grid grid-cols-2 gap-3">
              <label className="block space-y-1">
                <span className="text-xs font-semibold text-slate-700 dark:text-slate-300">الصف الدراسي</span>
                <select
                  value={courseGrade}
                  onChange={(e) => setCourseGrade(e.target.value as GradeLevel)}
                  className="w-full px-3 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-semibold text-slate-900 dark:text-slate-100"
                >
                  {Object.entries(GRADE_LABELS).map(([k, v]) => (
                    <option key={k} value={k}>
                      {v}
                    </option>
                  ))}
                </select>
              </label>

              <label className="block space-y-1">
                <span className="text-xs font-semibold text-slate-700 dark:text-slate-300">الفرع</span>
                <select
                  value={courseBranch}
                  onChange={(e) => setCourseBranch(e.target.value as SubjectBranch)}
                  className="w-full px-3 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-semibold text-slate-900 dark:text-slate-100"
                >
                  {Object.entries(BRANCH_LABELS).map(([k, v]) => (
                    <option key={k} value={k}>
                      {v}
                    </option>
                  ))}
                </select>
              </label>
            </div>

            <div className="grid grid-cols-3 gap-3">
              <label className="block space-y-1">
                <span className="text-xs font-semibold text-slate-700 dark:text-slate-300">تسمية الشهر</span>
                <input
                  type="text"
                  value={courseMonth}
                  onChange={(e) => setCourseMonth(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-slate-100"
                />
              </label>
              <label className="block space-y-1">
                <span className="text-xs font-semibold text-slate-700 dark:text-slate-300">السعر (ج.م)</span>
                <input
                  type="number"
                  dir="ltr"
                  value={coursePrice}
                  onChange={(e) => setCoursePrice(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-mono text-slate-900 dark:text-slate-100"
                />
              </label>
              <label className="block space-y-1">
                <span className="text-xs font-semibold text-slate-700 dark:text-slate-300">الساعات</span>
                <input
                  type="number"
                  dir="ltr"
                  value={courseHours}
                  onChange={(e) => setCourseHours(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-mono text-slate-900 dark:text-slate-100"
                />
              </label>
            </div>

            <label className="block space-y-1">
              <span className="text-xs font-semibold text-slate-700 dark:text-slate-300">عنوان المحاضرة الأولى</span>
              <input
                type="text"
                value={firstLessonTitle}
                onChange={(e) => setFirstLessonTitle(e.target.value)}
                placeholder="المحاضرة التمهيدية المفتوحة"
                className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-sm text-slate-900 dark:text-slate-100"
              />
            </label>

            <button
              type="submit"
              className="w-full py-3 bg-blue-700 hover:bg-blue-800 text-white text-xs font-bold rounded-xl flex items-center justify-center gap-1.5 cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>نشر الكورس الجديد</span>
            </button>
          </form>

          <form
            onSubmit={(e) => void handleAddLesson(e)}
            className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 space-y-4"
          >
            <h2 className="text-base font-bold text-slate-900 dark:text-slate-100 font-display">إضافة محاضرة إلى كورس قائم</h2>

            <label className="block space-y-1">
              <span className="text-xs font-semibold text-slate-700 dark:text-slate-300">اختر الكورس</span>
              <select
                value={lessonCourseId}
                onChange={(e) => setLessonCourseId(e.target.value)}
                className="w-full px-3 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-semibold text-slate-900 dark:text-slate-100"
              >
                {courses.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.title} ({GRADE_SHORT_LABELS[c.grade]})
                  </option>
                ))}
              </select>
            </label>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <label className="sm:col-span-2 block space-y-1">
                <span className="text-xs font-semibold text-slate-700 dark:text-slate-300">عنوان المحاضرة</span>
                <input
                  type="text"
                  value={lessonTitle}
                  onChange={(e) => setLessonTitle(e.target.value)}
                  placeholder="مثال: تطبيقات القيم العظمى والصغرى"
                  className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-sm text-slate-900 dark:text-slate-100"
                />
              </label>

              <label className="block space-y-1">
                <span className="text-xs font-semibold text-slate-700 dark:text-slate-300">المدة (دقيقة)</span>
                <input
                  type="number"
                  dir="ltr"
                  value={lessonDuration}
                  onChange={(e) => setLessonDuration(e.target.value)}
                  className="w-full px-3 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-sm font-mono text-slate-900 dark:text-slate-100"
                />
              </label>
            </div>

            <label className="block space-y-1">
              <span className="text-xs font-semibold text-slate-700 dark:text-slate-300">قانون أو معادلة رئيسية على السبورة</span>
              <input
                type="text"
                dir="ltr"
                value={lessonFormula}
                onChange={(e) => setLessonFormula(e.target.value)}
                placeholder="f'(x) = 0  &  f''(x) < 0"
                className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-sm font-mono text-slate-900 dark:text-slate-100"
              />
            </label>

            <label className="block space-y-1">
              <span className="text-xs font-semibold text-slate-700 dark:text-slate-300">ملخص الشرح</span>
              <textarea
                rows={2}
                value={lessonSummary}
                onChange={(e) => setLessonSummary(e.target.value)}
                placeholder="شرح خطوات الحل وتطبيقات الوزارة"
                className="w-full px-3.5 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-sm text-slate-900 dark:text-slate-100"
              />
            </label>

            <label className="inline-flex items-center gap-2 text-xs font-semibold text-slate-700 dark:text-slate-300 cursor-pointer">
              <input
                type="checkbox"
                checked={lessonFree}
                onChange={(e) => setLessonFree(e.target.checked)}
                className="w-4 h-4 accent-blue-700"
              />
              <span>إتاحة هذه المحاضرة كمعاينة مجانية للطلاب</span>
            </label>

            <button
              type="submit"
              className="w-full py-3 bg-slate-900 dark:bg-blue-700 hover:bg-slate-800 dark:hover:bg-blue-800 text-white text-xs font-bold rounded-xl flex items-center justify-center gap-1.5 cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>إضافة المحاضرة للمنهج</span>
            </button>
          </form>
        </div>
      )}

      {/* Tab 2: Activation Code Generator */}
      {activeTab === 'codes' && (
        <div className="space-y-6">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 flex flex-col md:flex-row md:items-end justify-between gap-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 flex-1">
              <label className="block space-y-1">
                <span className="text-xs font-semibold text-slate-700 dark:text-slate-300">تخصيص الكود لكورس</span>
                <select
                  value={codeCourseId}
                  onChange={(e) => setCodeCourseId(e.target.value)}
                  className="w-full px-3 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-semibold text-slate-900 dark:text-slate-100"
                >
                  <option value="ALL">كود شامل (VIP - يفتح كل الكورسات)</option>
                  {courses.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.title}
                    </option>
                  ))}
                </select>
              </label>

              <label className="block space-y-1">
                <span className="text-xs font-semibold text-slate-700 dark:text-slate-300">عدد الأكواد المطلوب إصدارها</span>
                <select
                  value={codeCount}
                  onChange={(e) => setCodeCount(Number(e.target.value))}
                  className="w-full px-3 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-semibold text-slate-900 dark:text-slate-100"
                >
                  <option value={1}>كود واحد (1)</option>
                  <option value={5}>دفعة 5 أكواد</option>
                  <option value={10}>دفعة 10 أكواد</option>
                </select>
              </label>
            </div>

            <button
              type="button"
              onClick={() => void generateCodes(codeCourseId, codeCount)}
              className="px-6 py-2.5 min-h-[42px] bg-blue-700 hover:bg-blue-800 text-white text-xs font-bold rounded-xl whitespace-nowrap shrink-0 cursor-pointer"
            >
              توليد الأكواد الآن
            </button>
          </div>

          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-right text-xs">
                <thead className="bg-slate-50 dark:bg-slate-800/80 text-slate-500 dark:text-slate-400 border-b border-slate-200 dark:border-slate-800">
                  <tr>
                    <th className="py-3 px-4">الكود</th>
                    <th className="py-3 px-4">الكورس المرتبط</th>
                    <th className="py-3 px-4">الحالة</th>
                    <th className="py-3 px-4">المستفيد</th>
                    <th className="py-3 px-4">نسخ</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                  {codes.map((c) => {
                    const crs = courses.find((item) => item.id === c.courseId);
                    return (
                      <tr key={c.code}>
                        <td className="py-3 px-4 font-mono font-bold text-slate-900 dark:text-slate-100">{c.code}</td>
                        <td className="py-3 px-4 text-slate-700 dark:text-slate-300">
                          {c.courseId === 'ALL' ? 'شامل كل الكورسات (VIP)' : crs?.title || c.courseId}
                        </td>
                        <td
                          className={`py-3 px-4 font-semibold ${
                            c.status === 'active' ? 'text-emerald-700 dark:text-emerald-400' : 'text-slate-400 dark:text-slate-500'
                          }`}
                        >
                          {c.status === 'active' ? 'متاح للتفعيل' : 'مستخدم'}
                        </td>
                        <td className="py-3 px-4 text-slate-600 dark:text-slate-400">{c.usedByStudentName || '—'}</td>
                        <td className="py-3 px-4">
                          <button
                            type="button"
                            onClick={() => void handleCopyCode(c.code)}
                            className="inline-flex items-center gap-1 px-2.5 py-1 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-lg text-slate-700 dark:text-slate-200 cursor-pointer"
                          >
                            {copiedCode === c.code ? (
                              <Check className="w-3.5 h-3.5 text-emerald-700 dark:text-emerald-400" />
                            ) : (
                              <Copy className="w-3.5 h-3.5" />
                            )}
                            <span>نسخ</span>
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* Tab 3: Instant Teacher Wallet Transfer + FawryPay + Wallet Top-up Requests */}
      {activeTab === 'wallet' && (
        <div className="space-y-6">
          {/* Teacher Wallet Instant Payout Controls & Balance */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 space-y-5">
            <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 border-b border-slate-100 dark:border-slate-800 pb-4">
              <div className="space-y-1">
                <div className="flex items-center gap-2 text-xs font-bold text-emerald-700 dark:text-emerald-400">
                  <Wallet className="w-4 h-4" />
                  <span>التحويل الفوري لمحفظة المعلم فور دفع الطالب</span>
                </div>
                <h2 className="text-lg font-extrabold text-slate-900 dark:text-slate-100 font-display">
                  محفظة الأستاذة وتحويل الأرباح المباشر
                </h2>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  كل سداد يقوم به الطالب (فوري باي، محفظة، أو شحن معتمد) يُضاف تلقائياً ويُحوَّل فوراً إلى رقم محفظتك عند التفعيل.
                </p>
              </div>

              <div className="flex flex-wrap items-center gap-3">
                <div className="bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-4 py-2.5">
                  <p className="text-[11px] text-slate-500 dark:text-slate-400">إجمالي المدفوعات المحصلة</p>
                  <p className="text-base font-extrabold text-slate-900 dark:text-slate-100 font-mono tabular-nums">
                    {formatEgp(teacherTotalCollectedEgp)}
                  </p>
                </div>
                <div className="bg-emerald-50 dark:bg-emerald-950/50 border border-emerald-200 dark:border-emerald-800 rounded-xl px-4 py-2.5">
                  <p className="text-[11px] text-emerald-700 dark:text-emerald-400">محوّل لمحفظتك فوراً</p>
                  <p className="text-base font-extrabold text-emerald-800 dark:text-emerald-300 font-mono tabular-nums">
                    {formatEgp(teacherTotalTransferredEgp)}
                  </p>
                </div>
                <div className="bg-amber-50 dark:bg-amber-950/50 border border-amber-200 dark:border-amber-800 rounded-xl px-4 py-2.5">
                  <p className="text-[11px] text-amber-800 dark:text-amber-300">رصيد معلق بالمحفظة</p>
                  <p className="text-base font-extrabold text-amber-900 dark:text-amber-200 font-mono tabular-nums">
                    {formatEgp(teacherWalletBalance)}
                  </p>
                </div>
              </div>
            </div>

            <form onSubmit={(e) => void handleSavePayoutSettings(e)} className="grid grid-cols-1 lg:grid-cols-12 gap-4 items-end">
              <div className="lg:col-span-4 bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-xl p-3.5">
                <label className="flex items-center justify-between gap-3 cursor-pointer">
                  <div>
                    <span className="text-xs font-bold text-slate-900 dark:text-slate-100 block">
                      تفعيل التحويل التلقائي فور الدفع
                    </span>
                    <span className="text-[11px] text-slate-500 dark:text-slate-400">
                      تحويل الأموال إلى محفظتك لحظياً عند سداد أي طالب
                    </span>
                  </div>
                  <input
                    type="checkbox"
                    checked={payoutAuto}
                    onChange={(e) => setPayoutAuto(e.target.checked)}
                    className="w-5 h-5 accent-emerald-600 cursor-pointer shrink-0"
                  />
                </label>
              </div>

              <label className="lg:col-span-3 block space-y-1">
                <span className="text-xs font-semibold text-slate-700 dark:text-slate-300">قناة الاستلام الفوري</span>
                <select
                  value={payoutMethod}
                  onChange={(e) => setPayoutMethod(e.target.value as TopupMethod)}
                  className="w-full px-3 py-2.5 min-h-[42px] bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-slate-100 rounded-xl text-xs font-semibold"
                >
                  <option value="vodafone_cash">فودافون كاش (Vodafone Cash)</option>
                  <option value="instapay">إنستاباي (InstaPay)</option>
                  <option value="fawry">حساب تاجر فوري باي</option>
                </select>
              </label>

              <label className="lg:col-span-3 block space-y-1">
                <span className="text-xs font-semibold text-slate-700 dark:text-slate-300">رقم محفظة الاستلام</span>
                <input
                  type="tel"
                  dir="ltr"
                  value={payoutPhone}
                  onChange={(e) => setPayoutPhone(e.target.value)}
                  placeholder="01029121467"
                  className="w-full px-3.5 py-2.5 min-h-[42px] bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-slate-100 rounded-xl text-sm font-mono"
                />
              </label>

              <div className="lg:col-span-2 flex items-center gap-2">
                <button
                  type="submit"
                  disabled={savingPayout}
                  className="w-full py-2.5 min-h-[42px] bg-blue-700 hover:bg-blue-800 disabled:bg-slate-400 text-white text-xs font-bold rounded-xl cursor-pointer"
                >
                  {savingPayout ? 'جاري الحفظ...' : 'حفظ وتفعيل'}
                </button>
              </div>
            </form>

            {teacherWalletBalance > 0 && (
              <div className="bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800 rounded-xl px-4 py-3 flex flex-wrap items-center justify-between gap-3">
                <p className="text-xs text-amber-950 dark:text-amber-100">
                  يوجد رصيد معلق بقيمة <strong className="font-mono tabular-nums">{formatEgp(teacherWalletBalance)}</strong> جاهز للتحويل الآن إلى {payoutPhone}.
                </p>
                <button
                  type="button"
                  onClick={() => void transferTeacherWalletNow()}
                  className="inline-flex items-center gap-1.5 px-4 py-2 min-h-[36px] bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-bold rounded-xl cursor-pointer"
                >
                  <ArrowUpRight className="w-3.5 h-3.5" />
                  <span>تحويل الرصيد المعلق الآن</span>
                </button>
              </div>
            )}

            {/* Recent Teacher Wallet Ledger Transactions */}
            <div className="border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden">
              <div className="px-4 py-3 bg-slate-50 dark:bg-slate-800/80 border-b border-slate-200 dark:border-slate-700 flex items-center justify-between text-xs font-bold text-slate-900 dark:text-slate-100">
                <span>سجل الإيداعات والتحويلات الفورية ({teacherTransactions.length})</span>
                <span className="text-emerald-700 dark:text-emerald-400 font-mono">
                  {payoutAuto ? 'التحويل التلقائي مفعّل ✓' : 'وضع التجميع اليدوي'}
                </span>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-right text-xs">
                  <thead className="bg-slate-50/70 dark:bg-slate-900 text-slate-500 dark:text-slate-400 border-b border-slate-200 dark:border-slate-800">
                    <tr>
                      <th className="py-2.5 px-4">النوع</th>
                      <th className="py-2.5 px-4">البيان والطالب</th>
                      <th className="py-2.5 px-4">المبلغ</th>
                      <th className="py-2.5 px-4">المرجع / الوجهة</th>
                      <th className="py-2.5 px-4">التاريخ</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                    {teacherTransactions.slice(0, 15).map((tx) => {
                      const isPayout = tx.type !== 'student_payment';
                      return (
                        <tr key={tx.id}>
                          <td className="py-2.5 px-4 whitespace-nowrap">
                            <span
                              className={`inline-flex items-center gap-1 font-bold ${
                                isPayout
                                  ? 'text-emerald-700 dark:text-emerald-400'
                                  : 'text-blue-700 dark:text-blue-400'
                              }`}
                            >
                              {isPayout ? (
                                <ArrowUpRight className="w-3.5 h-3.5" />
                              ) : (
                                <ArrowDownLeft className="w-3.5 h-3.5" />
                              )}
                              <span>
                                {tx.type === 'auto_payout'
                                  ? 'تحويل فوري تلقائي'
                                  : tx.type === 'manual_payout'
                                    ? 'تحويل يدوي'
                                    : 'دفع طالب'}
                              </span>
                            </span>
                          </td>
                          <td className="py-2.5 px-4 text-slate-700 dark:text-slate-200">{tx.note}</td>
                          <td className="py-2.5 px-4 font-mono font-bold text-slate-900 dark:text-slate-100 tabular-nums">
                            {formatEgp(tx.amountEgp)}
                          </td>
                          <td className="py-2.5 px-4 font-mono text-slate-500 dark:text-slate-400" dir="ltr">
                            {tx.destinationPhone ? `${tx.destinationPhone} · ${tx.referenceNumber}` : tx.referenceNumber}
                          </td>
                          <td className="py-2.5 px-4 text-slate-500 dark:text-slate-400 whitespace-nowrap">
                            {formatArabicDateTime(tx.createdAt)}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          </div>

          {/* FawryPay Merchant Status & Settled Revenue */}
          <div className="bg-slate-900 text-white rounded-2xl p-6 space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <p className="text-xs font-semibold text-amber-400">بوابة الدفع التلقائي — فوري باي (FawryPay)</p>
                <h2 className="text-lg font-bold font-display mt-0.5">
                  {fawryStatus?.configured && fawryStatus.mode === 'live'
                    ? 'متصل بحساب التاجر الفعلي (Live Production)'
                    : 'يعمل حالياً بوضع التجربة (Sandbox) — جاهز لربط حساب التاجر'}
                </h2>
                <p className="text-xs text-slate-300 mt-1 leading-relaxed">
                  {fawryStatus?.configured
                    ? `كود التاجر المربوط: ${fawryStatus.merchantCodeMasked || 'مفعل'} · تُضاف المبالغ تلقائياً عند تأكيد Webhook من فوري.`
                    : 'عند استلام بيانات التاجر من فوري (FAWRY_MERCHANT_CODE و FAWRY_SECURITY_KEY) يتم إضافتها في إعدادات Secrets بالخادم وتعيين FAWRY_ENV=production لتحويل كل مدفوعات الطلاب تلقائياً إلى حسابك في فوري.'}
                </p>
              </div>
              <div className="bg-slate-800 border border-slate-700 rounded-xl px-5 py-3 shrink-0">
                <p className="text-[11px] text-slate-300">إجمالي تحصيلات فوري باي المدفوعة</p>
                <p className="text-xl font-extrabold font-mono text-amber-400 tabular-nums mt-0.5">
                  {formatEgp(fawryPaidTotal)}
                </p>
              </div>
            </div>

            {fawryOrders.length > 0 && (
              <div className="bg-slate-950/60 border border-slate-800 rounded-xl overflow-x-auto">
                <table className="w-full text-right text-xs">
                  <thead className="text-slate-400 border-b border-slate-800">
                    <tr>
                      <th className="py-2.5 px-4">الرقم المرجعي</th>
                      <th className="py-2.5 px-4">الطالب</th>
                      <th className="py-2.5 px-4">الغرض</th>
                      <th className="py-2.5 px-4">المبلغ</th>
                      <th className="py-2.5 px-4">الحالة</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800">
                    {fawryOrders.map((order) => (
                      <tr key={order.id}>
                        <td className="py-2.5 px-4 font-mono font-bold text-amber-300 tabular-nums">
                          {order.referenceNumber}
                        </td>
                        <td className="py-2.5 px-4 text-slate-200">{order.studentName}</td>
                        <td className="py-2.5 px-4 text-slate-300">
                          {order.purpose === 'course'
                            ? order.courseTitle || order.courseId
                            : 'شحن المحفظة'}
                        </td>
                        <td className="py-2.5 px-4 font-mono font-bold tabular-nums">
                          {formatEgp(order.amountEgp)}
                        </td>
                        <td
                          className={`py-2.5 px-4 font-semibold ${
                            order.status === 'PAID' ? 'text-emerald-400' : 'text-amber-300'
                          }`}
                        >
                          {order.status === 'PAID' ? 'مدفوعة' : 'بانتظار السداد'}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>

          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl overflow-hidden">
            <div className="px-5 py-3.5 border-b border-slate-200 dark:border-slate-800 text-sm font-bold text-slate-900 dark:text-slate-100">
              طلبات شحن المحفظة اليدوية (فودافون كاش / إنستاباي)
            </div>
            <div className="overflow-x-auto">
            <table className="w-full text-right text-xs">
              <thead className="bg-slate-50 dark:bg-slate-800/80 text-slate-500 dark:text-slate-400 border-b border-slate-200 dark:border-slate-800">
                <tr>
                  <th className="py-3 px-4">الطالب</th>
                  <th className="py-3 px-4">المبلغ</th>
                  <th className="py-3 px-4">طريقة التحويل</th>
                  <th className="py-3 px-4">رقم العملية</th>
                  <th className="py-3 px-4">التاريخ</th>
                  <th className="py-3 px-4">الإجراء</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {walletRequests.map((wr) => (
                  <tr key={wr.id}>
                    <td className="py-3 px-4">
                      <p className="font-semibold text-slate-900 dark:text-slate-100">{wr.studentName}</p>
                      <p className="text-[11px] text-slate-500 dark:text-slate-400 font-mono">{wr.studentPhone}</p>
                    </td>
                    <td className="py-3 px-4 font-mono font-bold text-slate-900 dark:text-slate-100 tabular-nums">
                      {formatEgp(wr.amountEgp)}
                    </td>
                    <td className="py-3 px-4 text-slate-700 dark:text-slate-300">{TOPUP_METHOD_LABELS[wr.method]}</td>
                    <td className="py-3 px-4 font-mono text-slate-700 dark:text-slate-300">{wr.referenceNumber}</td>
                    <td className="py-3 px-4 text-slate-500 dark:text-slate-400">{formatArabicDateTime(wr.createdAt)}</td>
                    <td className="py-3 px-4">
                      {wr.status === 'pending' ? (
                        <div className="flex items-center gap-2">
                          <button
                            type="button"
                            onClick={() => void resolveWalletRequest(wr.id, 'approved')}
                            className="inline-flex items-center gap-1 px-3 py-1.5 bg-emerald-700 hover:bg-emerald-800 text-white rounded-lg font-semibold cursor-pointer"
                          >
                            <Check className="w-3.5 h-3.5" />
                            <span>اعتماد</span>
                          </button>
                          <button
                            type="button"
                            onClick={() => void resolveWalletRequest(wr.id, 'rejected')}
                            className="inline-flex items-center gap-1 px-3 py-1.5 bg-red-50 dark:bg-red-950/60 hover:bg-red-100 text-red-700 dark:text-red-300 rounded-lg font-semibold cursor-pointer"
                          >
                            <X className="w-3.5 h-3.5" />
                            <span>رفض</span>
                          </button>
                        </div>
                      ) : (
                        <span
                          className={`font-semibold ${
                            wr.status === 'approved' ? 'text-emerald-700 dark:text-emerald-400' : 'text-red-700 dark:text-red-400'
                          }`}
                        >
                          {wr.status === 'approved' ? 'معتمد' : 'مرفوض'}
                        </span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
        </div>
      )}

      {/* Tab 4: Live In-Site Student/Parent Chat Inbox */}
      {activeTab === 'chat' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <div className="lg:col-span-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl overflow-hidden">
            <div className="p-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
              <h2 className="text-sm font-bold text-slate-900 dark:text-slate-100 font-display">محادثات الطلاب وأولياء الأمور</h2>
              <span className="text-xs font-mono tabular-nums text-slate-500 dark:text-slate-400">{chatThreads.length}</span>
            </div>
            {chatThreads.length === 0 ? (
              <p className="p-6 text-xs text-slate-500 dark:text-slate-400 text-center">
                لا توجد رسائل واردة بعد. ستظهر هنا فور إرسال أي طالب رسالة من نافذة المحادثة داخل الموقع.
              </p>
            ) : (
              <div className="divide-y divide-slate-100 dark:divide-slate-800 max-h-[460px] overflow-y-auto">
                {chatThreads.map((thread) => {
                  const selected = activeThread?.threadId === thread.threadId;
                  return (
                    <button
                      key={thread.threadId}
                      type="button"
                      onClick={() => setSelectedThreadId(thread.threadId)}
                      className={`w-full text-right p-4 transition-colors cursor-pointer ${
                        selected ? 'bg-blue-50 dark:bg-blue-950/50' : 'hover:bg-slate-50 dark:hover:bg-slate-800/60'
                      }`}
                    >
                      <div className="flex items-center justify-between gap-2">
                        <span className="text-xs font-bold text-slate-900 dark:text-slate-100 truncate">{thread.displayName}</span>
                        <span className="text-[11px] font-semibold text-blue-700 dark:text-blue-400 shrink-0">
                          {thread.gradeLabel}
                        </span>
                      </div>
                      {thread.phone && (
                        <p className="text-[11px] text-slate-500 dark:text-slate-400 font-mono tabular-nums mt-0.5" dir="ltr">
                          {thread.phone}
                        </p>
                      )}
                      <p className="text-xs text-slate-600 dark:text-slate-400 truncate mt-1.5">
                        {thread.lastMessage.senderRole === 'teacher' ? 'أنت: ' : ''}
                        {thread.lastMessage.text}
                      </p>
                    </button>
                  );
                })}
              </div>
            )}
          </div>

          <div className="lg:col-span-8 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl overflow-hidden flex flex-col min-h-[460px]">
            {activeThread ? (
              <>
                <div className="p-4 border-b border-slate-200 dark:border-slate-800 flex flex-wrap items-center justify-between gap-3 bg-slate-50 dark:bg-slate-800/70">
                  <div>
                    <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100">{activeThread.displayName}</h3>
                    <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                      {activeThread.gradeLabel}
                      {activeThread.phone ? ` · ${activeThread.phone}` : ''}
                    </p>
                  </div>
                  {activeThread.phone && (
                    <div className="flex items-center gap-2">
                      <a
                        href={`tel:${formatPhoneDigits(activeThread.phone)}`}
                        className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 hover:border-blue-600 text-slate-800 dark:text-slate-100 text-xs font-semibold rounded-lg"
                      >
                        <Phone className="w-3.5 h-3.5 text-blue-700 dark:text-blue-400" />
                        <span>اتصال</span>
                      </a>
                      <a
                        href={formatWhatsappHref(activeThread.phone)}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-semibold rounded-lg"
                      >
                        <MessageCircle className="w-3.5 h-3.5" />
                        <span>واتساب الطالب</span>
                      </a>
                    </div>
                  )}
                </div>

                <div className="flex-1 p-5 space-y-3 overflow-y-auto bg-slate-50 dark:bg-slate-950/60 max-h-[340px]">
                  {activeThread.messages.map((msg) => {
                    const isTeacher = msg.senderRole === 'teacher';
                    return (
                      <div
                        key={msg.id}
                        className={`flex flex-col ${isTeacher ? 'items-end' : 'items-start'}`}
                      >
                        <div
                          className={`max-w-[80%] rounded-xl px-4 py-2.5 text-xs leading-relaxed ${
                            isTeacher
                              ? 'bg-slate-900 dark:bg-blue-700 text-white'
                              : 'bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-slate-100'
                          }`}
                        >
                          <p className={`text-[11px] font-bold mb-1 ${isTeacher ? 'text-slate-300 dark:text-blue-100' : 'text-blue-700 dark:text-blue-400'}`}>
                            {msg.senderName}
                          </p>
                          <p className="whitespace-pre-wrap break-words">{msg.text}</p>
                        </div>
                        <span className="text-[10px] text-slate-400 dark:text-slate-500 font-mono tabular-nums mt-1 px-1">
                          {formatArabicDateTime(msg.createdAt)}
                        </span>
                      </div>
                    );
                  })}
                </div>

                <form
                  onSubmit={(e) => void handleSendTeacherReply(e)}
                  className="p-4 border-t border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 flex items-center gap-2"
                >
                  <input
                    type="text"
                    value={teacherReply}
                    onChange={(e) => setTeacherReply(e.target.value)}
                    placeholder={`اكتب رد الأستاذة نجلاء على ${activeThread.displayName}...`}
                    maxLength={1000}
                    className="flex-1 px-4 py-2.5 min-h-[44px] bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-slate-100 focus:outline-none focus:border-blue-700"
                  />
                  <button
                    type="submit"
                    disabled={!teacherReply.trim() || sendingReply}
                    className="inline-flex items-center gap-1.5 px-5 py-2.5 min-h-[44px] bg-blue-700 hover:bg-blue-800 disabled:bg-slate-300 dark:disabled:bg-slate-700 text-white text-xs font-bold rounded-xl transition-colors cursor-pointer shrink-0"
                  >
                    <Send className="w-3.5 h-3.5" />
                    <span>إرسال الرد</span>
                  </button>
                </form>
              </>
            ) : (
              <div className="flex-1 flex items-center justify-center p-8 text-xs text-slate-500 dark:text-slate-400">
                اختر محادثة من القائمة لعرض الرسائل والرد مباشرة.
              </div>
            )}
          </div>
        </div>
      )}

      {/* Tab 2: Scheduled Lectures & Real-Time Push Reminders */}
      {activeTab === 'schedules' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <form
            onSubmit={(e) => void handleCreateSchedule(e)}
            className="lg:col-span-5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 space-y-4"
          >
            <h2 className="text-base font-bold text-slate-900 dark:text-slate-100 font-display flex items-center gap-2">
              <BellRing className="w-4 h-4 text-blue-700 dark:text-blue-400" />
              <span>جدولة محاضرة وإرسال تنبيه للطلاب</span>
            </h2>

            <label className="block space-y-1">
              <span className="text-xs font-semibold text-slate-700 dark:text-slate-300">الكورس</span>
              <select
                value={schCourseId}
                onChange={(e) => setSchCourseId(e.target.value)}
                className="w-full px-3 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-semibold text-slate-900 dark:text-slate-100"
              >
                {courses.map((c) => (
                  <option key={c.id} value={c.id}>
                    {GRADE_SHORT_LABELS[c.grade]} · {c.title}
                  </option>
                ))}
              </select>
            </label>

            <label className="block space-y-1">
              <span className="text-xs font-semibold text-slate-700 dark:text-slate-300">عنوان المحاضرة القادمة</span>
              <input
                type="text"
                value={schLessonTitle}
                onChange={(e) => setSchLessonTitle(e.target.value)}
                placeholder="مثال: حل تدريبات النحو الشاملة"
                className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-sm text-slate-900 dark:text-slate-100"
              />
            </label>

            <div className="grid grid-cols-2 gap-3">
              <label className="block space-y-1">
                <span className="text-xs font-semibold text-slate-700 dark:text-slate-300">تبدأ بعد (دقيقة)</span>
                <select
                  value={schStartsInMin}
                  onChange={(e) => setSchStartsInMin(e.target.value)}
                  className="w-full px-3 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-bold font-mono text-slate-900 dark:text-slate-100"
                >
                  <option value="2">2 دقيقة (عاجل)</option>
                  <option value="5">5 دقائق</option>
                  <option value="10">10 دقائق</option>
                  <option value="15">15 دقيقة</option>
                  <option value="30">30 دقيقة</option>
                  <option value="60">ساعة واحدة</option>
                  <option value="180">3 ساعات</option>
                </select>
              </label>

              <label className="block space-y-1">
                <span className="text-xs font-semibold text-slate-700 dark:text-slate-300">التذكير التلقائي قبلها بـ</span>
                <select
                  value={schRemindMin}
                  onChange={(e) => setSchRemindMin(e.target.value)}
                  className="w-full px-3 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-bold font-mono text-slate-900 dark:text-slate-100"
                >
                  <option value="5">5 دقائق</option>
                  <option value="10">10 دقائق</option>
                  <option value="15">15 دقيقة</option>
                  <option value="30">30 دقيقة</option>
                </select>
              </label>
            </div>

            <label className="block space-y-1">
              <span className="text-xs font-semibold text-slate-700 dark:text-slate-300">ملاحظة تظهر في التنبيه للطلاب</span>
              <input
                type="text"
                value={schNote}
                onChange={(e) => setSchNote(e.target.value)}
                placeholder="مثال: أحضر كراسة التدريبات قبل بدء الشرح"
                className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-sm text-slate-900 dark:text-slate-100"
              />
            </label>

            <label className="flex items-center gap-2 text-xs text-slate-700 dark:text-slate-300 cursor-pointer">
              <input
                type="checkbox"
                checked={schPushNow}
                onChange={(e) => setSchPushNow(e.target.checked)}
                className="accent-blue-700"
              />
              <span>بث تنبيه دفع فوري داخل الموقع فور حفظ الموعد</span>
            </label>

            <button
              type="submit"
              className="w-full py-2.5 min-h-[44px] bg-blue-700 hover:bg-blue-800 text-white text-xs font-bold rounded-xl transition-colors cursor-pointer"
            >
              حفظ الموعد وتفعيل التذكير
            </button>
          </form>

          <div className="lg:col-span-7 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl overflow-hidden">
            <div className="p-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
              <h2 className="text-sm font-bold text-slate-900 dark:text-slate-100 font-display">
                المواعيد المجدولة وبث التنبيهات الفورية
              </h2>
              <span className="text-xs font-mono tabular-nums text-slate-500 dark:text-slate-400">
                {lectureSchedules.length} مواعيد
              </span>
            </div>

            {lectureSchedules.length === 0 ? (
              <p className="p-8 text-center text-xs text-slate-500 dark:text-slate-400">
                لا توجد محاضرات مجدولة حالياً. أضف موعداً جديداً من النموذج لإرسال تنبيهات للطلاب.
              </p>
            ) : (
              <div className="divide-y divide-slate-100 dark:divide-slate-800">
                {lectureSchedules.map((sch) => (
                  <div
                    key={sch.id}
                    className="p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                  >
                    <div className="space-y-1">
                      <p className="text-xs text-slate-500 dark:text-slate-400">
                        {GRADE_SHORT_LABELS[sch.grade]} · {BRANCH_LABELS[sch.branch]} ·{' '}
                        <span className="font-mono tabular-nums">
                          {formatArabicDateTime(sch.scheduledAt)}
                        </span>
                      </p>
                      <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100">{sch.lessonTitle}</h3>
                      <p className="text-xs text-slate-600 dark:text-slate-400">{sch.courseTitle}</p>
                      {sch.note && <p className="text-[11px] text-slate-500 dark:text-slate-400">{sch.note}</p>}
                    </div>

                    <div className="flex items-center gap-2 shrink-0">
                      <button
                        type="button"
                        onClick={() => void pushLectureReminderNow(sch.id)}
                        className="inline-flex items-center gap-1.5 px-3 py-2 min-h-[38px] bg-slate-900 dark:bg-slate-800 hover:bg-slate-800 dark:hover:bg-slate-700 text-white text-xs font-bold rounded-xl transition-colors cursor-pointer"
                      >
                        <BellRing className="w-3.5 h-3.5 text-amber-400" />
                        <span>بث تنبيه الآن</span>
                      </button>
                      <button
                        type="button"
                        onClick={() => void deleteLectureSchedule(sch.id)}
                        aria-label={`حذف موعد ${sch.lessonTitle}`}
                        className="p-2 min-h-[38px] bg-red-50 dark:bg-red-950/60 hover:bg-red-100 dark:hover:bg-red-900/60 text-red-700 dark:text-red-300 rounded-xl transition-colors cursor-pointer"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* Tab: Student Lesson Ratings & Reviews Analytics */}
      {activeTab === 'reviews' && (
        <div className="space-y-6">
          {/* 3 Rating Averages */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 space-y-1">
              <p className="text-xs text-slate-500 dark:text-slate-400">المتوسط العام لتقييمات المنصة</p>
              <p className="text-3xl font-extrabold text-slate-900 dark:text-slate-100 font-mono tabular-nums flex items-center gap-2">
                <Star className="w-6 h-6 fill-amber-400 text-amber-500" />
                <span>{reviewStats.total > 0 ? `${reviewStats.avgOverall} / 5` : '—'}</span>
              </p>
              <p className="text-xs text-slate-500 dark:text-slate-400 tabular-nums">
                إجمالي التقييمات المعتمدة: {reviewStats.total}
              </p>
            </div>

            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 space-y-1">
              <p className="text-xs text-slate-500 dark:text-slate-400">متوسط تقييم الشرح الصوتي والرسوم</p>
              <p className="text-3xl font-extrabold text-blue-700 dark:text-blue-400 font-mono tabular-nums">
                {reviewStats.total > 0 ? `${reviewStats.avgAudio} / 5` : '—'}
              </p>
              <p className="text-xs text-slate-500 dark:text-slate-400">وضوح الصوت وتفاعل الفيديو الكرتوني</p>
            </div>

            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 space-y-1">
              <p className="text-xs text-slate-500 dark:text-slate-400">متوسط تقييم المحتوى التعليمي</p>
              <p className="text-3xl font-extrabold text-emerald-700 dark:text-emerald-400 font-mono tabular-nums">
                {reviewStats.total > 0 ? `${reviewStats.avgContent} / 5` : '—'}
              </p>
              <p className="text-xs text-slate-500 dark:text-slate-400">الأمثلة والقواعد والملازم التدريبية</p>
            </div>
          </div>

          {/* Per-Lesson Rating Averages Table (متوسط تقييمات كل درس) */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl overflow-hidden">
            <div className="p-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
              <h2 className="text-sm font-bold text-slate-900 dark:text-slate-100 font-display">
                متوسط تقييمات كل درس
              </h2>
              <span className="text-xs font-mono tabular-nums text-slate-500 dark:text-slate-400">
                {reviewStats.byLesson.length} دروس مقيمة
              </span>
            </div>

            {reviewStats.byLesson.length === 0 ? (
              <p className="p-6 text-center text-xs text-slate-500 dark:text-slate-400">
                لا توجد تقييمات دروس مسجلة بعد.
              </p>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-right text-xs">
                  <thead className="bg-slate-50 dark:bg-slate-800/80 text-slate-500 dark:text-slate-400 border-b border-slate-200 dark:border-slate-800">
                    <tr>
                      <th className="py-3 px-4">الدرس</th>
                      <th className="py-3 px-4">الكورس</th>
                      <th className="py-3 px-4">الصف</th>
                      <th className="py-3 px-4">عدد التقييمات</th>
                      <th className="py-3 px-4">الشرح الصوتي</th>
                      <th className="py-3 px-4">المحتوى التعليمي</th>
                      <th className="py-3 px-4">متوسط الدرس</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                    {reviewStats.byLesson.map((row) => (
                      <tr key={row.lessonId}>
                        <td className="py-3 px-4 font-bold text-slate-900 dark:text-slate-100">{row.lessonTitle}</td>
                        <td className="py-3 px-4 text-slate-600 dark:text-slate-300">{row.courseTitle}</td>
                        <td className="py-3 px-4 text-slate-600 dark:text-slate-300">{GRADE_SHORT_LABELS[row.grade]}</td>
                        <td className="py-3 px-4 font-mono tabular-nums text-slate-700 dark:text-slate-200">{row.count}</td>
                        <td className="py-3 px-4 font-mono font-bold text-blue-700 dark:text-blue-400 tabular-nums">
                          {row.avgAudio} / 5
                        </td>
                        <td className="py-3 px-4 font-mono font-bold text-emerald-700 dark:text-emerald-400 tabular-nums">
                          {row.avgContent} / 5
                        </td>
                        <td className="py-3 px-4 font-mono font-extrabold text-amber-700 dark:text-amber-400 tabular-nums">
                          <span className="inline-flex items-center gap-1">
                            <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-500" />
                            <span>{row.avgOverall}</span>
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>

          {/* Course-by-Course Rating Averages Table */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl overflow-hidden">
            <div className="p-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
              <h2 className="text-sm font-bold text-slate-900 dark:text-slate-100 font-display">
                متوسط التقييمات حسب كل كورس
              </h2>
              <span className="text-xs font-mono tabular-nums text-slate-500 dark:text-slate-400">
                {reviewStats.byCourse.length} كورسات مقيمة
              </span>
            </div>

            {reviewStats.byCourse.length === 0 ? (
              <p className="p-6 text-center text-xs text-slate-500 dark:text-slate-400">
                لا توجد تقييمات مسجلة بعد.
              </p>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-right text-xs">
                  <thead className="bg-slate-50 dark:bg-slate-800/80 text-slate-500 dark:text-slate-400 border-b border-slate-200 dark:border-slate-800">
                    <tr>
                      <th className="py-3 px-4">الكورس</th>
                      <th className="py-3 px-4">الصف</th>
                      <th className="py-3 px-4">عدد التقييمات</th>
                      <th className="py-3 px-4">متوسط الشرح الصوتي</th>
                      <th className="py-3 px-4">متوسط المحتوى</th>
                      <th className="py-3 px-4">المتوسط العام</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                    {reviewStats.byCourse.map((row) => (
                      <tr key={row.courseId}>
                        <td className="py-3 px-4 font-bold text-slate-900 dark:text-slate-100">{row.courseTitle}</td>
                        <td className="py-3 px-4 text-slate-600 dark:text-slate-300">{GRADE_SHORT_LABELS[row.grade]}</td>
                        <td className="py-3 px-4 font-mono tabular-nums text-slate-700 dark:text-slate-200">{row.count}</td>
                        <td className="py-3 px-4 font-mono font-bold text-blue-700 dark:text-blue-400 tabular-nums">
                          {row.avgAudio} / 5
                        </td>
                        <td className="py-3 px-4 font-mono font-bold text-emerald-700 dark:text-emerald-400 tabular-nums">
                          {row.avgContent} / 5
                        </td>
                        <td className="py-3 px-4 font-mono font-extrabold text-amber-700 dark:text-amber-400 tabular-nums">
                          <span className="inline-flex items-center gap-1">
                            <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-500" />
                            <span>{row.avgOverall}</span>
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>

          {/* Detailed Student Reviews List */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl overflow-hidden">
            <div className="p-4 border-b border-slate-200 dark:border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <h2 className="text-sm font-bold text-slate-900 dark:text-slate-100 font-display">
                تعليقات وآراء الطلاب بعد إتمام الدروس ({filteredReviews.length})
              </h2>
              <select
                value={reviewCourseFilter}
                onChange={(e) => setReviewCourseFilter(e.target.value)}
                className="px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-slate-100 rounded-xl text-xs font-semibold"
              >
                <option value="all">جميع الكورسات</option>
                {courses.map((c) => (
                  <option key={c.id} value={c.id}>
                    {GRADE_SHORT_LABELS[c.grade]} · {c.title}
                  </option>
                ))}
              </select>
            </div>

            {filteredReviews.length === 0 ? (
              <p className="p-8 text-center text-xs text-slate-500 dark:text-slate-400">
                لا توجد تعليقات مطابقة للتصفية الحالية.
              </p>
            ) : (
              <div className="divide-y divide-slate-100 dark:divide-slate-800">
                {filteredReviews.map((rev) => (
                  <div key={rev.id} className="p-4 space-y-1.5">
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <div className="text-xs">
                        <span className="font-bold text-slate-900 dark:text-slate-100">{rev.studentName}</span>
                        <span className="text-slate-400 mx-1.5">·</span>
                        <span className="text-blue-700 dark:text-blue-400 font-semibold">{rev.lessonTitle}</span>
                        <span className="text-slate-400 mx-1.5">·</span>
                        <span className="text-slate-500 dark:text-slate-400">{GRADE_SHORT_LABELS[rev.grade]}</span>
                      </div>
                      <span className="inline-flex items-center gap-1 text-xs font-mono font-bold text-amber-700 dark:text-amber-400 tabular-nums">
                        <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-500" />
                        <span>{rev.overallRating.toFixed(1)} / 5</span>
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-500 dark:text-slate-400 tabular-nums">
                      {rev.courseTitle} · الصوت: {rev.audioRating}/5 · المحتوى: {rev.contentRating}/5 ·{' '}
                      {formatArabicDateTime(rev.updatedAt || rev.createdAt)}
                    </p>
                    {rev.comment && (
                      <p className="text-xs text-slate-700 dark:text-slate-200 leading-relaxed pt-1">{rev.comment}</p>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* Tab 5: Students & Exam Scores */}
      {activeTab === 'students' && (
        <div className="space-y-4">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4">
            <input
              type="search"
              value={studentQuery}
              onChange={(e) => setStudentQuery(e.target.value)}
              placeholder="ابحث باسم الطالب أو رقم الموبايل أو المحافظة..."
              className="w-full px-4 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-slate-100 rounded-xl text-sm focus:outline-none focus:border-blue-700"
            />
          </div>

          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-right text-xs">
                <thead className="bg-slate-50 dark:bg-slate-800/80 text-slate-500 dark:text-slate-400 border-b border-slate-200 dark:border-slate-800">
                  <tr>
                    <th className="py-3 px-4">الطالب</th>
                    <th className="py-3 px-4">الصف والمحافظة</th>
                    <th className="py-3 px-4">موبايل الطالب / ولي الأمر</th>
                    <th className="py-3 px-4">الرصيد</th>
                    <th className="py-3 px-4">الكورسات</th>
                    <th className="py-3 px-4">آخر امتحان</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                  {filteredStudents.map((stu) => {
                    const lastAttempt = attempts.find((a) => a.studentId === stu.id);
                    return (
                      <tr key={stu.id}>
                        <td className="py-3 px-4 font-bold text-slate-900 dark:text-slate-100">{stu.name}</td>
                        <td className="py-3 px-4 text-slate-600 dark:text-slate-300">
                          {GRADE_SHORT_LABELS[stu.grade]} · {stu.governorate}
                        </td>
                        <td className="py-3 px-4 font-mono text-slate-700 dark:text-slate-300">
                          {stu.phone} / {stu.parentPhone}
                        </td>
                        <td className="py-3 px-4 font-mono font-bold text-slate-900 dark:text-slate-100 tabular-nums">
                          {stu.walletBalance} ج.م
                        </td>
                        <td className="py-3 px-4 font-mono text-slate-700 dark:text-slate-200 tabular-nums">{stu.enrolledCourseIds.length}</td>
                        <td className="py-3 px-4 font-mono tabular-nums text-emerald-700 dark:text-emerald-400 font-bold">
                          {lastAttempt ? `${lastAttempt.score}/${lastAttempt.total} (${lastAttempt.percentage}%)` : '—'}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* Tab: Platform Settings, Server Export Bundle & Announcements */}
      {activeTab === 'settings' && (
        <div className="space-y-6">
          {/* Server Deployment, Free Cloud & Odoo Integration Card */}
          <div
            id="teacher-export-panel"
            className="bg-slate-900 text-white rounded-2xl p-6 space-y-5 border border-slate-800 scroll-mt-20"
          >
            <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
              <div className="flex items-start gap-3.5">
                <AcademyEmblem size={48} />
                <div className="space-y-1">
                  <div className="flex items-center gap-2 text-xs font-bold text-amber-400">
                    <HardDriveDownload className="w-4 h-4" />
                    <span>تجهيز الرفع على سيرفر مجاني + الربط مع موقع أودو (Odoo Website)</span>
                  </div>
                  <h2 className="text-lg font-extrabold font-display">
                    حزمة السيرفر المجاني وتضمين المنصة داخل Odoo
                  </h2>
                  <p className="text-xs text-slate-300 leading-relaxed max-w-2xl">
                    ملف <span dir="ltr" className="font-mono text-amber-300">platform-naglaa-fathi-server.tar.gz</span> يتضمن <span dir="ltr" className="font-mono text-slate-200">render.yaml</span> و <span dir="ltr" className="font-mono text-slate-200">Dockerfile</span> للرفع المباشر على Render أو Koyeb، بالإضافة لشعار المنصة الرسمي <span dir="ltr" className="font-mono text-slate-200">icon.svg</span>.
                  </p>
                </div>
              </div>

              <div className="flex flex-wrap items-center gap-2.5 shrink-0">
                <button
                  type="button"
                  disabled={downloadingFile !== null}
                  onClick={() =>
                    void triggerBlobDownload(
                      'bundle',
                      '/api/admin/export-bundle',
                      'platform-naglaa-fathi-server.tar.gz',
                      'ملف السيرفر'
                    )
                  }
                  className="inline-flex items-center gap-2 px-4 py-2.5 min-h-[42px] bg-amber-400 hover:bg-amber-300 disabled:opacity-60 text-slate-950 text-xs font-extrabold rounded-xl transition-colors cursor-pointer"
                >
                  <Download className="w-4 h-4" />
                  <span>{downloadingFile === 'bundle' ? 'جاري التحميل...' : 'ملف السيرفر (.tar.gz)'}</span>
                </button>
                <button
                  type="button"
                  disabled={downloadingFile !== null}
                  onClick={() =>
                    void triggerBlobDownload(
                      'odoo',
                      `/api/admin/export-odoo-module?url=${encodeURIComponent(sanitizedEmbedUrl)}`,
                      'naglaa_fathi_academy_odoo.zip',
                      'موديول Odoo'
                    )
                  }
                  className="inline-flex items-center gap-2 px-4 py-2.5 min-h-[42px] bg-emerald-500 hover:bg-emerald-400 disabled:opacity-60 text-slate-950 text-xs font-extrabold rounded-xl transition-colors cursor-pointer"
                >
                  <Download className="w-4 h-4" />
                  <span>{downloadingFile === 'odoo' ? 'جاري التجهيز...' : 'موديول Odoo (.zip)'}</span>
                </button>
                <button
                  type="button"
                  disabled={downloadingFile !== null}
                  onClick={() =>
                    void triggerBlobDownload('logo', '/icon.svg', 'naglaa-academy-logo.svg', 'شعار المنصة')
                  }
                  className="inline-flex items-center gap-2 px-4 py-2.5 min-h-[42px] bg-blue-700 hover:bg-blue-600 disabled:opacity-60 text-white text-xs font-bold rounded-xl transition-colors cursor-pointer"
                >
                  <Download className="w-4 h-4" />
                  <span>{downloadingFile === 'logo' ? 'جاري التحميل...' : 'اللوجو (SVG)'}</span>
                </button>
                <button
                  type="button"
                  disabled={downloadingFile !== null}
                  onClick={() =>
                    void triggerBlobDownload(
                      'backup',
                      '/api/admin/export-backup',
                      'naglaa-academy-backup.json',
                      'النسخة الاحتياطية'
                    )
                  }
                  className="inline-flex items-center gap-2 px-4 py-2.5 min-h-[42px] bg-slate-800 hover:bg-slate-700 disabled:opacity-60 text-white text-xs font-bold rounded-xl border border-slate-700 transition-colors cursor-pointer"
                >
                  <Download className="w-4 h-4" />
                  <span>{downloadingFile === 'backup' ? 'جاري التصدير...' : 'البيانات (JSON)'}</span>
                </button>
              </div>
            </div>

            {/* Free Hosting Guidance */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              <div className="bg-slate-950/75 border border-slate-800 rounded-xl p-4 space-y-1.5">
                <p className="text-xs font-bold text-emerald-400">1. استضافة Render أو Koyeb (مجاني)</p>
                <p className="text-[11px] text-slate-300 leading-relaxed">
                  يدعم ملف <span dir="ltr" className="font-mono text-slate-200">render.yaml</span> مباشرة. أضف <span dir="ltr" className="font-mono text-amber-300">DATABASE_URL</span> مجاني من <span className="font-semibold text-white">Neon.tech</span> لحفظ بيانات الطلاب دائماً دون مسح.
                </p>
              </div>
              <div className="bg-slate-950/75 border border-slate-800 rounded-xl p-4 space-y-1.5">
                <p className="text-xs font-bold text-blue-400">2. سيرفر Oracle Free VPS (دائم)</p>
                <p className="text-[11px] text-slate-300 leading-relaxed">
                  خادم Linux مجاني دائم لا ينام ولا يفقد الملفات المحلية، مناسب للتشغيل المستمر بـ Docker أو PM2 على منفذ 3000.
                </p>
              </div>
              <div className="bg-slate-950/75 border border-slate-800 rounded-xl p-4 space-y-1.5">
                <p className="text-xs font-bold text-amber-400">3. الربط مع نظام أودو (Odoo)</p>
                <p className="text-[11px] text-slate-300 leading-relaxed">
                  لأن أودو يعمل بـ Python فلا يركّب كوديول Node داخلياً، بل يُدمج في صفحة <span className="font-semibold text-white">Odoo Website</span> بكود <span dir="ltr" className="font-mono text-amber-300">iframe</span> الجاهز أدناه أو كرابط في القائمة.
                </p>
              </div>
            </div>

            {/* Odoo HTML Embed Generator + CLI Commands */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
              <div className="bg-slate-950/75 border border-slate-800 rounded-xl p-4 space-y-3">
                <div className="flex items-center justify-between gap-2">
                  <span className="inline-flex items-center gap-1.5 text-xs font-bold text-amber-300">
                    <Globe className="w-4 h-4" />
                    <span>كود التضمين داخل Odoo Website (HTML Block)</span>
                  </span>
                  <button
                    type="button"
                    onClick={() => void handleCopyOdooEmbed()}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-amber-400 hover:bg-amber-300 text-slate-950 text-[11px] font-extrabold rounded-lg cursor-pointer transition-colors"
                  >
                    {copiedOdoo ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copiedOdoo ? 'تم النسخ' : 'نسخ كود Odoo'}</span>
                  </button>
                </div>

                <label className="block space-y-1">
                  <span className="text-[11px] text-slate-400">رابط المنصة بعد الرفع (أو الرابط الحالي):</span>
                  <input
                    type="url"
                    dir="ltr"
                    value={embedOrigin}
                    onChange={(e) => setEmbedOrigin(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-lg text-xs font-mono text-slate-100"
                  />
                </label>

                <pre
                  dir="ltr"
                  className="text-[11px] font-mono text-amber-200 bg-slate-900/90 border border-slate-800 rounded-lg p-3 overflow-x-auto leading-relaxed"
                >{odooEmbedSnippet}</pre>
              </div>

              <div className="bg-slate-950/75 border border-slate-800 rounded-xl p-4 space-y-2">
                <p className="text-xs font-bold text-slate-200">خطوات التشغيل على السيرفر الخارجي أو Docker:</p>
                <pre
                  dir="ltr"
                  className="text-xs font-mono text-emerald-300 overflow-x-auto leading-relaxed bg-slate-900/90 border border-slate-800 rounded-lg p-3"
                >{`tar -xzf platform-naglaa-fathi-server.tar.gz
npm install --include=dev
npm run build
PORT=3000 NODE_ENV=production npm start`}</pre>
                <p className="text-[11px] text-slate-400 leading-relaxed">
                  في Odoo: افتح <span className="font-semibold text-slate-200">Website ← Edit</span> ثم اسحب أداة <span className="font-semibold text-slate-200">Embed Code</span> وألصق الكود، أو أضف الرابط في <span className="font-semibold text-slate-200">Menu Editor</span>.
                </p>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <form
            onSubmit={(e) => void handleSaveProfile(e)}
            className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 space-y-4"
          >
            <h2 className="text-base font-bold text-slate-900 dark:text-slate-100 font-display">تخصيص هوية المنصة والمعلم</h2>

            <label className="block space-y-1">
              <span className="text-xs font-semibold text-slate-700 dark:text-slate-300">اسم المنصة</span>
              <input
                type="text"
                value={profName}
                onChange={(e) => setProfName(e.target.value)}
                className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-slate-100 rounded-xl text-sm"
              />
            </label>

            <label className="block space-y-1">
              <span className="text-xs font-semibold text-slate-700 dark:text-slate-300">اسم المحاضر / الأستاذ</span>
              <input
                type="text"
                value={profTeacher}
                onChange={(e) => setProfTeacher(e.target.value)}
                className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-slate-100 rounded-xl text-sm"
              />
            </label>

            <label className="block space-y-1">
              <span className="text-xs font-semibold text-slate-700 dark:text-slate-300">المسمى التدريسي</span>
              <input
                type="text"
                value={profTitle}
                onChange={(e) => setProfTitle(e.target.value)}
                className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-slate-100 rounded-xl text-sm"
              />
            </label>

            <label className="block space-y-1">
              <span className="text-xs font-semibold text-slate-700 dark:text-slate-300">رقم التواصل والواتساب</span>
              <input
                type="tel"
                dir="ltr"
                value={profHotline}
                onChange={(e) => setProfHotline(e.target.value)}
                placeholder="01029121467"
                className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-slate-100 rounded-xl text-sm font-mono"
              />
            </label>

            <label className="block space-y-1">
              <span className="text-xs font-semibold text-slate-700 dark:text-slate-300">النبذة التعريفية في الصفحة الرئيسية</span>
              <textarea
                rows={3}
                value={profBio}
                onChange={(e) => setProfBio(e.target.value)}
                className="w-full px-3.5 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-slate-100 rounded-xl text-sm"
              />
            </label>

            <button
              type="submit"
              className="px-6 py-2.5 bg-blue-700 hover:bg-blue-800 text-white text-xs font-bold rounded-xl cursor-pointer"
            >
              حفظ التعديلات
            </button>
          </form>

          <form
            onSubmit={(e) => void handlePublishAnnouncement(e)}
            className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 space-y-4"
          >
            <h2 className="text-base font-bold text-slate-900 dark:text-slate-100 font-display">نشر تنبيه جديد للطلاب</h2>

            <label className="block space-y-1">
              <span className="text-xs font-semibold text-slate-700 dark:text-slate-300">عنوان التنبيه</span>
              <input
                type="text"
                value={annTitle}
                onChange={(e) => setAnnTitle(e.target.value)}
                placeholder="مثال: موعد مراجعة التفاضل المباشرة"
                className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-slate-100 rounded-xl text-sm"
              />
            </label>

            <label className="block space-y-1">
              <span className="text-xs font-semibold text-slate-700 dark:text-slate-300">الفئة المستهدفة</span>
              <select
                value={annGrade}
                onChange={(e) => setAnnGrade(e.target.value as GradeLevel | 'all')}
                className="w-full px-3 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-slate-100 rounded-xl text-xs font-semibold"
              >
                <option value="all">جميع الصفوف الدراسية</option>
                {Object.entries(GRADE_LABELS).map(([k, v]) => (
                  <option key={k} value={k}>
                    {v}
                  </option>
                ))}
              </select>
            </label>

            <label className="block space-y-1">
              <span className="text-xs font-semibold text-slate-700 dark:text-slate-300">نص الرسالة</span>
              <textarea
                rows={4}
                value={annBody}
                onChange={(e) => setAnnBody(e.target.value)}
                placeholder="التفاصيل والمواعيد..."
                className="w-full px-3.5 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-slate-100 rounded-xl text-sm"
              />
            </label>

            <button
              type="submit"
              className="px-6 py-2.5 bg-slate-900 dark:bg-blue-700 hover:bg-slate-800 dark:hover:bg-blue-600 text-white text-xs font-bold rounded-xl cursor-pointer"
            >
              نشر التنبيه الآن
            </button>
          </form>
        </div>
        </div>
      )}
    </div>
  );
}
