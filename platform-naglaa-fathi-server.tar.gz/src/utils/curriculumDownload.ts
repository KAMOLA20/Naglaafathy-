import type { AcademyProfile, Course, Exam, GradeLevel } from '../types.ts';
import { BRANCH_LABELS, GRADE_LABELS } from './academy.ts';

function escapeHtml(raw: string): string {
  return String(raw || '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function buildCourseSectionHtml(course: Course, exam?: Exam): string {
  const lessonsHtml = course.lessons
    .map(
      (lesson) => `
      <div class="lesson-box">
        <div class="lesson-header">
          <h3>الدرس ${lesson.order}: ${escapeHtml(lesson.title)}</h3>
          <span class="meta">${lesson.durationMin} دقيقة</span>
        </div>
        <p class="summary">${escapeHtml(lesson.videoSummary)}</p>
        ${
          lesson.keyFormulas.length > 0
            ? `<div class="formulas">
                <strong>أهم القواعد والمفاهيم:</strong>
                <ul>${lesson.keyFormulas.map((f) => `<li dir="auto">${escapeHtml(f)}</li>`).join('')}</ul>
              </div>`
            : ''
        }
        ${lesson.slides
          .map(
            (slide, idx) => `
          <div class="slide">
            <div class="slide-title">${idx + 1}. ${escapeHtml(slide.heading)}</div>
            <div class="slide-formula" dir="auto">${escapeHtml(slide.formula)}</div>
            <p class="slide-note">${escapeHtml(slide.note)}</p>
          </div>`
          )
          .join('')}
        <div class="handout">
          <strong>${escapeHtml(lesson.handoutTitle)}:</strong> ${escapeHtml(lesson.handoutSummary)}
        </div>
      </div>`
    )
    .join('');

  const examHtml = exam
    ? `
      <div class="exam-box">
        <h3>تدريبات وتقييم المادة: ${escapeHtml(exam.title)}</h3>
        <ol>
          ${exam.questions
            .map(
              (q) => `
            <li>
              <p class="q-prompt">${escapeHtml(q.prompt)}</p>
              <p class="q-opts">الاختيارات: ${q.options.map((o) => escapeHtml(o)).join(' · ')}</p>
              <p class="q-ans"><strong>الإجابة الصحيحة:</strong> ${escapeHtml(q.options[q.correctIndex] || '')} — ${escapeHtml(q.explanation)}</p>
            </li>`
            )
            .join('')}
        </ol>
      </div>`
    : '';

  return `
    <section class="course-section">
      <div class="course-banner">
        <div class="course-meta">${escapeHtml(GRADE_LABELS[course.grade])} · ${escapeHtml(BRANCH_LABELS[course.branch])} · ${course.lessons.length} دروس</div>
        <h2>${escapeHtml(course.title)}</h2>
        <p>${escapeHtml(course.subtitle)}</p>
      </div>
      ${lessonsHtml}
      ${examHtml}
    </section>
  `;
}

function buildDocumentHtml(
  title: string,
  subtitle: string,
  sectionsHtml: string,
  profile?: AcademyProfile
): string {
  const teacher = escapeHtml(profile?.teacherName || 'الأستاذة نجلاء فتحي');
  const platform = escapeHtml(profile?.platformName || 'منصة الأستاذة نجلاء فتحي');
  const year = escapeHtml(profile?.academicYear || '2026 / 2027');

  return `<!doctype html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="UTF-8" />
  <title>${escapeHtml(title)} — ${platform}</title>
  <style>
    body {
      font-family: 'Segoe UI', Tahoma, Arial, sans-serif;
      background: #f8fafc;
      color: #0f172a;
      margin: 0;
      padding: 28px;
      line-height: 1.75;
    }
    .doc-container {
      max-width: 900px;
      margin: 0 auto;
      background: #ffffff;
      border: 1px solid #cbd5e1;
      border-radius: 14px;
      padding: 32px;
    }
    .doc-header {
      border-bottom: 2px solid #1d4ed8;
      padding-bottom: 18px;
      margin-bottom: 24px;
    }
    .doc-kicker {
      color: #1d4ed8;
      font-weight: 700;
      font-size: 13px;
      margin: 0 0 6px 0;
    }
    h1 {
      margin: 0 0 8px 0;
      font-size: 26px;
    }
    .doc-sub {
      color: #475569;
      margin: 0;
      font-size: 14px;
    }
    .course-section {
      margin-bottom: 32px;
      padding-bottom: 24px;
      border-bottom: 1px dashed #cbd5e1;
    }
    .course-banner {
      background: #eff6ff;
      border: 1px solid #bfdbfe;
      border-radius: 10px;
      padding: 16px 20px;
      margin-bottom: 18px;
    }
    .course-meta {
      font-size: 12px;
      color: #1e40af;
      font-weight: 700;
    }
    .course-banner h2 {
      margin: 6px 0;
      font-size: 20px;
    }
    .lesson-box {
      border: 1px solid #e2e8f0;
      border-radius: 10px;
      padding: 16px 20px;
      margin-bottom: 14px;
      background: #ffffff;
    }
    .lesson-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 8px;
    }
    .lesson-header h3 {
      margin: 0;
      font-size: 16px;
      color: #0f172a;
    }
    .meta {
      font-size: 12px;
      color: #64748b;
    }
    .summary {
      margin: 0 0 12px 0;
      color: #334155;
      font-size: 14px;
    }
    .formulas {
      background: #f8fafc;
      border: 1px solid #e2e8f0;
      border-radius: 8px;
      padding: 10px 14px;
      margin-bottom: 12px;
      font-size: 13px;
    }
    .slide {
      background: #f1f5f9;
      border-radius: 8px;
      padding: 10px 14px;
      margin-bottom: 8px;
    }
    .slide-title {
      font-weight: 700;
      font-size: 13px;
      margin-bottom: 4px;
    }
    .slide-formula {
      font-family: Consolas, monospace;
      background: #ffffff;
      border: 1px solid #cbd5e1;
      border-radius: 6px;
      padding: 6px 10px;
      margin: 6px 0;
      color: #1e3a8a;
      font-size: 13px;
    }
    .slide-note {
      margin: 0;
      font-size: 13px;
      color: #334155;
    }
    .handout {
      margin-top: 10px;
      font-size: 13px;
      color: #065f46;
      background: #ecfdf5;
      border: 1px solid #a7f3d0;
      border-radius: 8px;
      padding: 8px 12px;
    }
    .exam-box {
      background: #fffbeb;
      border: 1px solid #fde68a;
      border-radius: 10px;
      padding: 16px 20px;
      margin-top: 14px;
    }
    .exam-box h3 {
      margin: 0 0 10px 0;
      font-size: 16px;
      color: #92400e;
    }
    .q-prompt { font-weight: 700; margin: 0 0 4px 0; font-size: 14px; }
    .q-opts { margin: 0 0 4px 0; font-size: 13px; color: #475569; }
    .q-ans { margin: 0 0 12px 0; font-size: 13px; color: #065f46; }
    .doc-footer {
      text-align: center;
      font-size: 12px;
      color: #64748b;
      margin-top: 24px;
    }
    @media print {
      body { background: #ffffff; padding: 0; }
      .doc-container { border: none; padding: 0; }
    }
  </style>
</head>
<body>
  <div class="doc-container">
    <header class="doc-header">
      <p class="doc-kicker">${platform} · ${teacher} · ${year}</p>
      <h1>${escapeHtml(title)}</h1>
      <p class="doc-sub">${escapeHtml(subtitle)}</p>
    </header>
    ${sectionsHtml}
    <footer class="doc-footer">
      تم إعداد وتصدير هذا المنهج من ${platform} — ${teacher}
    </footer>
  </div>
</body>
</html>`;
}

function triggerFileDownload(filename: string, content: string, mimeType: string): void {
  const blob = new Blob(['\ufeff', content], { type: mimeType });
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement('a');
  anchor.href = url;
  anchor.download = filename;
  document.body.appendChild(anchor);
  anchor.click();
  document.body.removeChild(anchor);
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

export function downloadSingleCourseCurriculum(
  course: Course,
  exam?: Exam,
  profile?: AcademyProfile,
  format: 'html' | 'doc' = 'html'
): void {
  const section = buildCourseSectionHtml(course, exam);
  const html = buildDocumentHtml(
    `منهج: ${course.title}`,
    `${GRADE_LABELS[course.grade]} · ${BRANCH_LABELS[course.branch]} — ملخص الدروس والقواعد والتدريبات`,
    section,
    profile
  );
  const safeSlug = course.id.replace(/[^a-z0-9-_]/gi, '_');
  const ext = format === 'doc' ? 'doc' : 'html';
  const mime = format === 'doc' ? 'application/msword;charset=utf-8' : 'text/html;charset=utf-8';
  triggerFileDownload(`منهج-${safeSlug}.${ext}`, html, mime);
}

export function downloadGradeCurriculum(
  grade: GradeLevel | 'all',
  courses: Course[],
  exams: Exam[],
  profile?: AcademyProfile,
  format: 'html' | 'doc' = 'html'
): void {
  const targetCourses =
    grade === 'all' ? courses : courses.filter((c) => c.grade === grade);
  const sections = targetCourses
    .map((c) => buildCourseSectionHtml(c, exams.find((e) => e.id === c.examId)))
    .join('');

  const gradeTitle =
    grade === 'all'
      ? 'المنهج الشامل لجميع الصفوف والمواد (رياض الأطفال + الابتدائي)'
      : `المنهج الكامل — ${GRADE_LABELS[grade]}`;

  const html = buildDocumentHtml(
    gradeTitle,
    `يشمل ${targetCourses.length} مواد/كورسات كاملة مع الشرح والقواعد ونماذج الأسئلة بالإجابات`,
    sections,
    profile
  );
  const ext = format === 'doc' ? 'doc' : 'html';
  const mime = format === 'doc' ? 'application/msword;charset=utf-8' : 'text/html;charset=utf-8';
  triggerFileDownload(`منهج-${grade}.${ext}`, html, mime);
}
