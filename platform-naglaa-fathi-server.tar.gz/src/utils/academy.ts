import type { GradeLevel, SubjectBranch, TopupMethod } from '../types.ts';

export const GRADE_LABELS: Record<GradeLevel, string> = {
  kg: 'رياض الأطفال (KG1 · KG2)',
  p1: 'الصف الأول الابتدائي',
  p2: 'الصف الثاني الابتدائي',
  p3: 'الصف الثالث الابتدائي',
  p4: 'الصف الرابع الابتدائي',
  p5: 'الصف الخامس الابتدائي',
  p6: 'الصف السادس الابتدائي',
};

export const GRADE_SHORT_LABELS: Record<GradeLevel, string> = {
  kg: 'رياض الأطفال',
  p1: 'أولى ابتدائي',
  p2: 'تانية ابتدائي',
  p3: 'تالتة ابتدائي',
  p4: 'رابعة ابتدائي',
  p5: 'خامسة ابتدائي',
  p6: 'سادسة ابتدائي',
};

export const PRIMARY_GRADES: GradeLevel[] = ['p1', 'p2', 'p3', 'p4', 'p5', 'p6'];

export const BRANCH_LABELS: Record<SubjectBranch, string> = {
  arabic: 'اللغة العربية',
  math: 'الرياضيات',
  kg_arabic: 'تأسيس العربي (نور البيان)',
  kg_math: 'تأسيس الحساب',
  kg_english: 'تأسيس الإنجليزي (Phonics)',
  kg_discover: 'اكتشف والعلوم والمهارات',
};

export const TOPUP_METHOD_LABELS: Record<TopupMethod, string> = {
  vodafone_cash: 'فودافون كاش',
  instapay: 'إنستاباي (InstaPay)',
  fawry: 'فوري (Fawry)',
};

export const EGYPT_GOVERNORATES = [
  'القاهرة',
  'الجيزة',
  'الإسكندرية',
  'الدقهلية',
  'الشرقية',
  'الغربية',
  'المنوفية',
  'القليوبية',
  'أسيوط',
  'سوهاج',
  'المنيا',
  'بني سويف',
  'الإسماعيلية',
  'بورسعيد',
];

export function formatEgp(amount: number): string {
  if (amount <= 0) return 'مجاني';
  return `${amount.toLocaleString('en-US')} ج.م`;
}

export function formatArabicDate(iso: string): string {
  try {
    return new Date(iso).toLocaleDateString('ar-EG', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
    });
  } catch {
    return iso;
  }
}

export function formatArabicDateTime(iso: string): string {
  try {
    return new Date(iso).toLocaleString('ar-EG', {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  } catch {
    return iso;
  }
}
