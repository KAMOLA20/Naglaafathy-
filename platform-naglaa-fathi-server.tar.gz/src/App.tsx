import { Bell, CheckCircle2, MessageCircle, MessageSquare, Moon, Phone, Sun, X, XCircle } from 'lucide-react';
import { AcademyProvider, useAcademy } from './context/AcademyContext.tsx';
import { AcademyHome } from './components/AcademyHome.tsx';
import { CourseClassroom } from './components/CourseClassroom.tsx';
import { HonorRollView } from './components/HonorRollView.tsx';
import { KindergartenPage } from './components/KindergartenPage.tsx';
import { LecturePushAlerts } from './components/LecturePushAlerts.tsx';
import { PrimaryInteractiveLab } from './components/PrimaryInteractiveLab.tsx';
import { StudentPortal } from './components/StudentPortal.tsx';
import { SupportChatDrawer, formatPhoneDigits, formatWhatsappHref } from './components/SupportChatDrawer.tsx';
import { AcademyEmblem, BrandLogo } from './components/BrandLogo.tsx';
import { TeacherDashboard } from './components/TeacherDashboard.tsx';
import type { AppSection } from './types.ts';

function AcademyShell() {
  const {
    snapshot,
    loading,
    currentStudent,
    activeSection,
    setActiveSection,
    setIsChatOpen,
    activePushAlerts,
    upcomingAlertsCount,
    setIsAlertsOpen,
    theme,
    toggleTheme,
    toast,
    clearToast,
  } = useAcademy();

  const navLinks: { id: AppSection; label: string }[] = [
    { id: 'catalog', label: 'دروس الابتدائي' },
    { id: 'kindergarten', label: 'تأسيس رياض الأطفال' },
    { id: 'interactive-lab', label: 'المختبر التفاعلي' },
    { id: 'honor-roll', label: 'لوحة الشرف' },
    { id: 'admin', label: 'لوحة المعلم' },
  ];

  const brandName = snapshot?.profile.platformName || 'منصة الأستاذة نجلاء فتحي';
  const hotline = snapshot?.profile.hotline || '01029121467';
  const phoneDigits = formatPhoneDigits(hotline);
  const whatsappUrl = formatWhatsappHref(hotline);

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 transition-colors">
      {/* Top Bar Contract: Zone 1 Brand Wordmark — Zone 2 Concise Nav Links — Zone 3 Primary Action */}
      <header className="bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 sticky top-0 z-40 transition-colors">
        <div className="max-w-[1440px] mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-4 sm:gap-8">
          <a
            href="/"
            onClick={(e) => {
              e.preventDefault();
              setActiveSection('catalog');
            }}
            className="whitespace-nowrap shrink-0 hover:opacity-90 transition-opacity"
          >
            <BrandLogo brandName={brandName} size={34} />
          </a>

          <nav aria-label="التنقل الرئيسي" className="flex items-center gap-4 sm:gap-6 overflow-x-auto">
            {navLinks.map((link) => {
              const isActive =
                activeSection === link.id ||
                (link.id === 'catalog' && activeSection === 'classroom');
              return (
                <button
                  key={link.id}
                  type="button"
                  onClick={() => setActiveSection(link.id)}
                  className={`py-2 text-xs sm:text-sm font-medium whitespace-nowrap shrink-0 border-b-2 transition-colors cursor-pointer ${
                    isActive
                      ? 'border-blue-700 dark:border-blue-400 text-slate-900 dark:text-white font-semibold'
                      : 'border-transparent text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-100'
                  }`}
                >
                  {link.label}
                </button>
              );
            })}
          </nav>

          <div className="flex items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={toggleTheme}
              aria-label={theme === 'dark' ? 'التبديل إلى الوضع الفاتح' : 'التبديل إلى الوضع الداكن'}
              title={theme === 'dark' ? 'الوضع الفاتح' : 'الوضع الداكن'}
              className="inline-flex items-center gap-1.5 px-3 py-2 min-h-[40px] text-xs font-semibold text-slate-800 dark:text-slate-100 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-xl transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              {theme === 'dark' ? (
                <Sun className="w-4 h-4 text-amber-400" />
              ) : (
                <Moon className="w-4 h-4 text-slate-700" />
              )}
              <span className="hidden xl:inline">{theme === 'dark' ? 'فاتح' : 'داكن'}</span>
            </button>

            <button
              type="button"
              onClick={() => setIsAlertsOpen(true)}
              aria-label="تنبيهات ومواعيد المحاضرات القادمة"
              className="inline-flex items-center gap-1.5 px-3 py-2 min-h-[40px] text-xs font-semibold text-slate-800 dark:text-slate-100 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-xl transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              <Bell className={`w-4 h-4 ${activePushAlerts.length > 0 ? 'text-amber-600 dark:text-amber-400' : 'text-slate-700 dark:text-slate-300'}`} />
              <span className="hidden md:inline">التنبيهات</span>
              {(activePushAlerts.length > 0 || upcomingAlertsCount > 0) && (
                <span className="px-1.5 py-0.5 bg-amber-400 text-slate-950 text-[11px] font-extrabold rounded-md font-mono tabular-nums">
                  {activePushAlerts.length || upcomingAlertsCount}
                </span>
              )}
            </button>

            <button
              type="button"
              onClick={() => setActiveSection('student')}
              className="px-4 py-2 min-h-[40px] text-xs font-semibold text-white bg-slate-900 dark:bg-blue-700 hover:bg-slate-800 dark:hover:bg-blue-800 rounded-xl transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              {currentStudent
                ? `${currentStudent.name.split(' ')[0]} · ${currentStudent.walletBalance} ج.م`
                : 'حساب الطالب'}
            </button>
          </div>
        </div>
      </header>

      {/* Toast Notification Bar */}
      {toast && (
        <div className="max-w-[1440px] w-full mx-auto px-4 sm:px-6 pt-4">
          <div
            role="status"
            className={`rounded-xl border px-4 py-3 flex items-center justify-between gap-3 text-xs sm:text-sm font-medium ${
              toast.type === 'success'
                ? 'bg-emerald-50 dark:bg-emerald-950/70 border-emerald-200 dark:border-emerald-800 text-emerald-900 dark:text-emerald-200'
                : 'bg-red-50 dark:bg-red-950/70 border-red-200 dark:border-red-800 text-red-900 dark:text-red-200'
            }`}
          >
            <div className="flex items-center gap-2">
              {toast.type === 'success' ? (
                <CheckCircle2 className="w-4 h-4 text-emerald-700 dark:text-emerald-400 shrink-0" />
              ) : (
                <XCircle className="w-4 h-4 text-red-700 dark:text-red-400 shrink-0" />
              )}
              <span>{toast.text}</span>
            </div>
            <button
              type="button"
              onClick={clearToast}
              aria-label="إغلاق التنبيه"
              className="p-1 text-slate-500 dark:text-slate-300 hover:text-slate-800 dark:hover:text-white cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* Main Content */}
      <main className="flex-1 max-w-[1440px] w-full mx-auto px-4 sm:px-6 py-6">
        {loading ? (
          <div className="py-24 text-center text-sm text-slate-500 dark:text-slate-400">
            جاري تحميل دروس المرحلة الابتدائية وقسم رياض الأطفال...
          </div>
        ) : activeSection === 'catalog' ? (
          <AcademyHome />
        ) : activeSection === 'kindergarten' ? (
          <KindergartenPage />
        ) : activeSection === 'classroom' ? (
          <CourseClassroom />
        ) : activeSection === 'interactive-lab' ? (
          <PrimaryInteractiveLab />
        ) : activeSection === 'honor-roll' ? (
          <HonorRollView />
        ) : activeSection === 'student' ? (
          <StudentPortal />
        ) : (
          <TeacherDashboard />
        )}
      </main>

      {/* Quiet Editorial Footer */}
      <footer className="bg-white dark:bg-slate-900 border-t border-slate-200 dark:border-slate-800 py-6 mt-auto pb-20 sm:pb-6 transition-colors">
        <div className="max-w-[1440px] mx-auto px-4 sm:px-6 flex flex-col lg:flex-row items-center justify-between gap-4 text-xs text-slate-500 dark:text-slate-400">
          <div className="flex flex-wrap items-center justify-center lg:justify-start gap-3">
            <AcademyEmblem size={22} />
            <p>
              © {new Date().getFullYear()} {brandName} — اللغة العربية والرياضيات (1–6 ابتدائي) وتأسيس رياض الأطفال
            </p>
            <span aria-hidden="true" className="hidden sm:inline">·</span>
            <a
              href={`tel:${phoneDigits}`}
              className="inline-flex items-center gap-1 font-bold text-slate-800 dark:text-slate-200 hover:text-blue-700 dark:hover:text-blue-400"
            >
              <Phone className="w-3.5 h-3.5 text-blue-700 dark:text-blue-400" />
              <span className="font-mono tabular-nums" dir="ltr">
                {hotline}
              </span>
            </a>
            <a
              href={whatsappUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1 font-bold text-emerald-700 dark:text-emerald-400 hover:text-emerald-800 dark:hover:text-emerald-300"
            >
              <MessageCircle className="w-3.5 h-3.5" />
              <span>واتساب مباشر</span>
            </a>
            <button
              type="button"
              onClick={() => setIsChatOpen(true)}
              className="inline-flex items-center gap-1 font-bold text-blue-700 dark:text-blue-400 hover:text-blue-800 dark:hover:text-blue-300 cursor-pointer"
            >
              <MessageSquare className="w-3.5 h-3.5" />
              <span>محادثة داخل الموقع</span>
            </button>
          </div>
          <div className="flex flex-wrap items-center justify-center gap-4">
            <button
              type="button"
              onClick={() => setActiveSection('catalog')}
              className="hover:text-slate-900 dark:hover:text-slate-100 cursor-pointer"
            >
              دروس الابتدائي
            </button>
            <button
              type="button"
              onClick={() => setActiveSection('kindergarten')}
              className="hover:text-slate-900 dark:hover:text-slate-100 cursor-pointer"
            >
              تأسيس رياض الأطفال
            </button>
            <button
              type="button"
              onClick={() => setActiveSection('interactive-lab')}
              className="hover:text-slate-900 dark:hover:text-slate-100 cursor-pointer"
            >
              المختبر التفاعلي
            </button>
            <button
              type="button"
              onClick={() => setActiveSection('admin')}
              className="hover:text-slate-900 dark:hover:text-slate-100 cursor-pointer"
            >
              لوحة المعلم
            </button>
          </div>
        </div>
      </footer>

      <SupportChatDrawer />
      <LecturePushAlerts />
    </div>
  );
}

export default function App() {
  return (
    <AcademyProvider>
      <AcademyShell />
    </AcademyProvider>
  );
}
