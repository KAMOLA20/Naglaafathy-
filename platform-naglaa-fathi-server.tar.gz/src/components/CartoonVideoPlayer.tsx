import { useEffect, useMemo, useRef, useState } from 'react';
import {
  Captions,
  CheckCircle2,
  ChevronLeft,
  ChevronRight,
  History,
  Maximize2,
  Minimize2,
  Pause,
  Play,
  RotateCcw,
  UserCheck,
  Volume2,
  VolumeX,
} from 'lucide-react';
import type { Course, Lesson, LessonAttendance, Student } from '../types.ts';
import { BRANCH_LABELS, GRADE_SHORT_LABELS } from '../utils/academy.ts';
import { speechController } from '../utils/speech.ts';
import { AnimatedCartoonStage } from './AnimatedCartoonStage.tsx';

interface CartoonVideoPlayerProps {
  course: Course;
  lesson: Lesson;
  teacherName: string;
  currentStudent: Student | null;
  attendance?: LessonAttendance | null;
  resumeTrigger?: number;
  onRecordAttendance?: (payload: {
    lessonId: string;
    watchedPercent: number;
    watchedSeconds: number;
    lastPositionSec?: number;
    lastSceneIndex?: number;
    checkedIn?: boolean;
    silent?: boolean;
  }) => Promise<LessonAttendance | null>;
  onCompleteLesson: (lessonId: string, durationMin: number) => Promise<void>;
}

interface VideoScene {
  id: string;
  label: string;
  teacherLine: string;
  boardTitle: string;
  boardHighlight: string;
  boardNote: string;
  speechLang: 'ar-EG' | 'en-US';
}

function getRevealedWords(text: string, progress: number, isActive: boolean): string {
  if (!isActive && progress <= 0.02) return text;
  const words = text.split(' ');
  const ratio = Math.min(1, Math.max(0.2, progress * 1.45));
  const count = Math.max(1, Math.ceil(words.length * ratio));
  return words.slice(0, count).join(' ');
}

interface SavedResumePoint {
  lastPositionSec: number;
  lastSceneIndex: number;
  progressPct: number;
  updatedAt: string;
}

function getResumeStorageKey(studentId: string | undefined, lessonId: string): string {
  return `qema_resume_v1:${studentId || 'guest'}:${lessonId}`;
}

function readLocalResume(studentId: string | undefined, lessonId: string): SavedResumePoint | null {
  if (typeof window === 'undefined') return null;
  try {
    const raw = localStorage.getItem(getResumeStorageKey(studentId, lessonId));
    if (!raw) return null;
    const parsed = JSON.parse(raw) as Partial<SavedResumePoint>;
    if (typeof parsed.lastPositionSec !== 'number' || !Number.isFinite(parsed.lastPositionSec)) {
      return null;
    }
    return {
      lastPositionSec: Math.max(0, Math.round(parsed.lastPositionSec)),
      lastSceneIndex: Math.max(0, Math.round(Number(parsed.lastSceneIndex || 0))),
      progressPct: Math.min(100, Math.max(0, Number(parsed.progressPct || 0))),
      updatedAt: String(parsed.updatedAt || ''),
    };
  } catch {
    return null;
  }
}

function writeLocalResume(
  studentId: string | undefined,
  lessonId: string,
  point: SavedResumePoint
): void {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(getResumeStorageKey(studentId, lessonId), JSON.stringify(point));
  } catch {
    // ignore storage quota issues
  }
}

export function CartoonVideoPlayer({
  course,
  lesson,
  teacherName,
  currentStudent,
  attendance,
  resumeTrigger = 0,
  onRecordAttendance,
  onCompleteLesson,
}: CartoonVideoPlayerProps) {
  const [isPlaying, setIsPlaying] = useState(false);
  const [voiceEnabled, setVoiceEnabled] = useState(true);
  const [captionsEnabled, setCaptionsEnabled] = useState(true);
  const [speed, setSpeed] = useState<1 | 1.25 | 1.5>(1);
  const [progressPct, setProgressPct] = useState(0);
  const [verifiedWatchPct, setVerifiedWatchPct] = useState<number>(
    attendance?.watchedPercent || 0
  );
  const [watchedSeconds, setWatchedSeconds] = useState<number>(
    attendance?.watchedSeconds || 0
  );
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [resumePrompt, setResumePrompt] = useState<SavedResumePoint | null>(null);
  const [lastSavedNoticeSec, setLastSavedNoticeSec] = useState<number | null>(null);

  const stageContainerRef = useRef<HTMLDivElement | null>(null);
  const lastSpokenSceneRef = useRef<number>(-1);
  const lastSyncedMilestoneRef = useRef<number>(attendance?.watchedPercent || 0);
  const secondsAccumRef = useRef<number>(0);
  const latestPositionRef = useRef<{ sec: number; scene: number; pct: number; watchedPct: number; watchedSec: number }>({
    sec: 0,
    scene: 0,
    pct: 0,
    watchedPct: attendance?.watchedPercent || 0,
    watchedSec: attendance?.watchedSeconds || 0,
  });

  const scenes: VideoScene[] = useMemo(() => {
    const lang: 'ar-EG' | 'en-US' = course.branch === 'kg_english' ? 'en-US' : 'ar-EG';
    const gradeLabel = GRADE_SHORT_LABELS[course.grade];
    const introSpeech =
      lang === 'en-US'
        ? `Hello little stars! Welcome to ${lesson.title}. ${lesson.videoSummary}`
        : `أهلاً بكم أبطال ${gradeLabel}، معاكم ${teacherName}. النهارده هنشرح مع بعض المحاضرة رقم ${lesson.order}: ${lesson.title}. ${lesson.videoSummary}`;

    const introScene: VideoScene = {
      id: `${lesson.id}-intro`,
      label: 'مقدمة الدرس',
      teacherLine: introSpeech,
      boardTitle: lesson.title,
      boardHighlight: lesson.keyFormulas[0] || course.title,
      boardNote: lesson.videoSummary,
      speechLang: lang,
    };

    const slideScenes: VideoScene[] = lesson.slides.map((s, idx) => ({
      id: `${lesson.id}-slide-${idx}`,
      label: `مشهد الشرح ${idx + 1}`,
      teacherLine:
        lang === 'en-US'
          ? `${s.heading}. ${s.note}`
          : `ركز يا بطل في النقطة دي: ${s.heading}. ${s.note}`,
      boardTitle: s.heading,
      boardHighlight: s.formula,
      boardNote: s.note,
      speechLang: lang,
    }));

    const outroScene: VideoScene = {
      id: `${lesson.id}-outro`,
      label: 'ملخص وتطبيق',
      teacherLine:
        lang === 'en-US'
          ? `Great job! Let's review our key takeaway and solve the worksheet.`
          : `أحسنت يا بطل! كده خلصنا شرح المحاضرة ${lesson.order}. راجع الملخص وحل تدريبات الملزمة.`,
      boardTitle: `ملخص المحاضرة ${lesson.order} · الأسبوع ${lesson.weekNumber || Math.ceil(lesson.order / 2)}`,
      boardHighlight: lesson.handoutTitle,
      boardNote: `${lesson.handoutSummary} — استمر حتى نهاية الفيديو لتأكيد حضورك الكامل.`,
      speechLang: lang,
    };

    return [introScene, ...slideScenes, outroScene];
  }, [course.branch, course.grade, course.title, lesson, teacherName]);

  const { activeSceneIndex, sceneProgress } = useMemo(() => {
    if (scenes.length <= 1) {
      return { activeSceneIndex: 0, sceneProgress: Math.min(1, progressPct / 100) };
    }
    const scaled = (progressPct / 100) * scenes.length;
    const idx = Math.min(scenes.length - 1, Math.max(0, Math.floor(scaled)));
    const localProg = Math.min(1, Math.max(0, scaled - idx));
    return { activeSceneIndex: idx, sceneProgress: localProg };
  }, [progressPct, scenes.length]);

  const currentScene = scenes[activeSceneIndex] || scenes[0];
  const effectiveWatchPct = Math.max(verifiedWatchPct, attendance?.watchedPercent || 0);
  const isFullyAttended =
    Boolean(attendance?.fullyWatched) || effectiveWatchPct >= 90;
  const isCompleted =
    Boolean(currentStudent?.completedLessonIds.includes(lesson.id)) && isFullyAttended;

  const totalSeconds = Math.max(60, lesson.durationMin * 60);

  // Keep latest playback checkpoint updated in ref
  useEffect(() => {
    const posSec = Math.round((progressPct / 100) * totalSeconds);
    latestPositionRef.current = {
      sec: posSec,
      scene: activeSceneIndex,
      pct: progressPct,
      watchedPct: verifiedWatchPct,
      watchedSec: watchedSeconds,
    };
  }, [progressPct, totalSeconds, activeSceneIndex, verifiedWatchPct, watchedSeconds]);

  // Reset player & load saved Resume Watching checkpoint when switching lessons
  useEffect(() => {
    speechController.stop();
    setIsPlaying(false);
    setIsSpeaking(false);
    const savedPct = attendance?.watchedPercent || 0;
    const savedSec = attendance?.watchedSeconds || 0;
    setVerifiedWatchPct(savedPct);
    setWatchedSeconds(savedSec);
    lastSyncedMilestoneRef.current = savedPct;
    secondsAccumRef.current = 0;
    lastSpokenSceneRef.current = -1;

    const localResume = readLocalResume(currentStudent?.id, lesson.id);
    const serverPosSec = attendance?.lastPositionSec || 0;
    const serverPct = serverPosSec > 0 ? Math.min(99, (serverPosSec / totalSeconds) * 100) : 0;

    let bestResume: SavedResumePoint | null = null;
    if (localResume && localResume.lastPositionSec > 2 && localResume.progressPct < 98) {
      bestResume = localResume;
    }
    if (serverPosSec > 2 && serverPct < 98) {
      if (!bestResume || serverPosSec >= bestResume.lastPositionSec) {
        bestResume = {
          lastPositionSec: serverPosSec,
          lastSceneIndex: attendance?.lastSceneIndex || 0,
          progressPct: serverPct,
          updatedAt: attendance?.lastActivityAt || new Date().toISOString(),
        };
      }
    }

    if (bestResume) {
      setResumePrompt(bestResume);
      setProgressPct(bestResume.progressPct);
      setLastSavedNoticeSec(bestResume.lastPositionSec);
    } else {
      setResumePrompt(null);
      setProgressPct(0);
      setLastSavedNoticeSec(null);
    }

    return () => {
      speechController.stop();
      const latest = latestPositionRef.current;
      if (latest.sec > 2 && latest.pct < 98) {
        writeLocalResume(currentStudent?.id, lesson.id, {
          lastPositionSec: latest.sec,
          lastSceneIndex: latest.scene,
          progressPct: latest.pct,
          updatedAt: new Date().toISOString(),
        });
      }
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [lesson.id, currentStudent?.id]);

  // Keep synced if attendance record updates from backend
  useEffect(() => {
    if (attendance) {
      setVerifiedWatchPct((prev) => Math.max(prev, attendance.watchedPercent));
      setWatchedSeconds((prev) => Math.max(prev, attendance.watchedSeconds));
    }
  }, [attendance]);

  // Auto-save Resume Watching point every 2 seconds while playing
  useEffect(() => {
    if (!isPlaying) return;
    const saveTimer = window.setInterval(() => {
      const latest = latestPositionRef.current;
      if (latest.sec > 0) {
        writeLocalResume(currentStudent?.id, lesson.id, {
          lastPositionSec: latest.sec,
          lastSceneIndex: latest.scene,
          progressPct: latest.pct,
          updatedAt: new Date().toISOString(),
        });
        setLastSavedNoticeSec(latest.sec);
      }
    }, 2000);
    return () => window.clearInterval(saveTimer);
  }, [isPlaying, currentStudent?.id, lesson.id]);

  // Smooth continuous video playback timer + genuine active watch tracking
  useEffect(() => {
    if (!isPlaying) return;
    const tickMs = 80;
    const stepPerTick = 0.28 * speed;
    const timer = setInterval(() => {
      setProgressPct((prev) => {
        if (prev >= 100) {
          setIsPlaying(false);
          speechController.stop();
          setIsSpeaking(false);
          writeLocalResume(currentStudent?.id, lesson.id, {
            lastPositionSec: 0,
            lastSceneIndex: 0,
            progressPct: 100,
            updatedAt: new Date().toISOString(),
          });
          setResumePrompt(null);
          return 100;
        }
        return Math.min(100, prev + stepPerTick);
      });

      // Verified active watch progress only increments while genuinely playing
      setVerifiedWatchPct((prev) => Math.min(100, prev + stepPerTick));
      secondsAccumRef.current += tickMs / 1000;
      if (secondsAccumRef.current >= 1) {
        const whole = Math.floor(secondsAccumRef.current);
        secondsAccumRef.current -= whole;
        setWatchedSeconds((s) => s + whole);
      }
    }, tickMs);
    return () => clearInterval(timer);
  }, [isPlaying, speed, currentStudent?.id, lesson.id]);

  // Sync watch attendance milestones cleanly to backend (every ~20% or upon hitting 90% / 100%)
  useEffect(() => {
    if (!currentStudent || !onRecordAttendance) return;
    const rounded = Math.round(verifiedWatchPct);
    const prevSynced = lastSyncedMilestoneRef.current;
    const hitCompletionThreshold = rounded >= 90 && prevSynced < 90;
    const hitFinish = rounded >= 100 && prevSynced < 100;
    const steppedBy20 = rounded - prevSynced >= 20;

    if (hitCompletionThreshold || hitFinish || steppedBy20) {
      lastSyncedMilestoneRef.current = rounded;
      const latest = latestPositionRef.current;
      void onRecordAttendance({
        lessonId: lesson.id,
        watchedPercent: rounded,
        watchedSeconds,
        lastPositionSec: latest.sec,
        lastSceneIndex: latest.scene,
        checkedIn: true,
        silent: true,
      });
    }
  }, [currentStudent, lesson.id, onRecordAttendance, verifiedWatchPct, watchedSeconds]);

  // Synchronized cartoon teacher voice narration per scene
  useEffect(() => {
    if (!isPlaying || !voiceEnabled) {
      if (!isPlaying) {
        speechController.stop();
        setIsSpeaking(false);
        lastSpokenSceneRef.current = -1;
      }
      return;
    }

    if (lastSpokenSceneRef.current !== activeSceneIndex && currentScene) {
      lastSpokenSceneRef.current = activeSceneIndex;
      const speechRate = speed === 1.5 ? 1.08 : speed === 1.25 ? 0.98 : 0.9;
      speechController.speak(currentScene.teacherLine, {
        lang: currentScene.speechLang,
        rate: speechRate,
        onStart: () => setIsSpeaking(true),
        onEnd: () => setIsSpeaking(false),
        onError: () => setIsSpeaking(false),
      });
    }
  }, [activeSceneIndex, currentScene, isPlaying, speed, voiceEnabled]);

  useEffect(() => {
    const onFsChange = () => {
      setIsFullscreen(Boolean(document.fullscreenElement));
    };
    document.addEventListener('fullscreenchange', onFsChange);
    return () => document.removeEventListener('fullscreenchange', onFsChange);
  }, []);

  const jumpToScene = (idx: number) => {
    const safeIdx = Math.max(0, Math.min(scenes.length - 1, idx));
    const pct = (safeIdx / scenes.length) * 100 + 0.5;
    lastSpokenSceneRef.current = -1;
    const nextPct = Math.min(99, pct);
    setProgressPct(nextPct);
    const posSec = Math.round((nextPct / 100) * totalSeconds);
    writeLocalResume(currentStudent?.id, lesson.id, {
      lastPositionSec: posSec,
      lastSceneIndex: safeIdx,
      progressPct: nextPct,
      updatedAt: new Date().toISOString(),
    });
    setLastSavedNoticeSec(posSec);
  };

  const handleResumeFromCheckpoint = (point: SavedResumePoint) => {
    speechController.stop();
    lastSpokenSceneRef.current = -1;
    setProgressPct(point.progressPct);
    setResumePrompt(null);
    setIsPlaying(true);
  };

  useEffect(() => {
    if (resumeTrigger > 0 && resumePrompt) {
      handleResumeFromCheckpoint(resumePrompt);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [resumeTrigger]);

  const handleTogglePlay = () => {
    if (isPlaying) {
      setIsPlaying(false);
      speechController.stop();
      setIsSpeaking(false);
      const posSec = Math.round((progressPct / 100) * totalSeconds);
      writeLocalResume(currentStudent?.id, lesson.id, {
        lastPositionSec: posSec,
        lastSceneIndex: activeSceneIndex,
        progressPct,
        updatedAt: new Date().toISOString(),
      });
      setLastSavedNoticeSec(posSec);
      if (currentStudent && onRecordAttendance) {
        void onRecordAttendance({
          lessonId: lesson.id,
          watchedPercent: Math.round(verifiedWatchPct),
          watchedSeconds,
          lastPositionSec: posSec,
          lastSceneIndex: activeSceneIndex,
          checkedIn: true,
          silent: true,
        });
      }
    } else {
      if (progressPct >= 99) {
        setProgressPct(0);
      }
      setResumePrompt(null);
      lastSpokenSceneRef.current = -1;
      setIsPlaying(true);
      // Automatically record student check-in when starting playback
      if (currentStudent && onRecordAttendance && !attendance?.checkedIn) {
        const posSec = Math.round((progressPct / 100) * totalSeconds);
        void onRecordAttendance({
          lessonId: lesson.id,
          watchedPercent: Math.max(1, Math.round(verifiedWatchPct)),
          watchedSeconds,
          lastPositionSec: posSec,
          lastSceneIndex: activeSceneIndex,
          checkedIn: true,
          silent: true,
        });
      }
    }
  };

  const handleToggleVoice = () => {
    if (voiceEnabled) {
      speechController.stop();
      setIsSpeaking(false);
      setVoiceEnabled(false);
    } else {
      lastSpokenSceneRef.current = -1;
      setVoiceEnabled(true);
    }
  };

  const handleToggleFullscreen = async () => {
    try {
      if (!document.fullscreenElement && stageContainerRef.current) {
        await stageContainerRef.current.requestFullscreen();
      } else if (document.fullscreenElement) {
        await document.exitFullscreen();
      }
    } catch {
      // Ignore fullscreen denial inside restricted iframes
    }
  };

  const elapsedSeconds = Math.round((progressPct / 100) * totalSeconds);
  const fmtTime = (sec: number) => {
    const m = Math.floor(sec / 60);
    const s = sec % 60;
    return `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
  };

  const revealedTitle = getRevealedWords(currentScene.boardTitle, sceneProgress, isPlaying);
  const revealedNote = getRevealedWords(currentScene.boardNote, sceneProgress, isPlaying);

  return (
    <div
      ref={stageContainerRef}
      className="bg-slate-950 border border-slate-800 rounded-2xl overflow-hidden text-white flex flex-col justify-between"
    >
      {/* Top Video Header */}
      <div className="px-5 py-3 border-b border-slate-800 flex flex-wrap items-center justify-between gap-3 text-xs">
        <div className="flex flex-wrap items-center gap-2 text-slate-200">
          <span className="font-bold text-amber-300">
            فيديو كرتوني متحرك · الأسبوع {lesson.weekNumber || Math.ceil(lesson.order / 2)}
          </span>
          <span aria-hidden="true" className="text-slate-600">·</span>
          <span className="font-semibold text-white">
            المحاضرة {lesson.order} من {course.lessons.length}: {lesson.title}
          </span>
        </div>

        <div className="flex flex-wrap items-center gap-3 text-slate-400 font-mono tabular-nums">
          {lastSavedNoticeSec !== null && lastSavedNoticeSec > 2 && (
            <span className="text-emerald-400">
              محفوظ تلقائياً عند {fmtTime(lastSavedNoticeSec)}
            </span>
          )}
          <span>
            {BRANCH_LABELS[course.branch]} · نسبة المشاهدة المسجلة: {Math.round(effectiveWatchPct)}%
          </span>
        </div>
      </div>

      {/* Resume Watching Banner when saved playback checkpoint exists */}
      {resumePrompt && !isPlaying && (
        <div className="bg-blue-950/90 border-b border-blue-800 px-5 py-2.5 flex flex-wrap items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-2 text-blue-100">
            <History className="w-4 h-4 text-amber-400 shrink-0" />
            <span>
              تم حفظ آخر نقطة توقف لك في هذا الدرس عند الدقيقة{' '}
              <span className="font-mono font-bold text-amber-300 tabular-nums">
                {fmtTime(resumePrompt.lastPositionSec)}
              </span>
            </span>
          </div>
          <div className="flex items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={() => handleResumeFromCheckpoint(resumePrompt)}
              className="inline-flex items-center gap-1.5 px-3.5 py-1.5 min-h-[34px] bg-amber-400 hover:bg-amber-300 text-slate-950 font-extrabold rounded-lg transition-colors cursor-pointer"
            >
              <Play className="w-3.5 h-3.5 fill-current" />
              <span>متابعة المشاهدة من {fmtTime(resumePrompt.lastPositionSec)}</span>
            </button>
            <button
              type="button"
              onClick={() => {
                speechController.stop();
                lastSpokenSceneRef.current = -1;
                setResumePrompt(null);
                setProgressPct(0);
                writeLocalResume(currentStudent?.id, lesson.id, {
                  lastPositionSec: 0,
                  lastSceneIndex: 0,
                  progressPct: 0,
                  updatedAt: new Date().toISOString(),
                });
                setIsPlaying(true);
              }}
              className="px-3 py-1.5 min-h-[34px] bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold rounded-lg transition-colors cursor-pointer"
            >
              البدء من 00:00
            </button>
          </div>
        </div>
      )}

      {/* Unified Widescreen Animated Cartoon Theater */}
      <div className="relative bg-slate-900">
        <div
          dir="ltr"
          onClick={handleTogglePlay}
          className="relative w-full aspect-[16/9] min-h-[240px] cursor-pointer select-none overflow-hidden"
        >
          <AnimatedCartoonStage
            branch={course.branch}
            isPlaying={isPlaying}
            isSpeaking={isSpeaking}
            speed={speed}
            sceneProgress={sceneProgress}
            sceneIndex={activeSceneIndex}
          />

          {/* Desktop / Tablet Crisp Chalkboard Overlay */}
          <div
            dir="rtl"
            onClick={(e) => e.stopPropagation()}
            className="hidden md:flex flex-col justify-between absolute left-[4.8%] top-[9.5%] w-[55.5%] h-[70%] p-4 lg:p-6 pointer-events-auto"
          >
            <div className="flex items-center justify-between text-[11px] text-emerald-200/80 border-b border-emerald-500/25 pb-2">
              <span className="font-semibold">{teacherName} · {currentScene.label}</span>
              <span className="font-mono tabular-nums">
                مشهد {activeSceneIndex + 1} / {scenes.length}
              </span>
            </div>

            <div className="space-y-3 my-auto">
              <div>
                <h2 className="text-base lg:text-xl font-extrabold text-white font-display leading-snug">
                  {revealedTitle}
                </h2>
                <div
                  className="h-0.5 bg-amber-300/85 rounded-full mt-1.5 transition-all duration-300"
                  style={{ width: `${Math.max(18, Math.min(100, Math.round(sceneProgress * 120)))}%` }}
                />
              </div>

              <div
                dir="auto"
                className={`bg-slate-950/65 border border-emerald-300/35 rounded-xl px-4 py-3 font-mono text-sm lg:text-lg text-amber-300 text-center tracking-wide transition-all duration-500 ${
                  isPlaying ? 'scale-100 opacity-100' : 'opacity-95'
                }`}
              >
                {currentScene.boardHighlight}
              </div>

              <p className="text-xs lg:text-sm text-emerald-50/95 leading-relaxed line-clamp-3">
                {revealedNote}
              </p>
            </div>

            <div className="flex items-center justify-between pt-2 border-t border-emerald-500/25 text-[11px]">
              <button
                type="button"
                onClick={() => jumpToScene(activeSceneIndex - 1)}
                disabled={activeSceneIndex === 0}
                className="inline-flex items-center gap-1 px-2.5 py-1 bg-emerald-950/80 hover:bg-emerald-900 disabled:opacity-40 text-emerald-100 rounded-lg cursor-pointer"
              >
                <ChevronRight className="w-3.5 h-3.5" />
                <span>المشهد السابق</span>
              </button>

              <div className="flex items-center gap-1.5">
                {scenes.map((sc, idx) => (
                  <button
                    key={sc.id}
                    type="button"
                    onClick={() => jumpToScene(idx)}
                    aria-label={sc.label}
                    className={`h-1.5 rounded-full transition-all cursor-pointer ${
                      idx === activeSceneIndex ? 'w-5 bg-amber-400' : 'w-2 bg-emerald-700'
                    }`}
                  />
                ))}
              </div>

              <button
                type="button"
                onClick={() => jumpToScene(activeSceneIndex + 1)}
                disabled={activeSceneIndex === scenes.length - 1}
                className="inline-flex items-center gap-1 px-2.5 py-1 bg-emerald-950/80 hover:bg-emerald-900 disabled:opacity-40 text-emerald-100 rounded-lg cursor-pointer"
              >
                <span>المشهد التالي</span>
                <ChevronLeft className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {!isPlaying && (
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                handleTogglePlay();
              }}
              aria-label="تشغيل الفيديو الكرتوني المتحرك"
              className="absolute bottom-4 right-4 md:bottom-5 md:right-5 inline-flex items-center gap-2 px-4 py-2.5 bg-blue-700 hover:bg-blue-600 text-white text-xs font-bold rounded-xl shadow-lg transition-transform hover:scale-105 cursor-pointer"
            >
              <Play className="w-4 h-4 fill-current" />
              <span>{progressPct > 0 && progressPct < 99 ? 'استكمال الشرح الكرتوني' : 'تشغيل الفيديو الكرتوني'}</span>
            </button>
          )}
        </div>

        {/* Mobile Synced Chalkboard */}
        <div className="md:hidden bg-[#123328] border-t border-emerald-800 p-4 space-y-3">
          <div className="flex items-center justify-between text-[11px] text-emerald-200">
            <span className="font-semibold">{currentScene.label}</span>
            <span className="font-mono tabular-nums">
              {activeSceneIndex + 1} / {scenes.length}
            </span>
          </div>
          <h2 className="text-base font-extrabold text-white font-display">{revealedTitle}</h2>
          <div
            dir="auto"
            className="bg-slate-950/65 border border-emerald-400/30 rounded-xl p-3 font-mono text-sm text-amber-300 text-center"
          >
            {currentScene.boardHighlight}
          </div>
          <p className="text-xs text-emerald-50 leading-relaxed">{revealedNote}</p>
          <div className="flex items-center justify-between pt-2 border-t border-emerald-800/70 text-xs">
            <button
              type="button"
              onClick={() => jumpToScene(activeSceneIndex - 1)}
              disabled={activeSceneIndex === 0}
              className="inline-flex items-center gap-1 px-2.5 py-1.5 bg-emerald-950 disabled:opacity-40 rounded-lg cursor-pointer"
            >
              <ChevronRight className="w-3.5 h-3.5" />
              <span>السابق</span>
            </button>
            <button
              type="button"
              onClick={() => jumpToScene(activeSceneIndex + 1)}
              disabled={activeSceneIndex === scenes.length - 1}
              className="inline-flex items-center gap-1 px-2.5 py-1.5 bg-emerald-950 disabled:opacity-40 rounded-lg cursor-pointer"
            >
              <span>التالي</span>
              <ChevronLeft className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {captionsEnabled && (
          <div className="bg-slate-950/95 border-t border-slate-800 px-4 py-2.5 text-center text-xs sm:text-sm text-slate-100">
            <span className="font-bold text-amber-300">{teacherName}: </span>
            <span>«{currentScene.teacherLine}»</span>
          </div>
        )}
      </div>

      {/* Video Transport & Attendance Controls Bar */}
      <div className="px-5 py-3.5 bg-slate-900 border-t border-slate-800 space-y-3">
        <input
          type="range"
          min={0}
          max={100}
          value={Math.round(progressPct)}
          onChange={(e) => {
            const nextPct = Number(e.target.value);
            lastSpokenSceneRef.current = -1;
            setProgressPct(nextPct);
            const posSec = Math.round((nextPct / 100) * totalSeconds);
            const estScene = Math.min(scenes.length - 1, Math.max(0, Math.floor((nextPct / 100) * scenes.length)));
            writeLocalResume(currentStudent?.id, lesson.id, {
              lastPositionSec: posSec,
              lastSceneIndex: estScene,
              progressPct: nextPct,
              updatedAt: new Date().toISOString(),
            });
            setLastSavedNoticeSec(posSec);
          }}
          aria-label="شريط تقدم فيديو الشرح الكرتوني"
          className="w-full accent-amber-400 cursor-pointer"
        />

        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={handleTogglePlay}
              className="inline-flex items-center gap-1.5 px-4 py-2 min-h-[38px] bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-lg transition-colors cursor-pointer"
            >
              {isPlaying ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
              <span>{isPlaying ? 'إيقاف الفيديو' : 'تشغيل الشرح الكرتوني'}</span>
            </button>

            <button
              type="button"
              onClick={handleToggleVoice}
              className={`inline-flex items-center gap-1.5 px-3.5 py-2 min-h-[38px] text-xs font-semibold rounded-lg transition-colors cursor-pointer ${
                voiceEnabled
                  ? 'bg-amber-400 text-slate-950 hover:bg-amber-300'
                  : 'bg-slate-800 text-slate-300 border border-slate-700'
              }`}
            >
              {voiceEnabled ? <Volume2 className="w-3.5 h-3.5" /> : <VolumeX className="w-3.5 h-3.5" />}
              <span>{voiceEnabled ? 'صوت الأستاذة: مفعّل' : 'الصوت مكتوم'}</span>
            </button>

            <button
              type="button"
              onClick={() => setCaptionsEnabled((v) => !v)}
              className={`inline-flex items-center gap-1.5 px-3 py-2 min-h-[38px] text-xs font-semibold rounded-lg border transition-colors cursor-pointer ${
                captionsEnabled
                  ? 'bg-slate-800 border-slate-600 text-white'
                  : 'bg-slate-900 border-slate-800 text-slate-400'
              }`}
            >
              <Captions className="w-3.5 h-3.5" />
              <span>الترجمة</span>
            </button>

            <button
              type="button"
              onClick={() => {
                speechController.stop();
                lastSpokenSceneRef.current = -1;
                setProgressPct(0);
                setIsPlaying(true);
              }}
              aria-label="إعادة الفيديو من البداية"
              className="inline-flex items-center gap-1 px-2.5 py-2 min-h-[38px] bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs rounded-lg cursor-pointer"
            >
              <RotateCcw className="w-3.5 h-3.5" />
            </button>

            <button
              type="button"
              onClick={() => void handleToggleFullscreen()}
              aria-label={isFullscreen ? 'إنهاء ملء الشاشة' : 'ملء الشاشة'}
              className="inline-flex items-center gap-1 px-2.5 py-2 min-h-[38px] bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs rounded-lg cursor-pointer"
            >
              {isFullscreen ? <Minimize2 className="w-3.5 h-3.5" /> : <Maximize2 className="w-3.5 h-3.5" />}
            </button>

            <div className="flex items-center gap-1 bg-slate-800 p-1 rounded-lg text-xs">
              {([1, 1.25, 1.5] as const).map((spd) => (
                <button
                  key={spd}
                  type="button"
                  onClick={() => setSpeed(spd)}
                  className={`px-2 py-1 rounded font-mono cursor-pointer ${
                    speed === spd ? 'bg-slate-700 text-white' : 'text-slate-400'
                  }`}
                >
                  {spd}x
                </button>
              ))}
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2.5">
            <span className="text-xs font-mono text-slate-400 tabular-nums">
              {fmtTime(elapsedSeconds)} / {fmtTime(totalSeconds)}
            </span>

            {currentStudent && onRecordAttendance && !attendance?.checkedIn && (
              <button
                type="button"
                onClick={() =>
                  void onRecordAttendance({
                    lessonId: lesson.id,
                    watchedPercent: Math.max(1, Math.round(effectiveWatchPct)),
                    watchedSeconds,
                    checkedIn: true,
                  })
                }
                className="inline-flex items-center gap-1.5 px-3 py-1.5 min-h-[36px] bg-amber-400 hover:bg-amber-300 text-slate-950 text-xs font-bold rounded-lg transition-colors cursor-pointer"
              >
                <UserCheck className="w-3.5 h-3.5" />
                <span>تسجيل الحضور</span>
              </button>
            )}

            {currentStudent && (
              <button
                type="button"
                onClick={() => void onCompleteLesson(lesson.id, lesson.durationMin)}
                disabled={isCompleted || !isFullyAttended}
                title={
                  isFullyAttended
                    ? 'تأكيد إتمام المحاضرة'
                    : 'أكمل مشاهدة 90% من الفيديو الكرتوني لتسجيل الحضور الكامل'
                }
                className={`inline-flex items-center gap-1.5 px-3 py-1.5 min-h-[36px] text-xs font-semibold rounded-lg transition-colors ${
                  isCompleted
                    ? 'bg-emerald-900/60 text-emerald-300 border border-emerald-700'
                    : isFullyAttended
                      ? 'bg-emerald-700 hover:bg-emerald-600 text-white cursor-pointer'
                      : 'bg-slate-800 text-slate-400 border border-slate-700 opacity-80 cursor-not-allowed'
                }`}
              >
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>
                  {isCompleted
                    ? 'تم الحضور والمشاهدة الكاملة'
                    : isFullyAttended
                      ? 'تأكيد إتمام المحاضرة'
                      : `شاهد 90% (${Math.round(effectiveWatchPct)}%)`}
                </span>
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
