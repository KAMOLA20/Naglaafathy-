# دليل توليد ملفات Android APK المنفصلة لمنصة KAMOLA

نظراً لأن منصة التطوير تعمل على خادم سحابي ببيئة Node.js ولا تحتوي على أدوات Android SDK / Gradle لتجميع ملفات `.apk` الثنائية مباشرة، تم تجهيز التطبيقين (`/passenger` و`/captain`) بحيث يمكنك تحويل كل منهما إلى **ملف APK منفصل** باستخدام **Capacitor** أو تثبيتهما فوراً كتطبيقات موبايل مستقلة (PWA).

## 1. بناء APK تطبيق العميل (`com.kamola.passenger`)
1. حمّل ملف الإعداد من `/api/apk-config/passenger` واحفظه باسم `capacitor.config.json` في جذر المشروع.
2. نفّذ الأوامر التالية على جهازك (مع تثبيت Node.js وAndroid Studio):
```bash
npm install @capacitor/core @capacitor/cli @capacitor/android
npx cap add android
npx cap sync android
cd android && ./gradlew assembleRelease
```
ستجد ملف الـ APK في:
`android/app/build/outputs/apk/release/app-release.apk`

## 2. بناء APK تطبيق الكابتن (`com.kamola.captain`)
1. في مجلد منفصل أو بعد نقل مجلد `android` الخاص بالعميل، حمّل ملف الإعداد من `/api/apk-config/captain` واحفظه باسم `capacitor.config.json`.
2. نفّذ نفس الأوامر لتوليد تطبيق الكابتن المستقل:
```bash
rm -rf android
npx cap add android
npx cap sync android
cd android && ./gradlew assembleRelease
```

سيتم ربط كلا التطبيقين تلقائياً بنفس خادم KAMOLA اللحظي في القاهرة (`WebSockets + REST API`).
