import React, { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from 'react';
import type {
  AcademyProfile,
  AcademySnapshot,
  AppSection,
  Certificate,
  ChatMessage,
  Course,
  Exam,
  ExamAttempt,
  FawryOrder,
  GradeLevel,
  LecturePushEvent,
  LessonAttendance,
  LessonReview,
  LiveLectureSchedule,
  Student,
  SubjectBranch,
  TeacherPayoutSettings,
  TopupMethod,
} from '../types.ts';

export type ThemeMode = 'light' | 'dark';

export interface PushPreferences {
  enabled: boolean;
  leadMinutes: number;
  soundEnabled: boolean;
  browserNotifications: boolean;
}

export interface ActiveLectureAlert {
  schedule: LiveLectureSchedule;
  secondsUntilStart: number;
  isLiveNow: boolean;
  customTitle?: string;
  customBody?: string;
}
import {
  downloadGradeCurriculum,
  downloadSingleCourseCurriculum,
} from '../utils/curriculumDownload.ts';
import { downloadCertificateAsPdf } from '../utils/certificatePdf.ts';

interface AcademyContextValue {
  snapshot: AcademySnapshot | null;
  loading: boolean;
  currentStudent: Student | null;
  activeSection: AppSection;
  setActiveSection: (sec: AppSection) => void;
  selectedCourseId: string | null;
  openCourse: (courseId: string) => void;
  toast: { type: 'success' | 'error'; text: string } | null;
  clearToast: () => void;
  showToast: (type: 'success' | 'error', text: string) => void;
  refreshState: () => Promise<void>;
  loginStudent: (phone: string, password: string) => Promise<boolean>;
  registerStudent: (payload: {
    name: string;
    phone: string;
    parentPhone: string;
    governorate: string;
    grade: GradeLevel;
    password: string;
  }) => Promise<boolean>;
  logoutStudent: () => Promise<void>;
  enrollWithWallet: (courseId: string) => Promise<boolean>;
  redeemCode: (code: string, targetCourseId?: string) => Promise<boolean>;
  requestTopup: (payload: {
    amountEgp: number;
    method: TopupMethod;
    referenceNumber: string;
  }) => Promise<boolean>;
  createFawryCharge: (payload: {
    purpose: 'course' | 'wallet';
    courseId?: string;
    amountEgp?: number;
  }) => Promise<FawryOrder | null>;
  confirmSandboxFawryOrder: (orderId: string) => Promise<boolean>;
  downloadAuthorizedCurriculum: (params: {
    courseId?: string;
    grade?: GradeLevel | 'all';
    format?: 'html' | 'doc';
  }) => Promise<boolean>;
  downloadCertificatePdf: (certificateId: string) => Promise<boolean>;
  recordAttendance: (payload: {
    lessonId: string;
    watchedPercent: number;
    watchedSeconds: number;
    lastPositionSec?: number;
    lastSceneIndex?: number;
    checkedIn?: boolean;
    silent?: boolean;
  }) => Promise<LessonAttendance | null>;
  completeLesson: (lessonId: string, durationMin: number) => Promise<void>;
  submitLessonReview: (payload: {
    lessonId: string;
    audioRating: number;
    contentRating: number;
    comment: string;
  }) => Promise<LessonReview | null>;
  submitExam: (examId: string, answers: number[]) => Promise<ExamAttempt | null>;
  generateCodes: (courseId: string, count: number) => Promise<boolean>;
  resolveWalletRequest: (id: string, decision: 'approved' | 'rejected') => Promise<boolean>;
  createCourse: (payload: {
    title: string;
    subtitle: string;
    grade: GradeLevel;
    branch: SubjectBranch;
    monthLabel: string;
    priceEgp: number;
    totalHours: number;
    firstLessonTitle: string;
  }) => Promise<boolean>;
  addLesson: (
    courseId: string,
    payload: {
      title: string;
      durationMin: number;
      videoSummary: string;
      formula: string;
      isFreePreview: boolean;
    }
  ) => Promise<boolean>;
  publishAnnouncement: (payload: {
    title: string;
    body: string;
    grade: GradeLevel | 'all';
  }) => Promise<boolean>;
  updateProfile: (payload: Partial<AcademyProfile>) => Promise<boolean>;
  resetAcademy: () => Promise<void>;
  chatMessages: ChatMessage[];
  activeChatThreadId: string;
  isChatOpen: boolean;
  setIsChatOpen: (open: boolean) => void;
  unreadChatCount: number;
  chatConnected: boolean;
  sendChatMessage: (payload: {
    threadId?: string;
    senderRole: 'student' | 'teacher';
    senderName?: string;
    senderPhone?: string;
    text: string;
  }) => Promise<boolean>;
  lectureSchedules: LiveLectureSchedule[];
  activePushAlerts: ActiveLectureAlert[];
  upcomingAlertsCount: number;
  nowMs: number;
  pushPrefs: PushPreferences;
  updatePushPrefs: (partial: Partial<PushPreferences>) => Promise<void>;
  isAlertsOpen: boolean;
  setIsAlertsOpen: (open: boolean) => void;
  dismissPushAlert: (scheduleId: string) => void;
  snoozePushAlert: (scheduleId: string, minutes?: number) => void;
  testPushAlert: () => void;
  createLectureSchedule: (payload: {
    courseId: string;
    lessonId?: string;
    lessonTitle?: string;
    startsInMinutes?: number;
    scheduledAt?: string;
    durationMin?: number;
    remindBeforeMin?: number;
    note?: string;
    pushNow?: boolean;
  }) => Promise<boolean>;
  pushLectureReminderNow: (scheduleId: string) => Promise<boolean>;
  deleteLectureSchedule: (scheduleId: string) => Promise<boolean>;
  updatePayoutSettings: (payload: Partial<TeacherPayoutSettings>) => Promise<boolean>;
  transferTeacherWalletNow: (amountEgp?: number) => Promise<boolean>;
  theme: ThemeMode;
  toggleTheme: () => void;
}

const TOKEN_STORAGE_KEY = 'qema_student_token_v1';
const GUEST_CHAT_ID_KEY = 'qema_guest_chat_id_v1';
const PUSH_PREFS_KEY = 'qema_push_prefs_v1';
const ALERT_STATE_KEY = 'qema_alert_dismissed_v1';
const THEME_STORAGE_KEY = 'qema_theme_v1';

const DEFAULT_PUSH_PREFS: PushPreferences = {
  enabled: true,
  leadMinutes: 15,
  soundEnabled: true,
  browserNotifications: false,
};

function loadPushPrefs(): PushPreferences {
  if (typeof window === 'undefined') return DEFAULT_PUSH_PREFS;
  try {
    const raw = localStorage.getItem(PUSH_PREFS_KEY);
    if (!raw) return DEFAULT_PUSH_PREFS;
    return { ...DEFAULT_PUSH_PREFS, ...(JSON.parse(raw) as Partial<PushPreferences>) };
  } catch {
    return DEFAULT_PUSH_PREFS;
  }
}

function playNotificationChime() {
  if (typeof window === 'undefined') return;
  try {
    const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
    if (!AudioCtx) return;
    const ctx = new AudioCtx();
    const now = ctx.currentTime;
    const notes = [587.33, 880]; // D5 -> A5 pleasant reminder chime
    notes.forEach((freq, i) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, now + i * 0.14);
      gain.gain.setValueAtTime(0.001, now + i * 0.14);
      gain.gain.exponentialRampToValueAtTime(0.08, now + i * 0.14 + 0.03);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + i * 0.14 + 0.28);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(now + i * 0.14);
      osc.stop(now + i * 0.14 + 0.3);
    });
    window.setTimeout(() => {
      void ctx.close().catch(() => {});
    }, 900);
  } catch {
    // ignore WebAudio restrictions prior to user gesture
  }
}

function getOrCreateGuestThreadId(): string {
  if (typeof window === 'undefined') return 'guest:visitor';
  const existing = localStorage.getItem(GUEST_CHAT_ID_KEY);
  if (existing) return existing;
  const created = `guest:${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 7)}`;
  localStorage.setItem(GUEST_CHAT_ID_KEY, created);
  return created;
}

const AcademyContext = createContext<AcademyContextValue | null>(null);

export function AcademyProvider({ children }: { children: React.ReactNode }) {
  const [snapshot, setSnapshot] = useState<AcademySnapshot | null>(null);
  const [loading, setLoading] = useState(true);
  const [currentStudent, setCurrentStudent] = useState<Student | null>(null);
  const [activeSection, setActiveSection] = useState<AppSection>('catalog');
  const [selectedCourseId, setSelectedCourseId] = useState<string | null>(null);
  const [toast, setToast] = useState<{ type: 'success' | 'error'; text: string } | null>(null);
  const [theme, setTheme] = useState<ThemeMode>(() => {
    if (typeof window === 'undefined') return 'light';
    return localStorage.getItem(THEME_STORAGE_KEY) === 'dark' ? 'dark' : 'light';
  });

  useEffect(() => {
    if (typeof document === 'undefined') return;
    document.documentElement.classList.toggle('dark', theme === 'dark');
    try {
      localStorage.setItem(THEME_STORAGE_KEY, theme);
    } catch {
      // ignore storage errors
    }
  }, [theme]);

  const toggleTheme = useCallback(() => {
    setTheme((prev) => (prev === 'dark' ? 'light' : 'dark'));
  }, []);
  const [guestThreadId] = useState<string>(() => getOrCreateGuestThreadId());
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([]);
  const [isChatOpen, setIsChatOpenState] = useState(false);
  const [unreadChatCount, setUnreadChatCount] = useState(0);
  const [chatConnected, setChatConnected] = useState(false);

  // Upcoming Lecture Push Notifications State
  const [pushPrefs, setPushPrefs] = useState<PushPreferences>(() => loadPushPrefs());
  const [isAlertsOpen, setIsAlertsOpen] = useState(false);
  const [nowMs, setNowMs] = useState<number>(() => Date.now());
  const [dismissedIds, setDismissedIds] = useState<string[]>(() => {
    if (typeof window === 'undefined') return [];
    try {
      const parsed = JSON.parse(localStorage.getItem(ALERT_STATE_KEY) || '{}') as {
        dismissed?: string[];
      };
      return Array.isArray(parsed.dismissed) ? parsed.dismissed : [];
    } catch {
      return [];
    }
  });
  const [snoozedUntil, setSnoozedUntil] = useState<Record<string, number>>(() => {
    if (typeof window === 'undefined') return {};
    try {
      const parsed = JSON.parse(localStorage.getItem(ALERT_STATE_KEY) || '{}') as {
        snoozed?: Record<string, number>;
      };
      return parsed.snoozed && typeof parsed.snoozed === 'object' ? parsed.snoozed : {};
    } catch {
      return {};
    }
  });
  const [pushedOverrides, setPushedOverrides] = useState<Record<string, LecturePushEvent>>({});
  const notifiedScheduleIdsRef = useRef<Set<string>>(new Set());
  const pushPrefsRef = useRef<PushPreferences>(pushPrefs);
  pushPrefsRef.current = pushPrefs;

  const wsRef = useRef<WebSocket | null>(null);
  const isChatOpenRef = useRef(false);
  const activeSectionRef = useRef<AppSection>(activeSection);
  activeSectionRef.current = activeSection;
  const activeChatThreadId = useMemo(
    () => (currentStudent ? `student:${currentStudent.id}` : guestThreadId),
    [currentStudent, guestThreadId]
  );
  const activeThreadRef = useRef(activeChatThreadId);
  activeThreadRef.current = activeChatThreadId;

  const setIsChatOpen = useCallback((open: boolean) => {
    setIsChatOpenState(open);
    isChatOpenRef.current = open;
    if (open) {
      setUnreadChatCount(0);
    }
  }, []);

  useEffect(() => {
    const timer = window.setInterval(() => {
      setNowMs(Date.now());
    }, 1000);
    return () => window.clearInterval(timer);
  }, []);

  const persistAlertState = useCallback((nextDismissed: string[], nextSnoozed: Record<string, number>) => {
    if (typeof window === 'undefined') return;
    localStorage.setItem(
      ALERT_STATE_KEY,
      JSON.stringify({ dismissed: nextDismissed.slice(-100), snoozed: nextSnoozed })
    );
  }, []);

  const updatePushPrefs = useCallback(async (partial: Partial<PushPreferences>) => {
    const merged: PushPreferences = { ...pushPrefsRef.current, ...partial };
    if (partial.browserNotifications && typeof window !== 'undefined' && 'Notification' in window) {
      if (Notification.permission === 'default') {
        try {
          const perm = await Notification.requestPermission();
          if (perm !== 'granted') {
            merged.browserNotifications = false;
          }
        } catch {
          merged.browserNotifications = false;
        }
      } else if (Notification.permission === 'denied') {
        merged.browserNotifications = false;
      }
    }
    setPushPrefs(merged);
    if (typeof window !== 'undefined') {
      localStorage.setItem(PUSH_PREFS_KEY, JSON.stringify(merged));
    }
  }, []);

  const fireSideEffectPush = useCallback((title: string, body: string) => {
    const prefs = pushPrefsRef.current;
    if (!prefs.enabled) return;
    if (prefs.soundEnabled) {
      playNotificationChime();
    }
    if (
      prefs.browserNotifications &&
      typeof window !== 'undefined' &&
      'Notification' in window &&
      Notification.permission === 'granted'
    ) {
      try {
        new Notification(title, { body, dir: 'rtl', lang: 'ar' });
      } catch {
        // ignore notification errors in constrained frames
      }
    }
  }, []);

  const dismissPushAlert = useCallback(
    (scheduleId: string) => {
      setDismissedIds((prev) => {
        const next = prev.includes(scheduleId) ? prev : [...prev, scheduleId];
        persistAlertState(next, snoozedUntil);
        return next;
      });
    },
    [persistAlertState, snoozedUntil]
  );

  const snoozePushAlert = useCallback(
    (scheduleId: string, minutes = 5) => {
      const wakeAt = Date.now() + minutes * 60_000;
      setSnoozedUntil((prev) => {
        const next = { ...prev, [scheduleId]: wakeAt };
        persistAlertState(dismissedIds, next);
        return next;
      });
      notifiedScheduleIdsRef.current.delete(scheduleId);
    },
    [dismissedIds, persistAlertState]
  );

  const mergeMessages = useCallback((incoming: ChatMessage[]) => {
    setChatMessages((prev) => {
      const map = new Map<string, ChatMessage>();
      for (const m of prev) map.set(m.id, m);
      for (const m of incoming) map.set(m.id, m);
      return Array.from(map.values()).sort((a, b) => a.createdAt.localeCompare(b.createdAt));
    });
  }, []);

  const showToast = useCallback((type: 'success' | 'error', text: string) => {
    setToast({ type, text });
  }, []);

  const clearToast = useCallback(() => setToast(null), []);

  useEffect(() => {
    if (!toast) return;
    const timer = setTimeout(() => setToast(null), 5000);
    return () => clearTimeout(timer);
  }, [toast]);

  const refreshState = useCallback(async () => {
    try {
      const res = await fetch('/api/state');
      if (res.ok) {
        const data = (await res.json()) as AcademySnapshot;
        setSnapshot(data);
        if (Array.isArray(data.chatMessages)) {
          mergeMessages(data.chatMessages);
        }
        setCurrentStudent((prev) => {
          if (!prev) return null;
          return data.students.find((s) => s.id === prev.id) || null;
        });
      }
    } finally {
      setLoading(false);
    }
  }, [mergeMessages]);

  useEffect(() => {
    let active = true;
    const init = async () => {
      await refreshState();
      const token = localStorage.getItem(TOKEN_STORAGE_KEY);
      if (token && active) {
        try {
          const res = await fetch('/api/auth/me', {
            headers: { Authorization: `Bearer ${token}` },
          });
          if (res.ok) {
            const data = (await res.json()) as { student: Student };
            if (active) setCurrentStudent(data.student);
          } else {
            localStorage.removeItem(TOKEN_STORAGE_KEY);
          }
        } catch {
          // ignore
        }
      }
    };
    void init();
    return () => {
      active = false;
    };
  }, [refreshState]);

  // Persistent real-time WebSocket connection for in-site student <-> teacher chat
  useEffect(() => {
    if (typeof window === 'undefined') return;
    let disposed = false;
    let reconnectTimer: number | null = null;
    let attempt = 0;

    const connect = () => {
      if (disposed) return;
      const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
      const ws = new WebSocket(`${protocol}//${window.location.host}/ws/chat`);
      wsRef.current = ws;

      ws.onopen = () => {
        if (disposed) {
          ws.close();
          return;
        }
        attempt = 0;
        setChatConnected(true);
        ws.send(
          JSON.stringify({
            type: 'chat:subscribe',
            role: activeSectionRef.current === 'admin' ? 'teacher' : 'student',
            threadId: activeThreadRef.current,
          })
        );
      };

      ws.onmessage = (event) => {
        try {
          const data = JSON.parse(String(event.data)) as {
            type?: string;
            messages?: ChatMessage[];
            message?: ChatMessage;
            event?: LecturePushEvent;
            lectureSchedules?: LiveLectureSchedule[];
            error?: string;
          };
          if (data.type === 'chat:init' && Array.isArray(data.messages)) {
            mergeMessages(data.messages);
          } else if (data.type === 'chat:message' && data.message) {
            mergeMessages([data.message]);
            if (
              data.message.senderRole === 'teacher' &&
              data.message.threadId === activeThreadRef.current &&
              !isChatOpenRef.current
            ) {
              setUnreadChatCount((c) => c + 1);
            }
          } else if (data.type === 'push:lecture' && data.event) {
            const pushEv = data.event;
            if (Array.isArray(data.lectureSchedules)) {
              setSnapshot((prev) =>
                prev ? { ...prev, lectureSchedules: data.lectureSchedules! } : prev
              );
            }
            // Re-surface alert even if previously dismissed when teacher explicitly pushes an urgent reminder
            setDismissedIds((prev) => prev.filter((id) => id !== pushEv.scheduleId));
            setSnoozedUntil((prev) => {
              const copy = { ...prev };
              delete copy[pushEv.scheduleId];
              return copy;
            });
            setPushedOverrides((prev) => ({ ...prev, [pushEv.scheduleId]: pushEv }));
            notifiedScheduleIdsRef.current.add(pushEv.scheduleId);
            fireSideEffectPush(pushEv.title, pushEv.body);
          } else if (data.type === 'chat:error' && data.error) {
            showToast('error', data.error);
          }
        } catch {
          // ignore malformed WS frames
        }
      };

      ws.onclose = () => {
        if (wsRef.current === ws) {
          wsRef.current = null;
        }
        setChatConnected(false);
        if (!disposed) {
          attempt += 1;
          const delay = Math.min(5000, 1200 * attempt);
          reconnectTimer = window.setTimeout(connect, delay);
        }
      };
    };

    connect();

    return () => {
      disposed = true;
      if (reconnectTimer !== null) window.clearTimeout(reconnectTimer);
      if (wsRef.current) {
        wsRef.current.close();
        wsRef.current = null;
      }
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [mergeMessages, showToast]);

  // Re-subscribe whenever student session or admin/student role view changes
  useEffect(() => {
    const ws = wsRef.current;
    if (ws && ws.readyState === WebSocket.OPEN) {
      ws.send(
        JSON.stringify({
          type: 'chat:subscribe',
          role: activeSection === 'admin' ? 'teacher' : 'student',
          threadId: activeChatThreadId,
        })
      );
    }
  }, [activeSection, activeChatThreadId]);

  const openCourse = useCallback((courseId: string) => {
    setSelectedCourseId(courseId);
    setActiveSection('classroom');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, []);

  const loginStudent = useCallback(
    async (phone: string, password: string) => {
      try {
        const res = await fetch('/api/auth/login', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ phone, password }),
        });
        const data = (await res.json()) as { token?: string; student?: Student; error?: string };
        if (!res.ok || !data.student || !data.token) {
          showToast('error', data.error || 'تعذر تسجيل الدخول');
          return false;
        }
        localStorage.setItem(TOKEN_STORAGE_KEY, data.token);
        setCurrentStudent(data.student);
        showToast('success', `مرحباً بك مجدداً يا ${data.student.name}`);
        await refreshState();
        return true;
      } catch {
        showToast('error', 'حدث خطأ في الاتصال بالخادم');
        return false;
      }
    },
    [refreshState, showToast]
  );

  const registerStudent = useCallback(
    async (payload: {
      name: string;
      phone: string;
      parentPhone: string;
      governorate: string;
      grade: GradeLevel;
      password: string;
    }) => {
      try {
        const res = await fetch('/api/auth/register', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload),
        });
        const data = (await res.json()) as {
          token?: string;
          student?: Student;
          snapshot?: AcademySnapshot;
          error?: string;
        };
        if (!res.ok || !data.student || !data.token) {
          showToast('error', data.error || 'تعذر إنشاء الحساب');
          return false;
        }
        localStorage.setItem(TOKEN_STORAGE_KEY, data.token);
        setCurrentStudent(data.student);
        if (data.snapshot) setSnapshot(data.snapshot);
        showToast('success', 'تم إنشاء حساب الطالب بنجاح وتفعيل الكورس المجاني');
        return true;
      } catch {
        showToast('error', 'حدث خطأ في الاتصال بالخادم');
        return false;
      }
    },
    [showToast]
  );

  const logoutStudent = useCallback(async () => {
    const token = localStorage.getItem(TOKEN_STORAGE_KEY);
    if (token) {
      await fetch('/api/auth/logout', {
        method: 'POST',
        headers: { Authorization: `Bearer ${token}` },
      }).catch(() => {});
      localStorage.removeItem(TOKEN_STORAGE_KEY);
    }
    setCurrentStudent(null);
    showToast('success', 'تم تسجيل الخروج من حساب الطالب');
  }, [showToast]);

  const enrollWithWallet = useCallback(
    async (courseId: string) => {
      if (!currentStudent) {
        showToast('error', 'يرجى تسجيل الدخول بحساب الطالب أولاً للاشتراك');
        setActiveSection('student');
        return false;
      }
      const res = await fetch(`/api/courses/${courseId}/enroll-wallet`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ studentId: currentStudent.id }),
      });
      const data = (await res.json()) as {
        student?: Student;
        snapshot?: AcademySnapshot;
        message?: string;
        error?: string;
      };
      if (!res.ok) {
        showToast('error', data.error || 'تعذر إتمام الاشتراك');
        return false;
      }
      if (data.student) setCurrentStudent(data.student);
      if (data.snapshot) setSnapshot(data.snapshot);
      showToast('success', data.message || 'تم تفعيل الكورس بنجاح');
      return true;
    },
    [currentStudent, showToast]
  );

  const redeemCode = useCallback(
    async (code: string, targetCourseId?: string) => {
      if (!currentStudent) {
        showToast('error', 'يرجى تسجيل الدخول بحساب الطالب أولاً لتفعيل الكود');
        setActiveSection('student');
        return false;
      }
      const res = await fetch('/api/codes/redeem', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ studentId: currentStudent.id, code, targetCourseId }),
      });
      const data = (await res.json()) as {
        student?: Student;
        snapshot?: AcademySnapshot;
        message?: string;
        error?: string;
      };
      if (!res.ok) {
        showToast('error', data.error || 'تعذر تفعيل الكود');
        return false;
      }
      if (data.student) setCurrentStudent(data.student);
      if (data.snapshot) setSnapshot(data.snapshot);
      showToast('success', data.message || 'تم تفعيل الكود بنجاح');
      return true;
    },
    [currentStudent, showToast]
  );

  const requestTopup = useCallback(
    async (payload: { amountEgp: number; method: TopupMethod; referenceNumber: string }) => {
      if (!currentStudent) {
        showToast('error', 'يرجى تسجيل الدخول أولاً');
        return false;
      }
      const res = await fetch('/api/wallet/topup-request', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ studentId: currentStudent.id, ...payload }),
      });
      const data = (await res.json()) as { snapshot?: AcademySnapshot; error?: string };
      if (!res.ok) {
        showToast('error', data.error || 'تعذر إرسال طلب الشحن');
        return false;
      }
      if (data.snapshot) setSnapshot(data.snapshot);
      showToast('success', 'تم إرسال طلب الشحن بنجاح، ويمكنك اعتماده فوراً من لوحة المعلم');
      return true;
    },
    [currentStudent, showToast]
  );

  const createFawryCharge = useCallback(
    async (payload: { purpose: 'course' | 'wallet'; courseId?: string; amountEgp?: number }) => {
      if (!currentStudent) {
        showToast('error', 'يرجى تسجيل الدخول بحساب الطالب أولاً لإصدار كود دفع فوري باي');
        setActiveSection('student');
        return null;
      }
      const token = localStorage.getItem(TOKEN_STORAGE_KEY);
      const res = await fetch('/api/payments/fawry/charge', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(token ? { Authorization: `Bearer ${token}` } : {}),
        },
        body: JSON.stringify({ studentId: currentStudent.id, ...payload }),
      });
      const data = (await res.json()) as {
        order?: FawryOrder;
        snapshot?: AcademySnapshot;
        error?: string;
      };
      if (!res.ok || !data.order) {
        showToast('error', data.error || 'تعذر إصدار كود الدفع عبر فوري باي');
        return null;
      }
      if (data.snapshot) setSnapshot(data.snapshot);
      showToast('success', `تم إصدار الرقم المرجعي لفوري: ${data.order.referenceNumber}`);
      return data.order;
    },
    [currentStudent, showToast]
  );

  const confirmSandboxFawryOrder = useCallback(
    async (orderId: string) => {
      if (!currentStudent) {
        showToast('error', 'يرجى تسجيل الدخول أولاً');
        return false;
      }
      const token = localStorage.getItem(TOKEN_STORAGE_KEY);
      const res = await fetch('/api/payments/fawry/sandbox-confirm', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(token ? { Authorization: `Bearer ${token}` } : {}),
        },
        body: JSON.stringify({ orderId, studentId: currentStudent.id }),
      });
      const data = (await res.json()) as {
        student?: Student | null;
        snapshot?: AcademySnapshot;
        message?: string;
        error?: string;
      };
      if (!res.ok) {
        showToast('error', data.error || 'تعذر تأكيد سداد فاتورة فوري');
        return false;
      }
      if (data.student) setCurrentStudent(data.student);
      if (data.snapshot) setSnapshot(data.snapshot);
      showToast('success', data.message || 'تم تأكيد الدفع عبر فوري بنجاح');
      return true;
    },
    [currentStudent, showToast]
  );

  const downloadAuthorizedCurriculum = useCallback(
    async ({
      courseId,
      grade = 'all',
      format = 'html',
    }: {
      courseId?: string;
      grade?: GradeLevel | 'all';
      format?: 'html' | 'doc';
    }) => {
      const token = localStorage.getItem(TOKEN_STORAGE_KEY);
      const res = await fetch('/api/curriculum/authorized', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(token ? { Authorization: `Bearer ${token}` } : {}),
        },
        body: JSON.stringify({
          studentId: currentStudent?.id,
          courseId,
          grade,
        }),
      });
      const data = (await res.json()) as {
        courses?: Course[];
        exams?: Exam[];
        error?: string;
      };
      if (!res.ok || !data.courses || data.courses.length === 0) {
        showToast(
          'error',
          data.error || 'تنزيل المنهج مغلق — يرجى سداد قيمة الكورس الشهري أولاً'
        );
        return false;
      }

      if (courseId && data.courses[0]) {
        downloadSingleCourseCurriculum(
          data.courses[0],
          data.exams?.[0],
          snapshot?.profile,
          format
        );
        showToast('success', `تم تنزيل منهج ${data.courses[0].monthLabel}`);
      } else {
        downloadGradeCurriculum(
          grade,
          data.courses,
          data.exams || [],
          snapshot?.profile,
          format
        );
        showToast(
          'success',
          `تم تنزيل المنهج للمواد المفعلة (${data.courses.length} مواد)`
        );
      }
      return true;
    },
    [currentStudent, snapshot?.profile, showToast]
  );

  const recordAttendance = useCallback(
    async (payload: {
      lessonId: string;
      watchedPercent: number;
      watchedSeconds: number;
      lastPositionSec?: number;
      lastSceneIndex?: number;
      checkedIn?: boolean;
      silent?: boolean;
    }) => {
      if (!currentStudent) return null;
      const token = localStorage.getItem(TOKEN_STORAGE_KEY);
      const res = await fetch('/api/attendance/record', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(token ? { Authorization: `Bearer ${token}` } : {}),
        },
        body: JSON.stringify({
          studentId: currentStudent.id,
          lessonId: payload.lessonId,
          watchedPercent: payload.watchedPercent,
          watchedSeconds: payload.watchedSeconds,
          lastPositionSec: payload.lastPositionSec,
          lastSceneIndex: payload.lastSceneIndex,
          checkedIn: payload.checkedIn,
        }),
      });
      const data = (await res.json().catch(() => ({}))) as {
        attendance?: LessonAttendance;
        student?: Student;
        snapshot?: AcademySnapshot;
        newlyIssuedCertificate?: Certificate | null;
        error?: string;
      };
      if (!res.ok || !data.attendance) {
        if (!payload.silent) {
          showToast('error', data.error || 'تعذر تسجيل حضور المحاضرة');
        }
        return null;
      }
      if (data.student) setCurrentStudent(data.student);
      if (data.snapshot) setSnapshot(data.snapshot);
      if (data.newlyIssuedCertificate) {
        showToast(
          'success',
          `مبارك! تم التحقق من حضور ومشاهدة الـ ${data.newlyIssuedCertificate.totalLessonsCount} محاضرات كاملة وإصدار شهادة «${data.newlyIssuedCertificate.courseTitle}»!`
        );
      } else if (!payload.silent) {
        showToast('success', 'تم تسجيل حضور المحاضرة بنجاح');
      }
      return data.attendance;
    },
    [currentStudent, showToast]
  );

  const downloadCertificatePdf = useCallback(
    async (certificateId: string) => {
      if (!currentStudent) {
        showToast('error', 'يرجى تسجيل الدخول بحساب الطالب أولاً لتحميل الشهادة');
        return false;
      }
      const token = localStorage.getItem(TOKEN_STORAGE_KEY);
      const res = await fetch(`/api/certificates/${certificateId}/authorize`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(token ? { Authorization: `Bearer ${token}` } : {}),
        },
        body: JSON.stringify({ studentId: currentStudent.id }),
      });
      const data = (await res.json()) as { certificate?: Certificate; error?: string };
      if (!res.ok || !data.certificate) {
        showToast('error', data.error || 'تعذر التحقق من صلاحية تحميل الشهادة');
        return false;
      }
      await downloadCertificateAsPdf(data.certificate);
      showToast('success', `تم تحميل شهادة «${data.certificate.courseTitle}» بصيغة PDF`);
      return true;
    },
    [currentStudent, showToast]
  );

  const completeLesson = useCallback(
    async (lessonId: string, durationMin: number) => {
      if (!currentStudent) return;
      const token = localStorage.getItem(TOKEN_STORAGE_KEY);
      const res = await fetch(`/api/lessons/${lessonId}/complete`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(token ? { Authorization: `Bearer ${token}` } : {}),
        },
        body: JSON.stringify({ studentId: currentStudent.id, durationMin }),
      });
      if (res.ok) {
        const data = (await res.json()) as {
          student?: Student;
          snapshot?: AcademySnapshot;
          newlyIssuedCertificate?: Certificate | null;
        };
        if (data.student) setCurrentStudent(data.student);
        if (data.snapshot) setSnapshot(data.snapshot);
        if (data.newlyIssuedCertificate) {
          showToast(
            'success',
            `مبارك! أتممت الـ ${data.newlyIssuedCertificate.totalLessonsCount} محاضرات وتم إصدار شهادة إتمام «${data.newlyIssuedCertificate.courseTitle}» في صفحة حسابك!`
          );
        } else {
          showToast('success', 'تم تسجيل إتمام المحاضرة وإضافة 40 نقطة إلى رصيدك');
        }
      } else {
        const err = (await res.json().catch(() => ({}))) as { error?: string };
        showToast('error', err.error || 'يرجى الاشتراك أولاً لتسجيل إتمام المحاضرة');
      }
    },
    [currentStudent, showToast]
  );

  const submitExam = useCallback(
    async (examId: string, answers: number[]) => {
      const token = localStorage.getItem(TOKEN_STORAGE_KEY);
      const res = await fetch(`/api/exams/${examId}/submit`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(token ? { Authorization: `Bearer ${token}` } : {}),
        },
        body: JSON.stringify({ studentId: currentStudent?.id, answers }),
      });
      const data = (await res.json()) as {
        attempt?: ExamAttempt;
        student?: Student | null;
        snapshot?: AcademySnapshot;
        error?: string;
      };
      if (!res.ok || !data.attempt) {
        showToast('error', data.error || 'تعذر تصحيح الامتحان');
        return null;
      }
      if (data.student) setCurrentStudent(data.student);
      if (data.snapshot) setSnapshot(data.snapshot);
      return data.attempt;
    },
    [currentStudent, showToast]
  );

  const generateCodes = useCallback(
    async (courseId: string, count: number) => {
      const res = await fetch('/api/admin/codes', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ courseId, count }),
      });
      const data = (await res.json()) as { snapshot?: AcademySnapshot; error?: string };
      if (!res.ok) {
        showToast('error', data.error || 'تعذر توليد الأكواد');
        return false;
      }
      if (data.snapshot) setSnapshot(data.snapshot);
      showToast('success', `تم إصدار ${count} كود تفعيل جديد بنجاح`);
      return true;
    },
    [showToast]
  );

  const resolveWalletRequest = useCallback(
    async (id: string, decision: 'approved' | 'rejected') => {
      const res = await fetch(`/api/admin/wallet-requests/${id}/resolve`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ decision }),
      });
      const data = (await res.json()) as { snapshot?: AcademySnapshot; error?: string };
      if (!res.ok) {
        showToast('error', data.error || 'تعذر تحديث الطلب');
        return false;
      }
      if (data.snapshot) {
        setSnapshot(data.snapshot);
        setCurrentStudent((prev) =>
          prev ? data.snapshot!.students.find((s) => s.id === prev.id) || prev : null
        );
      }
      showToast('success', decision === 'approved' ? 'تم اعتماد الشحن وإضافة الرصيد للطالب' : 'تم رفض طلب الشحن');
      return true;
    },
    [showToast]
  );

  const createCourse = useCallback(
    async (payload: {
      title: string;
      subtitle: string;
      grade: GradeLevel;
      branch: SubjectBranch;
      monthLabel: string;
      priceEgp: number;
      totalHours: number;
      firstLessonTitle: string;
    }) => {
      const res = await fetch('/api/admin/courses', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      const data = (await res.json()) as { snapshot?: AcademySnapshot; error?: string };
      if (!res.ok) {
        showToast('error', data.error || 'تعذر إضافة الكورس');
        return false;
      }
      if (data.snapshot) setSnapshot(data.snapshot);
      showToast('success', 'تم إضافة الكورس ونشره في المنصة بنجاح');
      return true;
    },
    [showToast]
  );

  const addLesson = useCallback(
    async (
      courseId: string,
      payload: {
        title: string;
        durationMin: number;
        videoSummary: string;
        formula: string;
        isFreePreview: boolean;
      }
    ) => {
      const res = await fetch(`/api/admin/courses/${courseId}/lessons`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      const data = (await res.json()) as { snapshot?: AcademySnapshot; error?: string };
      if (!res.ok) {
        showToast('error', data.error || 'تعذر إضافة المحاضرة');
        return false;
      }
      if (data.snapshot) setSnapshot(data.snapshot);
      showToast('success', 'تم إضافة المحاضرة إلى منهج الكورس');
      return true;
    },
    [showToast]
  );

  const publishAnnouncement = useCallback(
    async (payload: { title: string; body: string; grade: GradeLevel | 'all' }) => {
      const res = await fetch('/api/admin/announcements', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      const data = (await res.json()) as { snapshot?: AcademySnapshot; error?: string };
      if (!res.ok) {
        showToast('error', data.error || 'تعذر نشر التنبيه');
        return false;
      }
      if (data.snapshot) setSnapshot(data.snapshot);
      showToast('success', 'تم نشر التنبيه للطلاب');
      return true;
    },
    [showToast]
  );

  const updateProfile = useCallback(
    async (payload: Partial<AcademyProfile>) => {
      const res = await fetch('/api/admin/profile', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      const data = (await res.json()) as { snapshot?: AcademySnapshot; error?: string };
      if (!res.ok) {
        showToast('error', data.error || 'تعذر حفظ الإعدادات');
        return false;
      }
      if (data.snapshot) setSnapshot(data.snapshot);
      showToast('success', 'تم تحديث بيانات المنصة والمعلم');
      return true;
    },
    [showToast]
  );

  const resetAcademy = useCallback(async () => {
    const res = await fetch('/api/admin/reset', { method: 'POST' });
    if (res.ok) {
      const data = (await res.json()) as AcademySnapshot;
      setSnapshot(data);
      setChatMessages(Array.isArray(data.chatMessages) ? data.chatMessages : []);
      setCurrentStudent((prev) => (prev ? data.students.find((s) => s.id === prev.id) || null : null));
      showToast('success', 'تم استعادة البيانات الافتراضية للمنصة');
    }
  }, [showToast]);

  const sendChatMessage = useCallback(
    async (payload: {
      threadId?: string;
      senderRole: 'student' | 'teacher';
      senderName?: string;
      senderPhone?: string;
      text: string;
    }) => {
      const cleanText = payload.text.trim();
      if (!cleanText) return false;
      const targetThreadId = payload.threadId || activeChatThreadId;
      const clientMsgId = `msg-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
      const msgPayload = {
        id: clientMsgId,
        threadId: targetThreadId,
        senderRole: payload.senderRole,
        senderName:
          payload.senderName?.trim() ||
          (payload.senderRole === 'teacher'
            ? snapshot?.profile.teacherName || 'الأستاذة نجلاء فتحي'
            : currentStudent?.name || 'طالب / ولي أمر'),
        senderPhone:
          payload.senderPhone?.trim() ||
          (payload.senderRole === 'student' ? currentStudent?.phone : undefined),
        text: cleanText,
      };

      const ws = wsRef.current;
      if (ws && ws.readyState === WebSocket.OPEN) {
        ws.send(JSON.stringify({ type: 'chat:send', ...msgPayload }));
        return true;
      }

      try {
        const res = await fetch('/api/chat/messages', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(msgPayload),
        });
        const data = (await res.json()) as { message?: ChatMessage; error?: string };
        if (!res.ok || !data.message) {
          showToast('error', data.error || 'تعذر إرسال الرسالة');
          return false;
        }
        mergeMessages([data.message]);
        return true;
      } catch {
        showToast('error', 'تعذر الاتصال بخادم المحادثة');
        return false;
      }
    },
    [activeChatThreadId, currentStudent, mergeMessages, showToast, snapshot?.profile.teacherName]
  );

  const lectureSchedules = useMemo(() => {
    const list = snapshot?.lectureSchedules || [];
    return [...list].sort((a, b) => a.scheduledAt.localeCompare(b.scheduledAt));
  }, [snapshot?.lectureSchedules]);

  const activePushAlerts = useMemo<ActiveLectureAlert[]>(() => {
    if (!pushPrefs.enabled) return [];
    const results: ActiveLectureAlert[] = [];
    for (const sch of lectureSchedules) {
      if (dismissedIds.includes(sch.id)) continue;
      const snoozeTime = snoozedUntil[sch.id];
      if (snoozeTime && nowMs < snoozeTime) continue;

      const startMs = new Date(sch.scheduledAt).getTime();
      if (!Number.isFinite(startMs)) continue;
      const endMs = startMs + sch.durationMin * 60_000;
      const leadMs = Math.max(pushPrefs.leadMinutes, sch.remindBeforeMin) * 60_000;
      const isForcedPush = Boolean(pushedOverrides[sch.id]);

      if (isForcedPush || (nowMs >= startMs - leadMs && nowMs <= endMs)) {
        const secondsUntilStart = Math.round((startMs - nowMs) / 1000);
        const override = pushedOverrides[sch.id];
        results.push({
          schedule: sch,
          secondsUntilStart,
          isLiveNow: secondsUntilStart <= 0,
          customTitle: override?.title,
          customBody: override?.body,
        });
      }
    }
    return results;
  }, [lectureSchedules, pushPrefs.enabled, pushPrefs.leadMinutes, dismissedIds, snoozedUntil, nowMs, pushedOverrides]);

  const upcomingAlertsCount = useMemo(() => {
    return lectureSchedules.filter((sch) => {
      const startMs = new Date(sch.scheduledAt).getTime();
      const endMs = startMs + sch.durationMin * 60_000;
      return Number.isFinite(startMs) && nowMs <= endMs;
    }).length;
  }, [lectureSchedules, nowMs]);

  useEffect(() => {
    if (!pushPrefs.enabled || loading) return;
    for (const alert of activePushAlerts) {
      if (!notifiedScheduleIdsRef.current.has(alert.schedule.id)) {
        notifiedScheduleIdsRef.current.add(alert.schedule.id);
        const minsLeft = Math.max(0, Math.ceil(alert.secondsUntilStart / 60));
        const title =
          alert.customTitle ||
          (alert.isLiveNow
            ? `المحاضرة بدأت الآن: ${alert.schedule.lessonTitle}`
            : `اقترب موعد المحاضرة خلال ${minsLeft} دقيقة`);
        const body = alert.customBody || `${alert.schedule.courseTitle} مع ${alert.schedule.teacherName}`;
        fireSideEffectPush(title, body);
      }
    }
  }, [activePushAlerts, fireSideEffectPush, loading, pushPrefs.enabled]);

  const testPushAlert = useCallback(() => {
    const target = lectureSchedules[0] || {
      id: 'sch-preview',
      courseId: snapshot?.courses[0]?.id || 'crs-p4-ar',
      courseTitle: snapshot?.courses[0]?.title || 'اللغة العربية — الصف الرابع الابتدائي',
      lessonTitle: snapshot?.courses[0]?.lessons[0]?.title || 'مراجعة شاملة وتدريبات نحوية',
      grade: snapshot?.courses[0]?.grade || 'p4',
      branch: snapshot?.courses[0]?.branch || 'arabic',
      teacherName: snapshot?.profile.teacherName || 'الأستاذة نجلاء فتحي',
      scheduledAt: new Date(Date.now() + 5 * 60_000).toISOString(),
      durationMin: 40,
      remindBeforeMin: 15,
      note: 'تنبيه تجريبي للتأكد من عمل إشعارات الموعد والصوت داخل المنصة.',
      createdAt: new Date().toISOString(),
    };
    const ev: LecturePushEvent = {
      id: `push-test-${Date.now()}`,
      scheduleId: target.id,
      courseId: target.courseId,
      courseTitle: target.courseTitle,
      lessonTitle: target.lessonTitle,
      grade: target.grade,
      scheduledAt: target.scheduledAt,
      title: `تذكير تجريبي: محاضرة «${target.lessonTitle}»`,
      body: `${target.courseTitle} مع ${target.teacherName}`,
      pushedAt: new Date().toISOString(),
    };
    setDismissedIds((prev) => prev.filter((id) => id !== target.id));
    setSnoozedUntil((prev) => {
      const next = { ...prev };
      delete next[target.id];
      return next;
    });
    setPushedOverrides((prev) => ({ ...prev, [target.id]: ev }));
    fireSideEffectPush(ev.title, ev.body);
  }, [fireSideEffectPush, lectureSchedules, snapshot?.courses, snapshot?.profile.teacherName]);

  const createLectureSchedule = useCallback(
    async (payload: {
      courseId: string;
      lessonId?: string;
      lessonTitle?: string;
      startsInMinutes?: number;
      scheduledAt?: string;
      durationMin?: number;
      remindBeforeMin?: number;
      note?: string;
      pushNow?: boolean;
    }) => {
      const res = await fetch('/api/admin/schedules', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      const data = (await res.json()) as { snapshot?: AcademySnapshot; error?: string };
      if (!res.ok) {
        showToast('error', data.error || 'تعذر جدولة موعد المحاضرة');
        return false;
      }
      if (data.snapshot) setSnapshot(data.snapshot);
      showToast('success', 'تم حفظ موعد المحاضرة وتفعيل نظام التذكير التلقائي');
      return true;
    },
    [showToast]
  );

  const pushLectureReminderNow = useCallback(
    async (scheduleId: string) => {
      const res = await fetch(`/api/admin/schedules/${scheduleId}/push`, {
        method: 'POST',
      });
      const data = (await res.json()) as { snapshot?: AcademySnapshot; error?: string };
      if (!res.ok) {
        showToast('error', data.error || 'تعذر إرسال التنبيه الفوري');
        return false;
      }
      if (data.snapshot) setSnapshot(data.snapshot);
      showToast('success', 'تم بث تنبيه المحاضرة فورياً لجميع الطلاب المتصلين');
      return true;
    },
    [showToast]
  );

  const deleteLectureSchedule = useCallback(
    async (scheduleId: string) => {
      const res = await fetch(`/api/admin/schedules/${scheduleId}`, {
        method: 'DELETE',
      });
      const data = (await res.json()) as { snapshot?: AcademySnapshot; error?: string };
      if (!res.ok) {
        showToast('error', data.error || 'تعذر حذف الموعد');
        return false;
      }
      if (data.snapshot) setSnapshot(data.snapshot);
      showToast('success', 'تم حذف موعد المحاضرة');
      return true;
    },
    [showToast]
  );

  const submitLessonReview = useCallback(
    async (payload: {
      lessonId: string;
      audioRating: number;
      contentRating: number;
      comment: string;
    }) => {
      if (!currentStudent) {
        showToast('error', 'يرجى تسجيل الدخول بحساب الطالب أولاً لتقييم الدرس');
        return null;
      }
      const token = localStorage.getItem(TOKEN_STORAGE_KEY);
      const res = await fetch(`/api/lessons/${payload.lessonId}/reviews`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(token ? { Authorization: `Bearer ${token}` } : {}),
        },
        body: JSON.stringify({
          studentId: currentStudent.id,
          audioRating: payload.audioRating,
          contentRating: payload.contentRating,
          comment: payload.comment,
        }),
      });
      const data = (await res.json().catch(() => ({}))) as {
        updated?: boolean;
        review?: LessonReview;
        student?: Student;
        snapshot?: AcademySnapshot;
        error?: string;
      };
      if (!res.ok || !data.review) {
        showToast('error', data.error || 'تعذر حفظ تقييم الدرس');
        return null;
      }
      if (data.student) setCurrentStudent(data.student);
      if (data.snapshot) setSnapshot(data.snapshot);
      showToast(
        'success',
        data.updated
          ? 'تم تحديث تقييمك للدرس بنجاح'
          : 'شكراً لك! تم حفظ تقييم الدرس وإضافة 15 نقطة إلى رصيدك'
      );
      return data.review;
    },
    [currentStudent, showToast]
  );

  const updatePayoutSettings = useCallback(
    async (payload: Partial<TeacherPayoutSettings>) => {
      const res = await fetch('/api/admin/payout-settings', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      const data = (await res.json()) as {
        payoutSettings?: TeacherPayoutSettings;
        snapshot?: AcademySnapshot;
        error?: string;
      };
      if (!res.ok) {
        showToast('error', data.error || 'تعذر حفظ إعدادات التحويل التلقائي');
        return false;
      }
      if (data.snapshot) setSnapshot(data.snapshot);
      showToast(
        'success',
        data.payoutSettings?.autoTransferEnabled
          ? `تم تفعيل التحويل التلقائي الفوري إلى ${data.payoutSettings.destinationPhone}`
          : 'تم تحديث إعدادات المحفظة والتحويل'
      );
      return true;
    },
    [showToast]
  );

  const transferTeacherWalletNow = useCallback(
    async (amountEgp?: number) => {
      const res = await fetch('/api/admin/payouts/transfer-now', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(typeof amountEgp === 'number' ? { amountEgp } : {}),
      });
      const data = (await res.json()) as {
        snapshot?: AcademySnapshot;
        message?: string;
        error?: string;
      };
      if (!res.ok) {
        showToast('error', data.error || 'تعذر تنفيذ التحويل الآن');
        return false;
      }
      if (data.snapshot) setSnapshot(data.snapshot);
      showToast('success', data.message || 'تم تحويل الرصيد بنجاح');
      return true;
    },
    [showToast]
  );

  return (
    <AcademyContext.Provider
      value={{
        snapshot,
        loading,
        currentStudent,
        activeSection,
        setActiveSection,
        selectedCourseId,
        openCourse,
        toast,
        clearToast,
        showToast,
        refreshState,
        loginStudent,
        registerStudent,
        logoutStudent,
        enrollWithWallet,
        redeemCode,
        requestTopup,
        createFawryCharge,
        confirmSandboxFawryOrder,
        downloadAuthorizedCurriculum,
        downloadCertificatePdf,
        recordAttendance,
        completeLesson,
        submitLessonReview,
        submitExam,
        generateCodes,
        resolveWalletRequest,
        createCourse,
        addLesson,
        publishAnnouncement,
        updateProfile,
        resetAcademy,
        chatMessages,
        activeChatThreadId,
        isChatOpen,
        setIsChatOpen,
        unreadChatCount,
        chatConnected,
        sendChatMessage,
        lectureSchedules,
        activePushAlerts,
        upcomingAlertsCount,
        nowMs,
        pushPrefs,
        updatePushPrefs,
        isAlertsOpen,
        setIsAlertsOpen,
        dismissPushAlert,
        snoozePushAlert,
        testPushAlert,
        createLectureSchedule,
        pushLectureReminderNow,
        deleteLectureSchedule,
        updatePayoutSettings,
        transferTeacherWalletNow,
        theme,
        toggleTheme,
      }}
    >
      {children}
    </AcademyContext.Provider>
  );
}

export function useAcademy() {
  const ctx = useContext(AcademyContext);
  if (!ctx) {
    throw new Error('useAcademy must be used inside AcademyProvider');
  }
  return ctx;
}
