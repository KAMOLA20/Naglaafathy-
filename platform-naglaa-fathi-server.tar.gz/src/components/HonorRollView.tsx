import { useMemo } from 'react';
import { Award, Megaphone } from 'lucide-react';
import { useAcademy } from '../context/AcademyContext.tsx';
import { formatArabicDate, GRADE_SHORT_LABELS } from '../utils/academy.ts';

export function HonorRollView() {
  const { snapshot } = useAcademy();

  const rankedStudents = useMemo(() => {
    const list = [...(snapshot?.students || [])];
    return list.sort((a, b) => b.points - a.points);
  }, [snapshot?.students]);

  const announcements = snapshot?.announcements || [];
  const attempts = snapshot?.examAttempts || [];

  return (
    <div className="space-y-8 pb-10">
      <div className="border-b border-slate-200 dark:border-slate-800 pb-4">
        <p className="text-xs font-semibold text-blue-700 dark:text-blue-400">المتفوقون والنتائج الأسبوعية</p>
        <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-slate-100 font-display mt-1">
          لوحة الشرف وإعلانات المنصة
        </h1>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Leaderboard Table */}
        <section className="lg:col-span-7 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl overflow-hidden">
          <div className="px-6 py-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Award className="w-5 h-5 text-amber-600 dark:text-amber-400" />
              <h2 className="text-base font-bold text-slate-900 dark:text-slate-100 font-display">ترتيب الطلاب الأكثر التزاماً</h2>
            </div>
            <span className="text-xs text-slate-500 dark:text-slate-400 tabular-nums">{rankedStudents.length} طالب</span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-right text-sm">
              <thead className="bg-slate-50 dark:bg-slate-800/80 text-xs text-slate-500 dark:text-slate-400 border-b border-slate-200 dark:border-slate-800">
                <tr>
                  <th className="py-3 px-4 font-semibold">المركز</th>
                  <th className="py-3 px-4 font-semibold">اسم الطالب</th>
                  <th className="py-3 px-4 font-semibold">الصف والمحافظة</th>
                  <th className="py-3 px-4 font-semibold">المحاضرات</th>
                  <th className="py-3 px-4 font-semibold">النقاط</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {rankedStudents.map((stu, idx) => (
                  <tr key={stu.id} className="hover:bg-slate-50/60 dark:hover:bg-slate-800/50">
                    <td className="py-3.5 px-4 font-mono font-bold text-slate-900 dark:text-slate-100 tabular-nums">
                      #{idx + 1}
                    </td>
                    <td className="py-3.5 px-4 font-semibold text-slate-900 dark:text-slate-100">{stu.name}</td>
                    <td className="py-3.5 px-4 text-xs text-slate-600 dark:text-slate-400">
                      {GRADE_SHORT_LABELS[stu.grade]} · {stu.governorate}
                    </td>
                    <td className="py-3.5 px-4 font-mono text-xs text-slate-700 dark:text-slate-300 tabular-nums">
                      {stu.completedLessonIds.length}
                    </td>
                    <td className="py-3.5 px-4 font-mono font-bold text-blue-700 dark:text-blue-400 tabular-nums">
                      {stu.points}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>

        {/* Announcements & Recent Top Exam Scores */}
        <div className="lg:col-span-5 space-y-6">
          <section className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 space-y-4">
            <div className="flex items-center gap-2 border-b border-slate-100 dark:border-slate-800 pb-3">
              <Megaphone className="w-4 h-4 text-blue-700 dark:text-blue-400" />
              <h2 className="text-base font-bold text-slate-900 dark:text-slate-100 font-display">تنبيهات الأستاذ</h2>
            </div>

            <div className="space-y-3">
              {announcements.map((ann) => (
                <article key={ann.id} className="bg-slate-50 dark:bg-slate-800/70 border border-slate-200 dark:border-slate-700 rounded-xl p-4 space-y-1.5">
                  <div className="flex items-center justify-between text-[11px] text-slate-500 dark:text-slate-400">
                    <span className="font-semibold text-blue-700 dark:text-blue-400">
                      {ann.grade === 'all' ? 'لجميع الصفوف' : GRADE_SHORT_LABELS[ann.grade]}
                    </span>
                    <span>{formatArabicDate(ann.createdAt)}</span>
                  </div>
                  <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100">{ann.title}</h3>
                  <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">{ann.body}</p>
                </article>
              ))}
            </div>
          </section>

          <section className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 space-y-3">
            <h2 className="text-sm font-bold text-slate-900 dark:text-slate-100 font-display border-b border-slate-100 dark:border-slate-800 pb-3">
              أحدث درجات الامتحانات الإلكترونية
            </h2>
            <div className="space-y-2.5">
              {attempts.slice(0, 5).map((att) => (
                <div
                  key={att.id}
                  className="flex items-center justify-between text-xs py-2 border-b border-slate-100 dark:border-slate-800 last:border-none"
                >
                  <div>
                    <p className="font-semibold text-slate-900 dark:text-slate-100">{att.studentName}</p>
                    <p className="text-[11px] text-slate-500 dark:text-slate-400">{formatArabicDate(att.submittedAt)}</p>
                  </div>
                  <span className="font-mono font-bold text-emerald-700 dark:text-emerald-400 tabular-nums">
                    {att.score}/{att.total} ({att.percentage}%)
                  </span>
                </div>
              ))}
            </div>
          </section>
        </div>
      </div>
    </div>
  );
}
