import { useEffect, useMemo, useState } from 'react';
import { BookOpen, CheckCircle2, Download, Lock, Play, Sparkles, Volume2, VolumeX } from 'lucide-react';
import { useAcademy } from '../context/AcademyContext.tsx';
import type { SubjectBranch } from '../types.ts';
import { BRANCH_LABELS, formatEgp } from '../utils/academy.ts';
import { speechController } from '../utils/speech.ts';
import { SafeImage } from './SafeImage.tsx';

const KG_FUN_CARDS: Array<{
  subject: string;
  symbol: string;
  word: string;
  hint: string;
  spokenText: string;
  lang: 'ar-EG' | 'en-US';
}> = [
  {
    subject: 'العربي · نور البيان',
    symbol: 'أ',
    word: 'أَرْنَبٌ',
    hint: 'حرف الألف عليه همزة وفتحة: أَ',
    spokenText: 'حرف الألف بالفتحة: أَ، أَرنب',
    lang: 'ar-EG',
  },
  {
    subject: 'الحساب · الأرقام',
    symbol: '5',
    word: 'خَمْسَة (★★★★★)',
    hint: 'نعد خمسة نجوم: 1 · 2 · 3 · 4 · 5',
    spokenText: 'الرقم خمسة. هيا نعد معاً: واحد، اثنان، ثلاثة، أربعة، خمسة.',
    lang: 'ar-EG',
  },
  {
    subject: 'الإنجليزي · Phonics',
    symbol: 'Aa',
    word: 'Apple · تفاحة',
    hint: 'صوت الحرف القصير /æ/ مثل كلمة Apple',
    spokenText: 'Letter A says ah, Apple.',
    lang: 'en-US',
  },
  {
    subject: 'اكتشف والعلوم',
    symbol: '☀',
    word: 'الشمس والنهار',
    hint: 'تمنحنا الشمس الضوء والدفء وتساعد النبات على النمو',
    spokenText: 'الشمس تمنحنا الضوء والدفء وتساعد النبات على النمو.',
    lang: 'ar-EG',
  },
];

export function KindergartenPage() {
  const {
    snapshot,
    currentStudent,
    openCourse,
    setActiveSection,
    downloadAuthorizedCurriculum,
  } = useAcademy();
  const [branchFilter, setBranchFilter] = useState<'all' | SubjectBranch>('all');
  const [activeCardIdx, setActiveCardIdx] = useState(0);
  const [isSpeaking, setIsSpeaking] = useState(false);

  useEffect(() => {
    return () => {
      speechController.stop();
    };
  }, []);

  const kgCourses = useMemo(() => {
    const list = (snapshot?.courses || []).filter((c) => c.grade === 'kg');
    if (branchFilter === 'all') return list;
    return list.filter((c) => c.branch === branchFilter);
  }, [snapshot?.courses, branchFilter]);

  const branchTabs: { id: 'all' | SubjectBranch; label: string }[] = [
    { id: 'all', label: 'جميع المواد (KG1 & KG2)' },
    { id: 'kg_arabic', label: 'تأسيس العربي' },
    { id: 'kg_math', label: 'تأسيس الحساب' },
    { id: 'kg_english', label: 'تأسيس الإنجليزي' },
    { id: 'kg_discover', label: 'اكتشف والعلوم' },
  ];

  const activeCard = KG_FUN_CARDS[activeCardIdx];

  const handleToggleCardVoice = () => {
    if (isSpeaking) {
      speechController.stop();
      setIsSpeaking(false);
      return;
    }
    speechController.speak(activeCard.spokenText, {
      lang: activeCard.lang,
      rate: 0.9,
      onStart: () => setIsSpeaking(true),
      onEnd: () => setIsSpeaking(false),
      onError: () => setIsSpeaking(false),
    });
  };

  const handleDownloadAllKg = (format: 'html' | 'doc') => {
    void downloadAuthorizedCurriculum({ grade: 'kg', format });
  };

  return (
    <div className="space-y-10 pb-10">
      {/* Kindergarten Hero Split */}
      <section className="grid grid-cols-1 lg:grid-cols-12 gap-6 lg:gap-8 items-stretch">
        <div className="lg:col-span-7 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 sm:p-10 flex flex-col justify-between">
          <div className="space-y-4">
            <p className="text-xs sm:text-sm font-semibold text-amber-700 dark:text-amber-400">
              {snapshot?.profile.platformName || 'منصة الأستاذة نجلاء فتحي'} · رياض الأطفال (KG1 &amp; KG2)
            </p>
            <h1 className="text-3xl sm:text-4xl font-extrabold text-slate-900 dark:text-slate-100 leading-tight font-display">
              فيديوهات شرح كرتونية لتأسيس رياض الأطفال (8 محاضرات شهرياً)
            </h1>
            <p className="text-sm sm:text-base text-slate-600 dark:text-slate-400 leading-relaxed max-w-2xl">
              منهج متكامل بفيديوهات شرح كرتونية للأستاذة نجلاء فتحي (8 محاضرات في الشهر لكل مادة): تعليم القراءة بنور البيان، الحساب بالصور، أصوات الإنجليزي Phonics، واكتشف والعلوم مع تنزيل المنهج كاملاً.
            </p>

            <div className="flex flex-wrap items-center gap-3 pt-2">
              <button
                type="button"
                onClick={() => openCourse('crs-kg-ar')}
                className="inline-flex items-center gap-2 px-5 py-3 min-h-[44px] bg-blue-700 hover:bg-blue-800 text-white text-xs sm:text-sm font-semibold rounded-xl transition-colors whitespace-nowrap shrink-0 cursor-pointer"
              >
                <Play className="w-4 h-4" />
                <span>ابدأ درس العربي المجاني</span>
              </button>

              <button
                type="button"
                onClick={() => handleDownloadAllKg('html')}
                className="inline-flex items-center gap-2 px-5 py-3 min-h-[44px] bg-slate-900 dark:bg-slate-800 hover:bg-slate-800 dark:hover:bg-slate-700 text-white text-xs sm:text-sm font-semibold rounded-xl transition-colors whitespace-nowrap shrink-0 cursor-pointer"
              >
                <Download className="w-4 h-4" />
                <span>تنزيل مناهج KG المفعلة</span>
              </button>

              <button
                type="button"
                onClick={() => setActiveSection('interactive-lab')}
                className="inline-flex items-center gap-2 px-4 py-3 min-h-[44px] bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-900 dark:text-slate-100 text-xs sm:text-sm font-semibold rounded-xl transition-colors whitespace-nowrap shrink-0 cursor-pointer"
              >
                <BookOpen className="w-4 h-4" />
                <span>مختبر الحروف والأرقام</span>
              </button>
            </div>
          </div>

          <div className="mt-8 pt-5 border-t border-slate-100 dark:border-slate-800 flex flex-wrap items-center gap-4 text-xs text-slate-500 dark:text-slate-400">
            <span>فيديوهات كرتونية بصوت الأستاذة</span>
            <span aria-hidden="true">·</span>
            <span>8 محاضرات شهرياً لكل مادة</span>
            <span aria-hidden="true">·</span>
            <span>عربي · حساب · Phonics · اكتشف</span>
          </div>
        </div>

        <div className="lg:col-span-5 relative rounded-2xl overflow-hidden border border-slate-200 dark:border-slate-800 bg-slate-900 min-h-[300px]">
          <SafeImage
            src="/src/assets/images/kg_foundation_banner_1795354180015.jpg"
            alt="طاولة تأسيس رياض الأطفال بالحروف العربية والإنجليزية والمعداد الخشبي"
            className="w-full h-full lg:h-full object-cover"
            fallbackTitle="تأسيس رياض الأطفال — جميع المواد"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-slate-950/20 to-transparent flex flex-col justify-end p-6">
            <p className="text-xs text-amber-300">KG1 &amp; KG2 · باقة التأسيس الشاملة</p>
            <p className="text-lg font-bold text-white font-display mt-0.5">
              شرح صوتي ونطق سليم مع كراسات قابلة للتنزيل
            </p>
          </div>
        </div>
      </section>

      {/* Interactive Mini Flashcard Explorer with Audio Playback */}
      <section className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 space-y-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 dark:border-slate-800 pb-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2 text-xs font-semibold text-blue-700 dark:text-blue-400">
              <Sparkles className="w-4 h-4" />
              <span>بطاقات التأسيس الناطقة</span>
            </div>
            <h2 className="text-xl font-bold text-slate-900 dark:text-slate-100 font-display">
              جولة صوتية في مواد رياض الأطفال الأربع
            </h2>
          </div>

          <div className="flex items-center gap-1 p-1 bg-slate-100 dark:bg-slate-800 rounded-xl overflow-x-auto">
            {KG_FUN_CARDS.map((card, idx) => (
              <button
                key={card.subject}
                type="button"
                onClick={() => {
                  speechController.stop();
                  setIsSpeaking(false);
                  setActiveCardIdx(idx);
                }}
                className={`px-3 py-1.5 text-xs font-semibold rounded-lg whitespace-nowrap shrink-0 cursor-pointer ${
                  activeCardIdx === idx
                    ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-slate-100 shadow-sm'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-100'
                }`}
              >
                {card.subject}
              </button>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-center bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-xl p-6">
          <div className="md:col-span-4 flex items-center justify-center bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl h-40">
            <span className="text-6xl font-extrabold text-blue-700 dark:text-blue-400 font-display">
              {activeCard.symbol}
            </span>
          </div>
          <div className="md:col-span-8 space-y-3">
            <p className="text-xs font-semibold text-amber-700 dark:text-amber-400">{activeCard.subject}</p>
            <h3 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-slate-100 font-display">
              {activeCard.word}
            </h3>
            <p className="text-sm text-slate-600 dark:text-slate-300 leading-relaxed">{activeCard.hint}</p>

            <button
              type="button"
              onClick={handleToggleCardVoice}
              className={`inline-flex items-center gap-2 px-4 py-2.5 min-h-[40px] text-xs font-semibold rounded-xl transition-colors cursor-pointer ${
                isSpeaking
                  ? 'bg-amber-500 text-slate-950 hover:bg-amber-400'
                  : 'bg-blue-700 hover:bg-blue-800 text-white'
              }`}
            >
              {isSpeaking ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
              <span>{isSpeaking ? 'إيقاف الصوت' : 'استمع للنطق والشرح بالصوت'}</span>
            </button>
          </div>
        </div>
      </section>

      {/* All KG Courses Filtered by Subject */}
      <section className="space-y-6">
        <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-4 border-b border-slate-200 dark:border-slate-800 pb-4">
          <div>
            <h2 className="text-2xl font-extrabold text-slate-900 dark:text-slate-100 font-display">
              كورسات تأسيس رياض الأطفال (جميع المواد)
            </h2>
            <p className="text-sm text-slate-600 dark:text-slate-400 mt-1">
              مناهج متدرجة مع شرح صوتي وتنزيل المنهج كاملاً لكل مادة
            </p>
          </div>

          <div className="flex items-center gap-1 p-1 bg-slate-100 dark:bg-slate-900 border border-transparent dark:border-slate-800 rounded-xl overflow-x-auto">
            {branchTabs.map((tab) => (
              <button
                key={tab.id}
                type="button"
                onClick={() => setBranchFilter(tab.id)}
                className={`px-3 py-1.5 text-xs font-semibold rounded-lg whitespace-nowrap shrink-0 cursor-pointer ${
                  branchFilter === tab.id
                    ? 'bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100 shadow-sm'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-100'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {kgCourses.map((course) => {
            const isEnrolled =
              course.priceEgp === 0 || Boolean(currentStudent?.enrolledCourseIds.includes(course.id));
            return (
              <article
                key={course.id}
                className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl overflow-hidden flex flex-col sm:flex-row"
              >
                <div className="sm:w-48 aspect-[4/3] sm:aspect-auto shrink-0 bg-slate-100 dark:bg-slate-800 border-b sm:border-b-0 sm:border-l border-slate-100 dark:border-slate-800">
                  <SafeImage
                    src={course.coverImage}
                    alt={course.title}
                    className="w-full h-full object-cover"
                    fallbackTitle={course.title}
                  />
                </div>

                <div className="p-5 flex-1 flex flex-col justify-between space-y-4">
                  <div className="space-y-2">
                    <p className="text-xs text-slate-500 dark:text-slate-400">
                      <span className="font-semibold text-blue-700 dark:text-blue-400">{BRANCH_LABELS[course.branch]}</span>
                      {' · '}
                      <span className="tabular-nums">{course.lessons.length} محاضرات شهرياً</span>
                      {' · '}
                      <span className="tabular-nums">{course.totalHours} ساعات</span>
                    </p>
                    <h3 className="text-base sm:text-lg font-bold text-slate-900 dark:text-slate-100 font-display leading-snug">
                      {course.title}
                    </h3>
                    <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">{course.subtitle}</p>
                  </div>

                  <div className="flex flex-wrap items-center justify-between gap-2 pt-3 border-t border-slate-100 dark:border-slate-800">
                    <div>
                      <span className="text-base font-extrabold text-slate-900 dark:text-slate-100 tabular-nums">
                        {formatEgp(course.priceEgp)}
                      </span>
                      {isEnrolled ? (
                        <span className="mr-2 inline-flex items-center gap-1 text-[11px] font-semibold text-emerald-700 dark:text-emerald-400">
                          <CheckCircle2 className="w-3.5 h-3.5" />
                          <span>مفعل</span>
                        </span>
                      ) : (
                        <span className="mr-2 inline-flex items-center gap-1 text-[11px] font-semibold text-amber-800 dark:text-amber-400">
                          <Lock className="w-3 h-3" />
                          <span>مغلق حتى السداد</span>
                        </span>
                      )}
                    </div>

                    <div className="flex items-center gap-2 shrink-0">
                      {isEnrolled && (
                        <button
                          type="button"
                          onClick={() =>
                            void downloadAuthorizedCurriculum({ courseId: course.id, format: 'html' })
                          }
                          className="inline-flex items-center gap-1 px-3 py-2 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-900 dark:text-slate-100 text-xs font-semibold rounded-xl whitespace-nowrap cursor-pointer"
                        >
                          <Download className="w-3.5 h-3.5" />
                          <span>تنزيل المنهج</span>
                        </button>
                      )}

                      <button
                        type="button"
                        onClick={() => openCourse(course.id)}
                        className={`inline-flex items-center gap-1.5 px-4 py-2 text-white text-xs font-semibold rounded-xl whitespace-nowrap cursor-pointer ${
                          isEnrolled
                            ? 'bg-emerald-700 hover:bg-emerald-800'
                            : 'bg-slate-900 dark:bg-blue-700 hover:bg-slate-800 dark:hover:bg-blue-800'
                        }`}
                      >
                        {isEnrolled ? <Play className="w-3.5 h-3.5" /> : <Lock className="w-3.5 h-3.5" />}
                        <span>{isEnrolled ? 'فتح المادة' : 'ادفع وافتح'}</span>
                      </button>
                    </div>
                  </div>
                </div>
              </article>
            );
          })}
        </div>
      </section>
    </div>
  );
}
